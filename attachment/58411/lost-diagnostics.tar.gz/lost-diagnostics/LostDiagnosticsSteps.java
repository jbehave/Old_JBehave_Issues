import org.jbehave.core.annotations.Given;

public class LostDiagnosticsSteps {
	@Given("a duplicate step")
	public void duplicate1() {
	}

	@Given("a duplicate step")
	public void duplicate2() {
	}
}