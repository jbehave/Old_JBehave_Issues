package org.eclipse.behavior.assist;

import org.eclipse.jface.text.contentassist.ICompletionProposal;
import org.eclipse.jface.text.quickassist.IQuickAssistInvocationContext;
import org.eclipse.jface.text.quickassist.IQuickAssistProcessor;
import org.eclipse.jface.text.source.Annotation;

public class BehaviorProcessor implements IQuickAssistProcessor {

	public boolean canAssist(IQuickAssistInvocationContext arg0) {
		return true;
	}

	public boolean canFix(Annotation arg0) {
		return true;
	}

	public ICompletionProposal[] computeQuickAssistProposals(IQuickAssistInvocationContext arg0) {
		return null;
	}

	public String getErrorMessage() {
		return null;
	}

}
