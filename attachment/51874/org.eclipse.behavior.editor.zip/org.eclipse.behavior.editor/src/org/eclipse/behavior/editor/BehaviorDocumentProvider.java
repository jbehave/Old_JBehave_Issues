package org.eclipse.behavior.editor;

import org.eclipse.core.resources.IProject;
import org.eclipse.core.runtime.CoreException;
import org.eclipse.jface.text.IDocument;
import org.eclipse.jface.text.IDocumentPartitioner;
import org.eclipse.ui.editors.text.FileDocumentProvider;
import org.eclipse.ui.part.FileEditorInput;

public class BehaviorDocumentProvider extends FileDocumentProvider {

	protected IDocument createDocument(Object element) throws CoreException {
		if (element instanceof FileEditorInput) {
			final IProject project = ((FileEditorInput) element).getFile().getProject();
			IDocument document = super.createDocument(element);
			if (document != null) {
				IDocumentPartitioner partitioner =
						new ProjectAwareFastPartitioner(new BehaviorPartitionScanner(), new String[]{
								BehaviorPartitionScanner.GWZ }, project);
				partitioner.connect(document);
				document.setDocumentPartitioner(partitioner);
			}
			return document;
		}
		return null;
	}

}