package org.eclipse.behavior.properties;

import java.util.Map;

public interface PropertiesFile {

	public abstract Map getAllProperties();

	public abstract String getProperty(String s);
}
