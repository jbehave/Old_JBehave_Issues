package org.eclipse.behavior.builder;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.util.Map;
import java.util.regex.Pattern;

import org.eclipse.behavior.BehaviorEditorPlugin;
import org.eclipse.behavior.markers.MarkerTool;
import org.eclipse.behavior.steps.LineParser;
import org.eclipse.behavior.steps.StepLocator;
import org.eclipse.core.resources.IFile;
import org.eclipse.core.resources.IProject;
import org.eclipse.core.resources.IResource;
import org.eclipse.core.resources.IResourceDelta;
import org.eclipse.core.resources.IResourceDeltaVisitor;
import org.eclipse.core.resources.IResourceVisitor;
import org.eclipse.core.resources.IncrementalProjectBuilder;
import org.eclipse.core.runtime.CoreException;
import org.eclipse.core.runtime.IProgressMonitor;
import org.eclipse.jdt.internal.core.ResolvedSourceMethod;
import org.eclipse.search.core.text.TextSearchEngine;
import org.eclipse.search.core.text.TextSearchMatchAccess;
import org.eclipse.search.core.text.TextSearchRequestor;
import org.eclipse.search.core.text.TextSearchScope;

public class BehaviorValidator extends IncrementalProjectBuilder {

	public static final String BUILDER_ID = "BehaviorEclipse.BehaviorValidator";

	static MarkerTool markerTool = new MarkerTool();

	public static class StepUse {

		final String step;
		final IFile file;

		public StepUse(String step, IFile file) {
			this.step = step;
			this.file = file;
		}

		@Override
		public int hashCode() {
			final int prime = 31;
			int result = 1;
			result = prime * result + ((file == null) ? 0 : file.hashCode());
			result = prime * result + ((step == null) ? 0 : step.hashCode());
			return result;
		}

		@Override
		public boolean equals(Object obj) {
			if (this == obj)
				return true;
			if (obj == null)
				return false;
			if (getClass() != obj.getClass())
				return false;
			StepUse other = (StepUse) obj;
			if (file == null) {
				if (other.file != null)
					return false;
			} else if (!file.equals(other.file))
				return false;
			if (step == null) {
				if (other.step != null)
					return false;
			} else if (!step.equals(other.step))
				return false;
			return true;
		}
	}

	class SampleDeltaVisitor implements IResourceDeltaVisitor {

		/**
		 * If one of step class is added, updated or deleted we refresh the project cache and 
		 * then we re-validate all scenario and story files.
		 */
		public boolean visit(IResourceDelta delta) throws CoreException {
			IResource resource = delta.getResource();
			switch (delta.getKind()) {
			case IResourceDelta.ADDED:
				// handle added resource
				refreshProjectCache(resource);
				checkSteps(resource, null);
				break;
			case IResourceDelta.REMOVED:
				// handle removed resource
				refreshProjectCache(resource);
				break;
			case IResourceDelta.CHANGED:
				// handle changed resource
				refreshProjectCache(resource);
				checkSteps(resource, null);
				break;
			}
			// return true to continue visiting children.
			return true;
		}
	}

	class SampleResourceVisitor implements IResourceVisitor {

		private final IProgressMonitor monitor;

		public SampleResourceVisitor(IProgressMonitor monitor) {
			this.monitor = monitor;
		}

		public boolean visit(IResource resource) {
			// checkSteps(resource, monitor);
			// return true to continue visiting children.
			return false;
		}
	}

	/**
	 * In added, updated or deleted file is a java step we refresh the project cache and the textual files.
	 * @param resource The current project.
	 */
	void refreshProjectCache(IResource resource) {
		if (BehaviorEditorPlugin.JAVA_STEPS != null) {
			for (String step : BehaviorEditorPlugin.JAVA_STEPS) {
				if (resource instanceof IFile && resource.getName().contains(step)
						&& resource.getName().endsWith("." + BehaviorEditorPlugin.JAVA)) {
					BehaviorNature.initiateProjectCache(resource.getProject());
					refreshAllScenarioFilesFromProject(resource.getProject());
					break;
				}
			}
		}
	}

	/**
	 * This method will re-validate all scenario or story files from the current project.
	 * This action is made if one of step java class is added, updated or deleted. 
	 * @param project the current project.
	 */
	public static void refreshAllScenarioFilesFromProject(IProject project) {
		TextSearchEngine engine = TextSearchEngine.create();

		TextSearchScope scope =
				TextSearchScope.newSearchScope(new IResource[]{ project }, Pattern
						.compile(BehaviorEditorPlugin.SCENARIO_FILE_EXTENSIONS_AS_REGEX), false);
		TextSearchRequestor req = new TextSearchRequestor() {

			public boolean acceptPatternMatch(TextSearchMatchAccess m) throws CoreException {
				return true;
			}

			public boolean acceptFile(IFile file) throws CoreException {
				if (file.getName().matches(BehaviorEditorPlugin.SCENARIO_FILE_EXTENSIONS_AS_REGEX)) {
					checkSteps(file, null);
					return true;
				}
				return false;
			}
		};
		engine.search(scope, req, Pattern.compile(""), null);
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see org.eclipse.core.internal.events.InternalBuilder#build(int, java.util.Map,
	 * org.eclipse.core.runtime.IProgressMonitor)
	 */
	protected IProject[] build(int kind, Map args, IProgressMonitor monitor) throws CoreException {
		if (kind == FULL_BUILD) {
			fullBuild(monitor);
		} else {
			IResourceDelta delta = getDelta(getProject());
			if (delta == null) {
				fullBuild(monitor);
			} else {
				incrementalBuild(delta, monitor);
			}
		}
		return null;
	}

	/**
	 * If files name is scenario or story we read line by line and we check if current
	 *  line correspond to a step method.
	 * @param resource
	 * @param monitor
	 */
	static void checkSteps(IResource resource, IProgressMonitor monitor) {
		if (resource instanceof IFile
				&& resource.getName().matches(BehaviorEditorPlugin.SCENARIO_FILE_EXTENSIONS_AS_REGEX)) {
			IFile file = (IFile) resource;
			markerTool.deleteMarkers(file);

			BufferedReader br = null;
			try {
				br = new BufferedReader(new InputStreamReader(file.getContents()));
				String line = br.readLine();
				int lineNo = 0;
				while (line != null) {
					lineNo++;
					LineParser lineParser = new LineParser();
					if (lineParser.isStep(line)) {
						String step = lineParser.parse(line);
						if (monitor != null) {
							monitor.subTask("Validating step: " + step);
							monitor.worked(1);
						}
						ResolvedSourceMethod stepImplementation = validateStep(step, resource.getProject());
						if (stepImplementation == null) {
							markerTool.drawMarker(file, step, lineNo);
						}
					}
					line = br.readLine();
				}
			} catch (Exception e) {
				throw new RuntimeException(e);
			} finally {
				if (br != null)
					try {
						br.close();
					} catch (Exception e) {
					}
			}
		}
	}

	/**
	 * Return the corresponding java method for a textual step.
	 * @param step
	 * @param iProject
	 * @return
	 */
	static private ResolvedSourceMethod validateStep(String step, IProject iProject) {
		return new StepLocator().findMethod(step, iProject);
	}

	protected void fullBuild(final IProgressMonitor monitor) throws CoreException {
		try {
			// TODO no. of steps is hardcoded to 20
			if (monitor != null)
				monitor.beginTask("Started validating steps...", 20);
			getProject().accept(new SampleResourceVisitor(monitor));
		} catch (CoreException e) {
		}
	}

	protected void incrementalBuild(IResourceDelta delta, IProgressMonitor monitor) throws CoreException {
		// the visitor does the work.
		delta.accept(new SampleDeltaVisitor());
	}
}
