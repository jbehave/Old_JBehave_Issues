package org.eclipse.behavior.nature;

import org.eclipse.behavior.builder.BehaviorNature;
import org.eclipse.core.resources.IProject;
import org.eclipse.core.resources.ResourcesPlugin;
import org.eclipse.core.runtime.CoreException;

public class BehaviorNatureDetector {

	public IProject detectProject() {
		IProject[] projects = ResourcesPlugin.getWorkspace().getRoot().getProjects();
		for (IProject p : projects) {
			try {
				if (p.hasNature(BehaviorNature.NATURE_ID)) {
					return p;
				}
			} catch (CoreException e) {
				throw new RuntimeException("BehaviorEditorPlugin has problems detecting the nature of projects", e);
			}
		}
		return null;
	}
}
