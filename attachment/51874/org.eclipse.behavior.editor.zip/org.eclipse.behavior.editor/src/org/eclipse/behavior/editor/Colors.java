package org.eclipse.behavior.editor;

import org.eclipse.swt.graphics.RGB;

public interface Colors {
	RGB GWZ_SCRIPT = new RGB(128, 0, 0);
	RGB DEFAULT = new RGB(0, 0, 0);
	RGB GWZ_KEYWORD = new RGB(0, 0, 255);
}
