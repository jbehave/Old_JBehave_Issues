package org.eclipse.behavior.assist;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Iterator;
import java.util.List;
import java.util.Set;
import java.util.regex.Pattern;

import org.eclipse.behavior.BehaviorEditorPlugin;
import org.eclipse.behavior.builder.BehaviorNature;
import org.eclipse.behavior.editor.ProjectAwareFastPartitioner;
import org.eclipse.behavior.steps.LineParser;
import org.eclipse.core.resources.IProject;
import org.eclipse.jface.text.BadLocationException;
import org.eclipse.jface.text.IDocument;
import org.eclipse.jface.text.ITextSelection;
import org.eclipse.jface.text.ITextViewer;
import org.eclipse.jface.text.contentassist.ICompletionProposal;
import org.eclipse.jface.text.contentassist.IContentAssistProcessor;
import org.eclipse.jface.text.contentassist.IContextInformation;
import org.eclipse.jface.text.contentassist.IContextInformationValidator;

/**
 * Behavior completion processor.
 * 
 * @author florea
 */
public class BehaviorContentCompletionProcessor implements
		IContentAssistProcessor {

	private static final ICompletionProposal[] NO_PROPOSALS = new ICompletionProposal[2];

	// public to enable unit testing
	public static Pattern MODULE_PREFIX_PATTERN = Pattern
			.compile("([A-Za-z0-9_]+(::|->))+");
	public static Pattern VAR_PREFIX_PATTERN = Pattern
			.compile("\\$[A-Za-z0-9_]+(::|->)$");

	public BehaviorContentCompletionProcessor() {

	}

	public ICompletionProposal[] computeCompletionProposals(ITextViewer viewer,
			int documentOffset) {
		// get the current document's text, up to caret position
		IDocument document = viewer.getDocument();
		ITextSelection selection = (ITextSelection) viewer
				.getSelectionProvider().getSelection();
		if (selection.getLength() > 0)
			return NO_PROPOSALS;

		String lastTextLine = null;
		int lastLine;
		int lineStartOffset = 0;
		try {
			lastLine = document.getLineOfOffset(documentOffset);
			lineStartOffset = document.getLineOffset(lastLine);
			lastTextLine = document.get(lineStartOffset, documentOffset
					- lineStartOffset);
		} catch (BadLocationException e) {
		}

		ProjectAwareFastPartitioner partitioner = (ProjectAwareFastPartitioner) viewer
				.getDocument().getDocumentPartitioner();
		IProject project = partitioner.getProject();

		if (BehaviorNature.getProjectCache(project) == null) {
			BehaviorNature.initiateProjectCache(project);
		}
		Set<String> projectCacheKeys = BehaviorNature.getProjectCache(project)
				.keySet();
		List<BehaviorStepProposal> proposals = new ArrayList<BehaviorStepProposal>();
		Iterator<String> iterator = projectCacheKeys.iterator();
		LineParser lineParser = new LineParser();
		// remove the last '?' character, who triggers the proposals appears
		lastTextLine = lastTextLine.substring(0, lastTextLine.length() - 1);
		// get the last line without the key words When, Give, Then or And
		String parsedLine = lineParser.getLineWithoutKeyword(lastTextLine);
		// save the key word, if it exist on last line
		String parsedKeyWork = lineParser.getKeyWord(lastTextLine);
		// add the reg ex at the end of the last line string
		while (iterator.hasNext()) {
			String annotationStringRegExValue = iterator.next();
			String auxParsedLine = parsedLine;
			int index = annotationStringRegExValue.indexOf(".*?");
			if (index > 0 && index < auxParsedLine.length()) {
				auxParsedLine = auxParsedLine.substring(0, index);
			}
			if (auxParsedLine.length() == 0
					|| annotationStringRegExValue.startsWith(auxParsedLine)) {
				if (parsedKeyWork != null && parsedKeyWork.trim().length() > 0) {
					// if write and, then, when or given, it will transform in
					// And, Then, When or Given
					parsedKeyWork = parsedKeyWork.replaceFirst(new String(
							new char[] { parsedKeyWork.charAt(0) }),
							new String(new char[] { parsedKeyWork.charAt(0) })
									.toUpperCase());
					annotationStringRegExValue = parsedKeyWork + " "
							+ annotationStringRegExValue;
				}
				proposals.add(new BehaviorStepProposal(
						annotationStringRegExValue, lineStartOffset,
						documentOffset));
				continue;
			}
		}
		Collections.sort(proposals);
		return proposals.toArray(new ICompletionProposal[proposals.size()]);
	}

	public IContextInformation[] computeContextInformation(ITextViewer viewer,
			int documentOffset) {
		return null;
	}

	public char[] getCompletionProposalAutoActivationCharacters() {
		return BehaviorEditorPlugin.AUTOCOMPLETE_CHARACTER_TRIGGER
				.toCharArray();
	}

	public char[] getContextInformationAutoActivationCharacters() {
		return null;
	}

	public String getErrorMessage() {
		return null;
	}

	public IContextInformationValidator getContextInformationValidator() {
		return null;
	}

}
