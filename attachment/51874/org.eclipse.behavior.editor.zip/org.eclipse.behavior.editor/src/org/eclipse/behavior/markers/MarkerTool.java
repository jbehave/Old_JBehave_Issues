package org.eclipse.behavior.markers;

import org.eclipse.behavior.BehaviorEditorPlugin;
import org.eclipse.core.resources.IFile;
import org.eclipse.core.resources.IMarker;
import org.eclipse.core.resources.IResource;
import org.eclipse.core.runtime.CoreException;

public class MarkerTool {

	private static final String MARKER_TYPE = "BehaviorEclipse.BehaviorProblem";

	public void drawMarker(IFile file, String message, int lineNumber) {
		try {
			IMarker marker = file.createMarker(MARKER_TYPE);
			marker.setAttribute(IMarker.MESSAGE, BehaviorEditorPlugin.NO_STEP_THAT_MATCHES + message);
			marker.setAttribute(IMarker.SEVERITY, 1);
			if (lineNumber == -1) {
				lineNumber = 1;
			}
			marker.setAttribute(IMarker.LINE_NUMBER, lineNumber);
		} catch (CoreException e) {
		}
	}

	public void deleteMarkers(IResource resource) {
		try {
			resource.deleteMarkers(MARKER_TYPE, false, IResource.DEPTH_INFINITE);
		} catch (CoreException ce) {
		}
	}

	public boolean isMissingStepMarker(String text) {
		return text.startsWith(BehaviorEditorPlugin.NO_STEP_THAT_MATCHES);
	}
}