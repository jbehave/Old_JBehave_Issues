package org.eclipse.behavior.properties;

public class ClassPathPropertiesFile extends SystemPropertyFile {

	public ClassPathPropertiesFile(String pAddress) {
		if (pAddress == null || pAddress.trim().length() == 0) {
			return;
		}
		java.io.InputStream inputFile = getClass().getClassLoader()
				.getResourceAsStream(pAddress);
		if (null != inputFile)
			super.setPropertyFile(inputFile);
	}

}
