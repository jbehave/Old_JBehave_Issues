package org.eclipse.behavior.search;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.util.LinkedList;
import java.util.List;
import java.util.regex.Pattern;

import org.eclipse.behavior.BehaviorEditorPlugin;
import org.eclipse.behavior.steps.ArgumentParser;
import org.eclipse.behavior.steps.LineParser;
import org.eclipse.core.resources.IFile;
import org.eclipse.core.resources.IResource;
import org.eclipse.core.runtime.CoreException;
import org.eclipse.core.runtime.IProgressMonitor;
import org.eclipse.jdt.core.IAnnotation;
import org.eclipse.jdt.core.IJavaElement;
import org.eclipse.jdt.core.IJavaProject;
import org.eclipse.jdt.internal.core.SourceMethod;
import org.eclipse.jdt.ui.search.ElementQuerySpecification;
import org.eclipse.jdt.ui.search.IMatchPresentation;
import org.eclipse.jdt.ui.search.IQueryParticipant;
import org.eclipse.jdt.ui.search.ISearchRequestor;
import org.eclipse.jdt.ui.search.QuerySpecification;
import org.eclipse.search.core.text.TextSearchEngine;
import org.eclipse.search.core.text.TextSearchMatchAccess;
import org.eclipse.search.core.text.TextSearchRequestor;
import org.eclipse.search.core.text.TextSearchScope;
import org.eclipse.search.ui.text.Match;

public class BehaviorQueryParticipant implements IQueryParticipant {

	public int estimateTicks(QuerySpecification arg0) {
		return 0;
	}

	public IMatchPresentation getUIParticipant() {
		return null;
	}

	public void search(ISearchRequestor requestor, QuerySpecification spec,
			IProgressMonitor monitor) throws CoreException {
		if (spec instanceof ElementQuerySpecification) {
			ElementQuerySpecification elementSpec = (ElementQuerySpecification) spec;
			int elementType = elementSpec.getElement().getElementType();
			if (elementType == IJavaElement.METHOD) {
				IAnnotation[] annotations = ((SourceMethod) elementSpec
						.getElement()).getAnnotations();
				if (annotations == null || annotations.length == 0) {
					return;
				}
				for (IAnnotation annotation : annotations) {
					boolean foundAnnotations = false;
					// all annotation beside Aliases (Given, When, Then and
					// Alias)
					if (BehaviorEditorPlugin.ANNOTATIONS != null) {
						for (String ann : BehaviorEditorPlugin.ANNOTATIONS) {
							if (ann.endsWith(annotation.getElementName())
									&& !annotation.getElementName().equals(
											"Aliases")) {
								foundAnnotations = true;
								break;
							}
						}
					}
					if (foundAnnotations) {
						// TODO: what if no value?
						if (annotation.getMemberValuePairs()[0].getValue() == null) {
							return;
						}
						String step = annotation.getMemberValuePairs()[0]
								.getValue().toString();
						if (step.trim().length() == 0) {
							return;
						}
						List<Match> results = searchForStep(step, elementSpec
								.getElement().getJavaProject(), monitor);
						for (Match m : results) {
							requestor.reportMatch(m);
						}
					}
					if (annotation.getElementName().equals("Aliases")) {
						if (annotation.getMemberValuePairs()[0].getValue() == null) {
							return;
						}
						Object[] values = (Object[]) annotation
								.getMemberValuePairs()[0].getValue();
						if (values != null && values.length > 0) {
							for (Object value : values) {
								String step = value.toString();
								if (step.trim().length() == 0) {
									continue;
								}
								List<Match> results = searchForStep(step,
										elementSpec.getElement()
												.getJavaProject(), monitor);
								for (Match m : results) {
									requestor.reportMatch(m);
								}
							}
						}
					}
				}
			} else if (elementType == IJavaElement.ANNOTATION) {
				// TODO
			}
		}
	}

	private List<Match> searchForStep(final String step, IJavaProject project,
			IProgressMonitor monitor) {
		TextSearchEngine engine = TextSearchEngine.create();
		// TODO: this can be optimized
		TextSearchScope scope = TextSearchScope
				.newSearchScope(
						new IResource[] { project.getResource() },
						Pattern
								.compile(BehaviorEditorPlugin.SCENARIO_FILE_EXTENSIONS_AS_REGEX),
						false);
		final List<Match> matched = new LinkedList<Match>();
		TextSearchRequestor req = new TextSearchRequestor() {

			@Override
			public boolean acceptPatternMatch(TextSearchMatchAccess m)
					throws CoreException {
				matched.add(new Match(m.getFile(), m.getMatchOffset(), m
						.getMatchLength()));
				return true;
			}

			@Override
			public boolean acceptFile(IFile file) throws CoreException {
				if (file.getName().matches(
						BehaviorEditorPlugin.SCENARIO_FILE_EXTENSIONS_AS_REGEX)) {
					BufferedReader br = null;
					try {
						br = new BufferedReader(new InputStreamReader(file
								.getContents()));
						String line = br.readLine();
						while (line != null) {
							LineParser lineParser = new LineParser();
							if (lineParser.isStep(line)) {
								String annotationValueRegEx = step;
								annotationValueRegEx = ArgumentParser
										.replaceArgumentPattern(annotationValueRegEx);
								String lineValue = lineParser.parse(line);
								if (lineValue.matches(annotationValueRegEx)) {
									matched.add(new Match(file, 1, 1));
									return true;
								}
							}
							line = br.readLine();
						}
					} catch (Exception e) {
						throw new RuntimeException(e);
					} finally {
						if (br != null)
							try {
								br.close();
							} catch (Exception e) {
							}
					}
				}
				return false;
			}
		};
		engine.search(scope, req, Pattern.compile(step), monitor);
		return matched;
	}
}