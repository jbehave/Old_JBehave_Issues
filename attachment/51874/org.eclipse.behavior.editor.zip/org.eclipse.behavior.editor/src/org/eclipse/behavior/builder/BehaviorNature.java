package org.eclipse.behavior.builder;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.eclipse.behavior.BehaviorEditorPlugin;
import org.eclipse.behavior.markers.MarkerTool;
import org.eclipse.behavior.steps.ArgumentParser;
import org.eclipse.core.resources.ICommand;
import org.eclipse.core.resources.IProject;
import org.eclipse.core.resources.IProjectDescription;
import org.eclipse.core.resources.IProjectNature;
import org.eclipse.core.runtime.CoreException;
import org.eclipse.jdt.core.IAnnotation;
import org.eclipse.jdt.core.IJavaElement;
import org.eclipse.jdt.core.IJavaProject;
import org.eclipse.jdt.core.JavaCore;
import org.eclipse.jdt.core.search.IJavaSearchConstants;
import org.eclipse.jdt.core.search.IJavaSearchScope;
import org.eclipse.jdt.core.search.SearchEngine;
import org.eclipse.jdt.core.search.SearchMatch;
import org.eclipse.jdt.core.search.SearchParticipant;
import org.eclipse.jdt.core.search.SearchPattern;
import org.eclipse.jdt.core.search.SearchRequestor;
import org.eclipse.jdt.internal.core.ResolvedSourceMethod;

public class BehaviorNature implements IProjectNature {

	/**
	 * This is a big cache containing all projects opened in eclipse. 
	 */
	private static Map<IProject, Map<String, ResolvedSourceMethod>> cache =
			new HashMap<IProject, Map<String, ResolvedSourceMethod>>();

	/**
	 * Reset cache.
	 */
	public static void resetCache() {
		BehaviorNature.cache = new HashMap<IProject, Map<String, ResolvedSourceMethod>>();
	}

	/**
	 * Reset the cache for one project.
	 * @param project The project for which we reset the cache.
	 */
	public static void resetProjectCache(IProject project) {
		BehaviorNature.cache.put(project, new HashMap<String, ResolvedSourceMethod>());
	}

	/**
	 * Set cache for a project. 'Cache' is a big map containing pairs like this:
	 * Key=regular exception with textual step
	 * Value=java method corresponding to this step
	 * @param cache
	 */
	public static void setCache(HashMap<IProject, Map<String, ResolvedSourceMethod>> cache) {
		BehaviorNature.cache = cache;
	}

	public static Map<IProject, Map<String, ResolvedSourceMethod>> getCache() {
		return BehaviorNature.cache;
	}

	/**
	 * Add a project cache to the big cache.
	 * @param project
	 * @param projectCache
	 */
	public static void addProjectToCache(IProject project, Map<String, ResolvedSourceMethod> projectCache) {
		BehaviorNature.cache.put(project, projectCache);
	}

	/**
	 * Return the map corresponding to a project.
	 * @param project
	 * @return
	 */
	public static Map<String, ResolvedSourceMethod> getProjectCache(IProject project) {
		return BehaviorNature.cache.get(project);
	}

	/**
	 * Add a new key/value pair to a project cache.
	 * @param project
	 * @param regEx
	 * @param method
	 */
	public static void addToProjectCache(IProject project, String regEx, ResolvedSourceMethod method) {
		if (BehaviorNature.cache.get(project) == null) {
			BehaviorNature.cache.put(project, new HashMap<String, ResolvedSourceMethod>());
		}
		BehaviorNature.cache.get(project).put(regEx, method);
	}

	/**
	 * Initialize a project cache.
	 * @param project
	 */
	public static void initiateProjectCache(final IProject project) {
		BehaviorNature.resetProjectCache(project);
		IJavaProject myJavaProject = (IJavaProject) JavaCore.create(project);
		List<SearchPattern> patterns = new ArrayList<SearchPattern>();
		for (String annotation : BehaviorEditorPlugin.ANNOTATIONS) {
			patterns.add(SearchPattern.createPattern(annotation, IJavaSearchConstants.ANNOTATION_TYPE,
					IJavaSearchConstants.REFERENCES, SearchPattern.R_PATTERN_MATCH | SearchPattern.R_CASE_SENSITIVE));
		}
		// TODO aliases
		IJavaSearchScope scope = SearchEngine.createJavaSearchScope(new IJavaElement[]{ myJavaProject });
		final SearchRequestor requestor = new SearchRequestor() {

			@Override
			public void acceptSearchMatch(SearchMatch match) throws CoreException {
				if (match.getElement() instanceof ResolvedSourceMethod) {
					ResolvedSourceMethod methodToJump = (ResolvedSourceMethod) match.getElement();
					// TODO: what if there is no annotation :)
					String stepRegEx = "";
					for (IAnnotation ia : methodToJump.getAnnotations()) {
						// aliases has a special behavior
						if (ia.getElementName().equals("Aliases")) {
							Object[] values =
									(Object[]) methodToJump.getAnnotation("Aliases").getMemberValuePairs()[0]
											.getValue();
							if (values != null && values.length > 0) {
								for (Object value : values) {
									stepRegEx = value.toString();
									// this will replace the $argumentName pattern
									stepRegEx = ArgumentParser.replaceArgumentPattern(stepRegEx);
									BehaviorNature.addToProjectCache(project, stepRegEx, methodToJump);
								}
							}
							continue;
						}

						if (ia.getElementName().matches(BehaviorEditorPlugin.ANNOTATIONS_SHORT_NAMES_AS_REGEX)) {
							stepRegEx =
									methodToJump.getAnnotation(ia.getElementName()).getMemberValuePairs()[0].getValue()
											.toString();
						}
						// this will replace the $argumentName pattern
						stepRegEx = ArgumentParser.replaceArgumentPattern(stepRegEx);
						BehaviorNature.addToProjectCache(project, stepRegEx, methodToJump);
					}
				}
			}
		};

		// search
		SearchEngine searchEngine = new SearchEngine();
		try {
			for (SearchPattern pattern : patterns) {
				searchEngine.search(pattern, new SearchParticipant[]{ SearchEngine.getDefaultSearchParticipant() },
						scope, requestor, null);
			}
		} catch (CoreException e) {
			throw new RuntimeException("Something went wrong when searching for Step", e);
		}
	}

	/**
	 * ID of this project nature
	 */
	public static final String NATURE_ID = "BehaviorEclipse.BehaviorNature";

	private IProject project;

	/*
	 * (non-Javadoc)
	 * 
	 * @see org.eclipse.core.resources.IProjectNature#configure()
	 */
	/**
	 * Add BehaviorValidator to project.
	 */
	public void configure() throws CoreException {
		IProjectDescription desc = project.getDescription();
		ICommand[] commands = desc.getBuildSpec();

		for (int i = 0; i < commands.length; ++i) {
			if (commands[i].getBuilderName().equals(BehaviorValidator.BUILDER_ID)) {
				return;
			}
		}

		ICommand[] newCommands = new ICommand[commands.length + 1];
		System.arraycopy(commands, 0, newCommands, 0, commands.length);
		ICommand command = desc.newCommand();
		command.setBuilderName(BehaviorValidator.BUILDER_ID);
		newCommands[newCommands.length - 1] = command;
		desc.setBuildSpec(newCommands);
		project.setDescription(desc, null);
		//init cache and the marks the scenario and story files.
		BehaviorNature.initiateProjectCache(project);
		BehaviorValidator.refreshAllScenarioFilesFromProject(project);
		// TODO: perform build if possible
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see org.eclipse.core.resources.IProjectNature#deconfigure()
	 */
	/**
	 * Remove the BehaviorValidator for the current project.
	 */
	public void deconfigure() throws CoreException {
		// TODO: remove markers on deconfigure
		IProjectDescription description = getProject().getDescription();
		ICommand[] commands = description.getBuildSpec();
		for (int i = 0; i < commands.length; ++i) {
			if (commands[i].getBuilderName().equals(BehaviorValidator.BUILDER_ID)) {
				new MarkerTool().deleteMarkers(getProject());
				ICommand[] newCommands = new ICommand[commands.length - 1];
				System.arraycopy(commands, 0, newCommands, 0, i);
				System.arraycopy(commands, i + 1, newCommands, i, commands.length - i - 1);
				description.setBuildSpec(newCommands);
				project.setDescription(description, null);
				return;
			}
		}
		BehaviorNature.resetProjectCache(project);
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see org.eclipse.core.resources.IProjectNature#getProject()
	 */
	public IProject getProject() {
		return project;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see org.eclipse.core.resources.IProjectNature#setProject(org.eclipse.core .resources.IProject)
	 */
	public void setProject(IProject project) {
		this.project = project;
	}
}