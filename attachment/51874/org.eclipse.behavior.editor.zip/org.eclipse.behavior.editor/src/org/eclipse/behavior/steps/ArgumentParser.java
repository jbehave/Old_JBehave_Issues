package org.eclipse.behavior.steps;

import org.eclipse.behavior.BehaviorEditorPlugin;

public class ArgumentParser {

	/*
	 * This method will replace the argument definition with a regEx definition.
	 * Ex: 1. regEx =
	 * "there are $number packager action histories for $packager: [$actions]"
	 * will became "there are .*? packager action histories for .*?: .*?" 
	 * 2. regEx =
	 * "get packager instance header for retailer packager id: $retailerId" will
	 * became regEx =
	 * "get packager instance header for retailer packager id: .*?"
	 */
	public static String replaceArgumentPattern(String regEx) {
		try {
			// treate the [$param] used for arrays
			// and list arguments
			regEx = regEx.replaceAll("[\\[]["
					+ BehaviorEditorPlugin.ARGUMENT_SEPARATOR + "][a-zA-Z0-9]*[\\]]",
					".*?");
			// treate the $param used for arguments
			regEx = regEx.replaceAll("[" + BehaviorEditorPlugin.ARGUMENT_SEPARATOR
					+ "][a-zA-Z0-9]*", ".*?");
			if(regEx.endsWith(" .*?")){
				//This is a workaround to find table step. We simply replace the suffix " .*?" with ".*?".
				regEx = regEx.substring(0, regEx.length()-4)+".*?";
			}
		} catch (java.util.regex.PatternSyntaxException e) {
			// TODO - actually do nothing
		}
		return regEx;
	}
}
