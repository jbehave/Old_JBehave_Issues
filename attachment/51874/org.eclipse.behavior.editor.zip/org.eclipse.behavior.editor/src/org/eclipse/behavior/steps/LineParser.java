package org.eclipse.behavior.steps;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.eclipse.behavior.BehaviorEditorPlugin;

public class LineParser {

	public LineParser() {
		Object[] array = BehaviorEditorPlugin.KEY_WORDS.toArray();
		if (NEW_FITNESSE_SYNTAX == null) {
			String newFitnesseSyntax = "";
			newFitnesseSyntax += "(";
			for (int i = 0; i < array.length; i++) {
				newFitnesseSyntax += array[i].toString().trim();
				if(i<array.length - 1){
					newFitnesseSyntax += " |";
				}
			}
			newFitnesseSyntax += " )(.+?)";
			NEW_FITNESSE_SYNTAX = Pattern.compile(newFitnesseSyntax,
					Pattern.CASE_INSENSITIVE);
		}

		if (OLD_SYNTAX_WITH_PIPES == null) {
			String oldFitnesseSyntax = "";
			oldFitnesseSyntax += ".*?\\|\\s*?(";
			for (int i = 0; i < array.length; i++) {
				oldFitnesseSyntax += array[i].toString().trim() + "|";
				if(i<BehaviorEditorPlugin.KEY_WORDS.size() - 1){
					oldFitnesseSyntax += "|";
				}
			}
			oldFitnesseSyntax += ")\\s*?\\|(.+?)\\|.*";
			OLD_SYNTAX_WITH_PIPES = Pattern.compile(oldFitnesseSyntax,
					Pattern.CASE_INSENSITIVE);
		}
	}

	private static Pattern NEW_FITNESSE_SYNTAX = null;
	// = Pattern.compile(
	// "(Given |When |Then |And )(.+?)", Pattern.CASE_INSENSITIVE);
	private static Pattern OLD_SYNTAX_WITH_PIPES = null;

	// Pattern.compile(".*?\\|\\s*?(Given|When|Then|And|But)\\s*?\\|(.+?)\\|.*",
	// Pattern.CASE_INSENSITIVE);

	public String parse(String step) {
		Matcher m = null;
		// new fitnesse syntax
		m = NEW_FITNESSE_SYNTAX.matcher(step);
		if (m.matches()) {
			return m.group(2).trim();
		}

		// old 'pipe'-like
		m = OLD_SYNTAX_WITH_PIPES.matcher(step);
		if (m.matches()) {
			return m.group(2).trim();
		}

		return step;
	}

	/**
	 * Remove the key word
	 * 
	 * @param step
	 * @return
	 */
	public String getLineWithoutKeyword(String step) {

		// new fitnesse syntax
		Matcher m = NEW_FITNESSE_SYNTAX.matcher(step);
		if (m.matches()) {
			return m.group(2).trim();
		}
		// old 'pipe'-like
		m = OLD_SYNTAX_WITH_PIPES.matcher(step);
		if (m.matches()) {
			return m.group(2).trim();
		}

		// if we have 'And ' this method return 'And ' instead of empty string
		// because it hasn't 2 groups
		return parse(step + " ").trim();
	}

	public String getKeyWord(String step) {

		// new fitnesse syntax
		Matcher m = NEW_FITNESSE_SYNTAX.matcher(step);
		if (m.matches()) {
			return m.group(1).trim();
		}

		// old 'pipe'-like
		m = OLD_SYNTAX_WITH_PIPES.matcher(step);
		if (m.matches()) {
			return m.group(1).trim();
		}

		return "";
	}

	public boolean isStep(String line) {
		return NEW_FITNESSE_SYNTAX.matcher(line).matches()
				|| OLD_SYNTAX_WITH_PIPES.matcher(line).matches();
	}
}