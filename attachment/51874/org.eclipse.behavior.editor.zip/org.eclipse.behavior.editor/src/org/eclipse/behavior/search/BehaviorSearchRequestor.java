/**
 * 
 */
package org.eclipse.behavior.search;

import org.eclipse.behavior.BehaviorEditorPlugin;
import org.eclipse.behavior.steps.ArgumentParser;
import org.eclipse.core.runtime.CoreException;
import org.eclipse.jdt.core.IAnnotation;
import org.eclipse.jdt.core.search.SearchMatch;
import org.eclipse.jdt.core.search.SearchRequestor;
import org.eclipse.jdt.internal.core.ResolvedSourceMethod;

public class BehaviorSearchRequestor extends SearchRequestor {

	String step;
	public ResolvedSourceMethod methodToJump;

	public BehaviorSearchRequestor(String step) {
		this.step = step;
	}

	@Override
	public void acceptSearchMatch(SearchMatch match) throws CoreException {
		if (match.getElement() instanceof ResolvedSourceMethod) {
			ResolvedSourceMethod methodToJump = (ResolvedSourceMethod) match
					.getElement();
			// TODO: what if there is no annotation :)
			String stepRegEx = "";
			for (IAnnotation ia : methodToJump.getAnnotations()) {
				String annotation = null;
				if (ia.getElementName().matches(BehaviorEditorPlugin.ANNOTATIONS_SHORT_NAMES_AS_REGEX)) {
					annotation = ia.getElementName();
				}
				if (annotation != null) {
					if (annotation.equals("Aliases")) {
						// Aliases annotation
						Object[] values = (Object[]) methodToJump
								.getAnnotation("Aliases").getMemberValuePairs()[0]
								.getValue();
						if (values != null && values.length > 0) {
							for (Object value : values) {
								stepRegEx = value.toString();
								// this will replace the $argumentName pattern
								stepRegEx = ArgumentParser
										.replaceArgumentPattern(stepRegEx);
								if (step.matches(stepRegEx)) {
									this.methodToJump = methodToJump;
									return;
								}
							}
						}
					} else {
						// Given, When, Then or Alias annotation
						stepRegEx = methodToJump.getAnnotation(annotation)
								.getMemberValuePairs()[0].getValue().toString();
					}
				}

				// this will replace the $argumentName pattern
				stepRegEx = ArgumentParser.replaceArgumentPattern(stepRegEx);
				if (step.matches(stepRegEx)) {
					this.methodToJump = methodToJump;
					return;
				}
			}
		}
	}
}