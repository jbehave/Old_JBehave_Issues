package org.eclipse.behavior.editor;

import org.eclipse.ui.editors.text.TextEditor;
import org.eclipse.ui.views.contentoutline.IContentOutlinePage;

public class BehaviorEditor extends TextEditor {
	
	private BehaviorStoryContentOutlinePage fOutlinePage;

	private ColorManager colorManager;

	public BehaviorEditor() {
		super();
		colorManager = new ColorManager();
		this.setSourceViewerConfiguration(new BehaviorConfiguration(colorManager));
		setDocumentProvider(new BehaviorDocumentProvider());
	}

	public void dispose() {
		colorManager.dispose();
		super.dispose();
	}
	
	@Override
	public Object getAdapter(Class adapter) {
		if (IContentOutlinePage.class.equals(adapter)) {
			if (fOutlinePage == null) {
				fOutlinePage= new BehaviorStoryContentOutlinePage(getDocumentProvider(), this);
				if (getEditorInput() != null)
					fOutlinePage.setInput(getEditorInput());
			}
			return fOutlinePage;
		}
		
		
		return super.getAdapter(adapter);
	}
}
