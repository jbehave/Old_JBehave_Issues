package org.eclipse.behavior.editor;

import org.eclipse.behavior.BehaviorEditorPlugin;
import org.eclipse.behavior.assist.BehaviorContentCompletionProcessor;
import org.eclipse.behavior.dialogs.BehaviorSimpleDialog;
import org.eclipse.behavior.steps.LineParser;
import org.eclipse.behavior.steps.StepLocator;
import org.eclipse.core.resources.IProject;
import org.eclipse.jdt.internal.core.ResolvedSourceMethod;
import org.eclipse.jdt.ui.JavaUI;
import org.eclipse.jface.text.IDocument;
import org.eclipse.jface.text.IRegion;
import org.eclipse.jface.text.ITextViewer;
import org.eclipse.jface.text.Region;
import org.eclipse.jface.text.TextAttribute;
import org.eclipse.jface.text.contentassist.ContentAssistant;
import org.eclipse.jface.text.contentassist.IContentAssistant;
import org.eclipse.jface.text.hyperlink.IHyperlink;
import org.eclipse.jface.text.hyperlink.IHyperlinkDetector;
import org.eclipse.jface.text.presentation.IPresentationReconciler;
import org.eclipse.jface.text.presentation.PresentationReconciler;
import org.eclipse.jface.text.quickassist.IQuickAssistAssistant;
import org.eclipse.jface.text.rules.DefaultDamagerRepairer;
import org.eclipse.jface.text.rules.RuleBasedScanner;
import org.eclipse.jface.text.rules.Token;
import org.eclipse.jface.text.source.ISourceViewer;
import org.eclipse.jface.text.source.SourceViewerConfiguration;
import org.eclipse.swt.custom.StyledText;

public class BehaviorConfiguration extends SourceViewerConfiguration {

	private RuleBasedScanner gwzScanner;
	private RuleBasedScanner defaultScanner;
	private ColorManager colorManager;

	public BehaviorConfiguration(ColorManager colorManager) {
		this.colorManager = colorManager;
	}

	public String[] getConfiguredContentTypes(ISourceViewer sourceViewer) {
		return new String[]{ IDocument.DEFAULT_CONTENT_TYPE, BehaviorPartitionScanner.GWZ };
	}

	@Override
	public IQuickAssistAssistant getQuickAssistAssistant(ISourceViewer sourceViewer) {
		return null;
	}

	private ContentAssistant contentAssist;

	@Override
	public IContentAssistant getContentAssistant(ISourceViewer sourceViewer) {
		if (this.contentAssist == null) {
			this.contentAssist = new ContentAssistant();
			this.contentAssist.setContentAssistProcessor(new BehaviorContentCompletionProcessor(),
					BehaviorPartitionScanner.GWZ);
			this.contentAssist.setContentAssistProcessor(new BehaviorContentCompletionProcessor(),
					IDocument.DEFAULT_CONTENT_TYPE);

			this.contentAssist.setProposalPopupOrientation(20);
			this.contentAssist.setContextInformationPopupOrientation(10);
			this.contentAssist.setInformationControlCreator(getInformationControlCreator(sourceViewer));
			this.contentAssist.enableAutoActivation(true);
		}
		return this.contentAssist;
	}

	public IHyperlinkDetector[] getHyperlinkDetectors(final ISourceViewer sourceViewer) {
		return new IHyperlinkDetector[]{ new IHyperlinkDetector() {

			public IHyperlink[] detectHyperlinks(final ITextViewer viewer, final IRegion region,
					boolean canShowMultipleHyperlinks) {
				StyledText widget = viewer.getTextWidget();
				int lineNo = widget.getLineAtOffset(region.getOffset());
				final int lineOffset = widget.getOffsetAtLine(lineNo);
				final String line = viewer.getTextWidget().getLine(lineNo);
				final String step = new LineParser().parse(line);

				IHyperlink link = new IHyperlink() {

					public IRegion getHyperlinkRegion() {
						return new Region(lineOffset, line.length());
					}

					public String getHyperlinkText() {
						return step;
					}

					public String getTypeLabel() {
						return BehaviorEditorPlugin.GO_TO_STEP;
					}

					public void open() {
						try {
							// configure search
							// IProject project = new GivWenZenNatureDetector().detectProject();
							// TODO: huge hack but I don't know how to get the project the other way
							ProjectAwareFastPartitioner partitioner =
									(ProjectAwareFastPartitioner) viewer.getDocument().getDocumentPartitioner();
							IProject project = partitioner.getProject();
							if (project == null) {
								new BehaviorSimpleDialog()
										.show(
												BehaviorEditorPlugin.CANNOT_LOCATE_STEP_TITLE,
												BehaviorEditorPlugin.CANNOT_LOCATE_STEP_MESSAGE);
								return;
							}
							ResolvedSourceMethod methodToJump = new StepLocator().findMethod(step, project);
							// jump to method
							if (methodToJump != null) {
								JavaUI.openInEditor(methodToJump);
								methodToJump = null;
							} else {
								new BehaviorSimpleDialog().show(BehaviorEditorPlugin.STEP_NOT_FOUND_TITLE, 
										BehaviorEditorPlugin.STEP_NOT_FOUND_MESSAGE + step);
							}
						} catch (Exception e) {
							throw new RuntimeException(e);
						}
					}
				};
				return new IHyperlink[]{ link };
			}
		} };
	}

	private RuleBasedScanner getDefaultScanner() {
		if (defaultScanner == null) {
			defaultScanner = new RuleBasedScanner();
			defaultScanner.setDefaultReturnToken(new Token(new TextAttribute(colorManager.getColor(Colors.DEFAULT))));
		}
		return defaultScanner;
	}

	protected RuleBasedScanner getGWZScanner() {
		if (gwzScanner == null) {
			gwzScanner = new RuleBasedScanner();
			gwzScanner.setDefaultReturnToken(new Token(new TextAttribute(colorManager.getColor(Colors.GWZ_KEYWORD))));
		}
		return gwzScanner;
	}

	public IPresentationReconciler getPresentationReconciler(ISourceViewer sourceViewer) {
		PresentationReconciler reconciler = new PresentationReconciler();

		DefaultDamagerRepairer dr = new DefaultDamagerRepairer(getDefaultScanner());
		reconciler.setDamager(dr, IDocument.DEFAULT_CONTENT_TYPE);
		reconciler.setRepairer(dr, IDocument.DEFAULT_CONTENT_TYPE);

		dr = new DefaultDamagerRepairer(getGWZScanner());
		reconciler.setDamager(dr, BehaviorPartitionScanner.GWZ);
		reconciler.setRepairer(dr, BehaviorPartitionScanner.GWZ);

		return reconciler;
	}

}