/*
 * (c) Copyright IBM Corp. 2000, 2001. All Rights Reserved.
 */
package org.eclipse.behavior.assist;

import org.eclipse.jface.text.BadLocationException;
import org.eclipse.jface.text.IDocument;
import org.eclipse.jface.text.contentassist.ICompletionProposal;
import org.eclipse.jface.text.contentassist.IContextInformation;
import org.eclipse.swt.graphics.Image;
import org.eclipse.swt.graphics.Point;

/**
 * A PHP identifier proposal.
 */
public class BehaviorStepProposal implements ICompletionProposal, Comparable<BehaviorStepProposal> {

	private final String fTemplate;
//	private final ResolvedSourceMethod method;
	private final int startOffset;
	private final int endOffset;

	/**
	 * Creates a template proposal with a template and its context.
	 * 
	 * @param template
	 *            the template
	 * @param context
	 *            the context in which the template was requested.
	 * @param image
	 *            the icon of the proposal.
	 */
	public BehaviorStepProposal(String template, int startOffset, int endOffset) {
		this.fTemplate = template;
		this.startOffset = startOffset;
		this.endOffset = endOffset;
	}

	/*
	 * @see ICompletionProposal#apply(IDocument)
	 */
	public void apply(IDocument document) {
		try {
			document.replace(this.startOffset, this.endOffset - this.startOffset, fTemplate);
		} catch (BadLocationException e) {

		}
	}

	/*
	 * @see ICompletionProposal#getSelection(IDocument)
	 */
	public Point getSelection(IDocument document) {
		// return new Point(fSelectedRegion.getOffset(), fSelectedRegion.getLength());
		return null;
	}

	/*
	 * @see ICompletionProposal#getAdditionalProposalInfo()
	 */
	public String getAdditionalProposalInfo() {
		return null;
	}

	/*
	 * @see ICompletionProposal#getDisplayString()
	 */
	public String getDisplayString() {
		return (fTemplate);
	}

	/*
	 * @see ICompletionProposal#getImage()
	 */
	public Image getImage() {
		return null;
	}

	/*
	 * @see ICompletionProposal#getContextInformation()
	 */
	public IContextInformation getContextInformation() {
		return null;
	}

	public int compareTo(BehaviorStepProposal o) {
		return o.getDisplayString().compareTo(this.getDisplayString());
	}

}