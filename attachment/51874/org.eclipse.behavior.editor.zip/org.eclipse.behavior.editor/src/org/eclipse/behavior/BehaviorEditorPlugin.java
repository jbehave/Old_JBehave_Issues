package org.eclipse.behavior;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import org.eclipse.core.runtime.IStatus;
import org.eclipse.core.runtime.Status;
import org.eclipse.jface.resource.ImageDescriptor;
import org.eclipse.swt.widgets.Shell;
import org.eclipse.ui.IWorkbench;
import org.eclipse.ui.IWorkbenchWindow;
import org.eclipse.ui.plugin.AbstractUIPlugin;
import org.osgi.framework.BundleContext;

import org.eclipse.behavior.properties.ClassPathPropertiesFile;

;
/**
 * The main plugin class to be used in the desktop.
 * 
 * @author florea
 */
public class BehaviorEditorPlugin extends AbstractUIPlugin {
	private static final String ID = "BehaviorEditorPlugin";
	// The shared instance.
	private static BehaviorEditorPlugin plugin;

	// properties file name
	private static final String PLUGIN_PROPERTIES = "plugin.properties";

	// properties separator
	private static final String PROPERTIES_SEPARATOR = ",";

	public static final String JAVA = "java";

	public static String SCENARIO_KEY_WORD = "";

	/**
	 * This prefix is used to compute properties for different version of BDD.
	 */
	public static String PROPERTIES_PREFIX = "org.eclipse.behavior.editor.";
	
	/**
	 * This suffix collection is used to compute properties for different version of BDD.
	 * Ex: JBehave.2.5, JBehave.3.0
	 */
	public static Set<String> TYPES = new HashSet<String>();
	
	/**
	 * This is argument separator. For JBehave is '$'
	 */
	public static String ARGUMENT_SEPARATOR = "";
	
	/**
	 * Using this character we can trigger the autocomplete functionality. Actualy we can use '?'
	 */
	public static String AUTOCOMPLETE_CHARACTER_TRIGGER = "";
	
	/**
	 * This list contains all annonation full name, which plugin works with. 
	 * Ex. JBehave 2.5.x - org.jbehave.scenario.annotations.Given 
	 *     JBehave 3.0 - org.jbehave.core.annotations.Given
	 */
	public static Set<String> ANNOTATIONS = new HashSet<String>();
	
	/**
	 * This list contains all annonation short name, which plugin works with. 
	 * Ex. Given, Then ..
	 */
	public static Set<String> ANNOTATIONS_SHORT_NAMES = new HashSet<String>();
	
	/**
	 * A reg ex based on annotations collection: .*(Aliases|Then|When|Given|Alias)
	 */
	public static String ANNOTATIONS_SHORT_NAMES_AS_REGEX = "";
	
	/**
	 * Key words used by the BDD framework. 
	 * For JBehave we should take into account: Given, When, Then, And 
	 */
	public static Set<String> KEY_WORDS = new HashSet<String>();
	
	/**
	 * Textual file extention: 
	 * JBehave 2.5.x - scenario
	 * JBehave 3.0 - story
	 */
	public static Set<String> SCENARIO_FILE_EXTENSIONS = new HashSet<String>();
	
	/**
	 * A reg ex used to take into account one textual file extention.
	 * Ex: .*.(story|scenario)
	 */
	public static String SCENARIO_FILE_EXTENSIONS_AS_REGEX = "";
	
	/**
	 * To optimize the search for java method algorithm we should take into account only some java class.
	 * For example we can search on in class which name ends with Step or Steps.
	 */
	public static Set<String> JAVA_STEPS = new HashSet<String>();
	public static String GO_TO_STEP = "";
	public static String CANNOT_LOCATE_STEP_TITLE = "";
	public static String CANNOT_LOCATE_STEP_MESSAGE = "";
	public static String STEP_NOT_FOUND_TITLE = "";
	public static String STEP_NOT_FOUND_MESSAGE = "";
	public static String NO_STEP_THAT_MATCHES = "";
	
	static {
		ClassPathPropertiesFile classPathPropertiesFile = new ClassPathPropertiesFile(
				PLUGIN_PROPERTIES);
		String propertyValue = null;
		propertyValue = classPathPropertiesFile.getProperty(PROPERTIES_PREFIX
				+ "types");
		if (propertyValue != null) {
			TYPES.addAll(removeTheWhiteSpaces(Arrays.asList(propertyValue.trim()
					.split(PROPERTIES_SEPARATOR))));
		}

		propertyValue = classPathPropertiesFile
				.getProperty("argument_separator");
		if (propertyValue != null) {
			ARGUMENT_SEPARATOR = propertyValue.trim();
		} else {
			ARGUMENT_SEPARATOR = "";
		}
		propertyValue = classPathPropertiesFile
				.getProperty("autocomplete_character_trigger");
		if (propertyValue != null) {
			AUTOCOMPLETE_CHARACTER_TRIGGER = propertyValue.trim();
		}
		propertyValue = classPathPropertiesFile
				.getProperty("scenario_key_word");
		if (propertyValue != null) {
			SCENARIO_KEY_WORD = propertyValue.trim();
		}

		for (String type : TYPES) {
			propertyValue = classPathPropertiesFile
					.getProperty((PROPERTIES_PREFIX + type + ".annotations").toString());
			if (propertyValue != null) {
				ANNOTATIONS.addAll(removeTheWhiteSpaces(Arrays
						.asList(propertyValue.trim()
								.split(PROPERTIES_SEPARATOR))));
			}

			propertyValue = classPathPropertiesFile
					.getProperty((PROPERTIES_PREFIX + type
							+ ".annotations_short_names").toString());
			if (propertyValue != null) {
				ANNOTATIONS_SHORT_NAMES.addAll(removeTheWhiteSpaces(Arrays
						.asList(propertyValue.trim()
								.split(PROPERTIES_SEPARATOR))));
			}

			propertyValue = classPathPropertiesFile
					.getProperty((PROPERTIES_PREFIX + type + ".key_words").toString());
			if (propertyValue != null) {
				KEY_WORDS.addAll(removeTheWhiteSpaces(Arrays
						.asList(propertyValue.trim()
								.split(PROPERTIES_SEPARATOR))));
			}

			propertyValue = classPathPropertiesFile
					.getProperty((PROPERTIES_PREFIX + type + ".java_step_pattern").toString());
			if (propertyValue != null) {
				JAVA_STEPS.addAll(removeTheWhiteSpaces(Arrays.asList(propertyValue
						.trim().split(PROPERTIES_SEPARATOR))));
			}
			
			propertyValue = classPathPropertiesFile
			.getProperty((PROPERTIES_PREFIX + type + ".scenario_file_extension").toString());
			if (propertyValue != null) {
				SCENARIO_FILE_EXTENSIONS.addAll(removeTheWhiteSpaces(Arrays
						.asList(propertyValue.trim().split(PROPERTIES_SEPARATOR))));
			}
		}

		ANNOTATIONS_SHORT_NAMES_AS_REGEX = ".*(";
		Object[] arr = ANNOTATIONS_SHORT_NAMES.toArray();
		for (int i = 0; i < arr.length; i++) {
			ANNOTATIONS_SHORT_NAMES_AS_REGEX += arr[i].toString().trim();
			if (i < arr.length - 1) {
				ANNOTATIONS_SHORT_NAMES_AS_REGEX += "|";
			}
		}
		ANNOTATIONS_SHORT_NAMES_AS_REGEX += ")";

		
		SCENARIO_FILE_EXTENSIONS_AS_REGEX = ".*.(";
		arr = SCENARIO_FILE_EXTENSIONS.toArray();
		for (int i = 0; i < arr.length; i++) {
			SCENARIO_FILE_EXTENSIONS_AS_REGEX += arr[i].toString().trim();
			if (i < arr.length - 1) {
				SCENARIO_FILE_EXTENSIONS_AS_REGEX += "|";
			}
		}
		SCENARIO_FILE_EXTENSIONS_AS_REGEX += ")";

		propertyValue = classPathPropertiesFile.getProperty("go_to_step");
		if (propertyValue != null) {
			GO_TO_STEP = propertyValue.trim();
		}
		propertyValue = classPathPropertiesFile
				.getProperty("cannot_locate_step_title");
		if (propertyValue != null) {
			CANNOT_LOCATE_STEP_TITLE = propertyValue.trim();
		}
		propertyValue = classPathPropertiesFile
				.getProperty("cannot_locate_step_message");
		if (propertyValue != null) {
			CANNOT_LOCATE_STEP_MESSAGE = propertyValue.trim();
		}
		propertyValue = classPathPropertiesFile
				.getProperty("step_not_found_title");
		if (propertyValue != null) {
			STEP_NOT_FOUND_TITLE = propertyValue.trim();
		}
		propertyValue = classPathPropertiesFile
				.getProperty("step_not_found_message");
		if (propertyValue != null) {
			STEP_NOT_FOUND_MESSAGE = propertyValue.trim();
		}
		propertyValue = classPathPropertiesFile
				.getProperty("no_step_that_matches");
		if (propertyValue != null) {
			NO_STEP_THAT_MATCHES = propertyValue.trim();
		}
	}

	private static List<String> removeTheWhiteSpaces(List<String> original) {
		List<String> after = new ArrayList<String>();
		for (String key : original) {
			after.add(key.trim());
		}
		return after;
	}

	/**
	 * The constructor.
	 */
	public BehaviorEditorPlugin() {
		plugin = this;
	}

	/**
	 * This method is called upon plug-in activation
	 */
	public void start(BundleContext context) throws Exception {
		super.start(context);
	}

	/**
	 * This method is called when the plug-in is stopped
	 */
	public void stop(BundleContext context) throws Exception {
		super.stop(context);
		plugin = null;
	}

	/**
	 * Returns the shared instance.
	 */
	public static BehaviorEditorPlugin getDefault() {
		return plugin;
	}

	/**
	 * Returns an image descriptor for the image file at the given plug-in
	 * relative path.
	 * 
	 * @param path
	 *            the path
	 * @return the image descriptor
	 */
	public static ImageDescriptor getImageDescriptor(String path) {
		return AbstractUIPlugin.imageDescriptorFromPlugin(ID, path);
	}

	public static void log(Throwable e) {
		log(new Status(IStatus.ERROR, ID, IStatus.ERROR, "Error", e)); //$NON-NLS-1$
	}

	public static void log(IStatus status) {
		getDefault().getLog().log(status);
	}

	public static Shell getActiveWorkbenchShell() {
		IWorkbenchWindow workBenchWindow = getActiveWorkbenchWindow();
		if (workBenchWindow == null)
			return null;
		return workBenchWindow.getShell();
	}

	/**
	 * Returns the active workbench window
	 * 
	 * @return the active workbench window
	 */
	public static IWorkbenchWindow getActiveWorkbenchWindow() {
		if (plugin == null)
			return null;
		IWorkbench workBench = plugin.getWorkbench();
		if (workBench == null)
			return null;
		return workBench.getActiveWorkbenchWindow();
	}

}
