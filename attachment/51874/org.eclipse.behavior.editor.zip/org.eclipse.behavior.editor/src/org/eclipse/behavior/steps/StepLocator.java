package org.eclipse.behavior.steps;

import java.util.Iterator;
import java.util.Map.Entry;

import org.eclipse.behavior.builder.BehaviorNature;
import org.eclipse.core.resources.IProject;
import org.eclipse.jdt.internal.core.ResolvedSourceMethod;

public class StepLocator {

    public ResolvedSourceMethod findMethod(String step, IProject project) {
    	
    		if(BehaviorNature.getCache().get(project) == null){
    			BehaviorNature.initiateProjectCache(project);
    		}
    		Iterator<Entry<String, ResolvedSourceMethod>> it =   BehaviorNature.getCache().get(project).entrySet().iterator();
    		while(it.hasNext()){
    			Entry<String, ResolvedSourceMethod> entry = it.next();
    			if (step.matches(entry.getKey())) {
    				return entry.getValue();
    			}
    		}
    		return null;
    }
}