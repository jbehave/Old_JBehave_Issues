package org.eclipse.behavior.editor;

import org.eclipse.behavior.BehaviorEditorPlugin;
import org.eclipse.jface.text.rules.*;

public class BehaviorPartitionScanner extends RuleBasedPartitionScanner {
	public final static String GWZ = "__gwz";

	public BehaviorPartitionScanner() {

		IToken gwz = new Token(GWZ);

		if (BehaviorEditorPlugin.KEY_WORDS != null) {
			IPredicateRule[] rules = new IPredicateRule[BehaviorEditorPlugin.KEY_WORDS
					.size()];
			Object[] array = BehaviorEditorPlugin.KEY_WORDS.toArray();
			for (int i = 0; i < array.length; i++) {
				rules[i] = new SingleLineRule(array[i].toString().trim(),
						" ", gwz);
			}
			setPredicateRules(rules);
		}
	}
}
