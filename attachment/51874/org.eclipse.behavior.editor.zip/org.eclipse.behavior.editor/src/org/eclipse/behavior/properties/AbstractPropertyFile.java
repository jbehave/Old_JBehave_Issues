package org.eclipse.behavior.properties;

import java.util.*;

public abstract class AbstractPropertyFile implements PropertiesFile {
	
	private Properties innerPropertyFile = null;

	public AbstractPropertyFile() {
		innerPropertyFile = null;
	}
	
	protected Properties getPropertyFile() {
		return innerPropertyFile;
	}

	protected void setPropertyFile(Properties file) {
			innerPropertyFile = file;
	}

	public Map getAllProperties() {
		if(innerPropertyFile == null){
			return null;
		}
		Map result = new HashMap();
		if (innerPropertyFile.entrySet().size() == 0) {
		} else {
			java.util.Map.Entry currentProperty;
			for (Iterator ite = innerPropertyFile.entrySet().iterator(); ite
					.hasNext(); result.put((String) currentProperty.getKey(),
					(String) currentProperty.getValue())) {
				currentProperty = (java.util.Map.Entry) ite.next();
			}

		}
		return result;
	}

	public String getProperty(String pKey) {
		if(innerPropertyFile == null){
			return null;
		}
		if (innerPropertyFile.containsKey(pKey)) {
			return innerPropertyFile.getProperty(pKey).trim();
		}
		return null;
	}

}
