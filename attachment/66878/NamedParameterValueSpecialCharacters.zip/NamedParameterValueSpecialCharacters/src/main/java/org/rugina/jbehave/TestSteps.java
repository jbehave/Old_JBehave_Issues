package org.rugina.jbehave;

import org.jbehave.core.annotations.Given;
import org.jbehave.core.annotations.Named;
import org.jbehave.core.annotations.Then;
import org.jbehave.core.annotations.When;
import org.jbehave.core.model.ExamplesTable;
import org.junit.Assert;

public class TestSteps {
    static String originalText;

    @Given("the text $textTable")
    public void givenTheText(@Named("textTable") final ExamplesTable table) {
        TestSteps.originalText = table.getRowAsParameters(0, true).values().get("Value");
    }

    @When("are used named parameters")
    public void whenAreUsedNamedParameters() {

    }

    @Then("text differs from the expected value '$value'")
    public void thenTheTextDiffersFromTheExpectedValue(@Named("value") final String modifiedText) {
        Assert.assertEquals(TestSteps.originalText, modifiedText);
    }

}
