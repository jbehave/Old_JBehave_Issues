import org.jbehave.core.annotations.When;

public class MySteps {
	@When("I foo")
	public void foo() throws InterruptedException {
		Thread.sleep(1000);
		System.out.println("foo!");
	}
}
