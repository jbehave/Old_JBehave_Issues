import static org.jbehave.core.reporters.Format.STATS;

import java.util.Arrays;
import java.util.List;

import org.jbehave.core.configuration.MostUsefulConfiguration;
import org.jbehave.core.embedder.Embedder;
import org.jbehave.core.junit.JUnitStories;
import org.jbehave.core.reporters.StoryReporterBuilder;
import org.jbehave.core.steps.InjectableStepsFactory;
import org.jbehave.core.steps.InstanceStepsFactory;

// my.stats duration value is incorrect
public class MyJBehaveTest extends JUnitStories {
	public MyJBehaveTest() {
		Embedder embedder = configuredEmbedder();
		embedder.embedderControls().useThreads(2); // changing threads to 1 makes the duration value correct
		
		useConfiguration(new MostUsefulConfiguration()
			.useStoryReporterBuilder(new StoryReporterBuilder().withFormats(STATS)));
	}
	
	@Override
	public InjectableStepsFactory stepsFactory() {
		return new InstanceStepsFactory(configuration(), new MySteps());
	}
	
	@Override
	protected List<String> storyPaths() {
		return Arrays.asList("my.story");
	}
}
