import org.jbehave.scenario.annotations.AfterScenario;
import org.jbehave.scenario.annotations.BeforeScenario;
import org.jbehave.scenario.annotations.Given;
import org.jbehave.scenario.annotations.When;
import org.jbehave.scenario.annotations.Then;
import com.thoughtworks.selenium.SeleneseTestCase;
import com.thoughtworks.selenium.Wait;


public class LoginSteps extends SeleneseTestCase {
    
	private SystemUnderTest system;
	
	@BeforeScenario
	public void startSystem1() throws Exception {
	   system = new SystemUnderTest();
	   system.start();
	}

	@AfterScenario
	public void stopSystem1() throws Exception {
	    SystemUnderTest.selenium.stop();
	    system.stop();
	}
	
    @Given("I am on the epson homepage")
     public void goEpsonHome1() {
    	SystemUnderTest.selenium.open("/");
    	SystemUnderTest.selenium.setSpeed(SystemUnderTest.SPEED);
    }
 
    @When("I log in as $username with a password $password")
    public void login1(String username, String password) throws Exception {
		SystemUnderTest.selenium.click("xpath=//div[@id='UserLinks']/form/ul/li[2]/a");
		new Wait("Couldn't find the login button!") {
		    public boolean until() {
		        return SystemUnderTest.selenium.isElementPresent("//div[@id='Popup']/div/div/p");
		    }
		};
		SystemUnderTest.selenium.type("f_email_id", username);
		SystemUnderTest.selenium.type("f_pwd", password);
		SystemUnderTest.selenium.click("/atg/userprofiling/ProfileFormHandler.login");
		SystemUnderTest.selenium.waitForPageToLoad("30000");
    }
 
    @Then("I should see a Hello message")
    public void checkLogin1() {
    	assertEquals(SystemUnderTest.hiMessage+"Tom", SystemUnderTest.selenium.getText("xpath=//div[@id='UserLinks']/form/ul/li[2]/a"));
    }
}
