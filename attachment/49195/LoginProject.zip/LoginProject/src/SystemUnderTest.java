import java.io.FileInputStream;
import java.util.Properties;
import com.thoughtworks.selenium.Selenium;
import com.thoughtworks.selenium.DefaultSelenium;
import org.openqa.selenium.server.SeleniumServer;


public class SystemUnderTest {
  
   /*Suggested servers are "www" for the live site or "qa" for the quality 
    * assurance site*/
   public static String SERVER;
  
   /*Suggested domains include "co.uk"(UK), "it" (Italy), "es" (Spain), 
	"fr" (France), "pt" (Portugal)*/
   public static String DOMAIN;
   
   //The variables defined in the domain properties files
   public static String welcomeMessage, hiMessage;
   
   //The Base URL is not composed of the previous settings
   public static String BASEURL;
   
   //The speed at which the tests run in  milliseconds per action
   public static String SPEED = "500";
   
   //The Selenium client and server objects
   public static Selenium selenium;
   private SeleniumServer seleniumServer;

   public void start() throws Exception {
	   	//Open up the base properties file	
	   	Properties defaultProps = new Properties();
		FileInputStream in = new FileInputStream("base.properties");
		defaultProps.load(in);
		in.close();
	   
		//Set the base global properties
		DOMAIN = defaultProps.getProperty("DOMAIN");
		SERVER = defaultProps.getProperty("SERVER");
		BASEURL = new String("http://"+SERVER+".epson."+DOMAIN);
		SPEED = defaultProps.getProperty("SPEED");
		
		//Start the Selenium Server
		selenium = new DefaultSelenium("localhost", 4444, "*firefox", BASEURL);
		seleniumServer = new SeleniumServer();
		seleniumServer.start();
		selenium.start();
      
		// Load in the properties of the correct domain
		in = new FileInputStream(DOMAIN+".properties");
		defaultProps.load(in);
		in.close();
		
		//Save the variables to the global config variables
		welcomeMessage = defaultProps.getProperty("welcomeMessage");
		hiMessage = defaultProps.getProperty("hiMessage");
	}

   public void stop() {
      selenium.stop();
      seleniumServer.stop();
   }

   public void open(String url) {
      selenium.open(url);
   }
}
