package org.jbehave.core.steps;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * <p>
 * Simple implementation for building a set of permutations of given String that
 * may contain special patterns. Depending on the patterns present, one or more
 * resulting Strings are created.
 * </p>
 * <p>
 * Currently supported patterns are
 * </p>
 * <table border="1">
 * <thead>
 * <tr>
 * <td>Pattern</td>
 * <td>Result</td>
 * </tr>
 * </thead> <tbody>
 * <tr>
 * <td>..A {x|y} B..</td>
 * <td>
 * <ul>
 * <li>..A x B..</li>
 * <li>..A y B..</li>
 * </ul>
 * </td>
 * </tr>
 * <tr>
 * <td>..A {x|y|} B..</td>
 * <td>
 * <ul>
 * <li>..A x B..</li>
 * <li>..A y B..</li>
 * <li>..A B..</li>
 * </ul>
 * </td>
 * </tr>
 * <tr>
 * <td>..A {x} B..</td>
 * <td>
 * <ul>
 * <li>..A x B..</li>
 * </ul>
 * </td>
 * </tr>
 * </table>
 * 
 * <p>
 * These patterns can be used to conveniently create several permutations of a
 * step, without having to repeat it as a whole as one or more aliases.
 * </p>
 * <p>
 * Examples:
 * </p>
 * <ul>
 * <li>
 * <p>
 * <code>
 * 
 * @Then("the result {must |has to |}be $x")<br> public void checkResult(int
 *            x)...<br></code>
 *            </p>
 *            <p>
 *            Would match any of these variants from a story file:
 *            <ul>
 *            <li>Then the result must be 42</li> <li>Then the result has to be
 *            42</li> <li>Then the result be 42</li>
 *            </ul>
 *            </p>
 *            </li> <li>
 *            <p>
 *            <code>
 * @When("$A {+|plus|is added to} $B")<br> public void add(int A, int B)...<br>
 *           </code>
 *           </p>
 *           <p>
 *           Would match any of these variants from a story file:
 *           <ul>
 *           <li>When 42 + 23</li> <li>When 42 plus 23</li> <li>When 42 is added
 *           to 23</li>
 *           </ul>
 *           </p>
 *           </li>
 *           </ul>
 * 
 * @author Daniel Schneller
 * 
 */
public class StepsPermutationBuilder {

	// private final String input;
	private final Set<String> permutations;

	/**
	 * Regular expression that locates patterns to be evaluated in the input
	 * string. </p>
	 */
	private final Pattern regex = Pattern
			.compile("(.*?)?(\\{((.*?)(\\|)?)*?\\})(.*)");

	/**
	 * Creates a permutation builder and calculates all permutations for later
	 * use. When there are no patterns found in the string, it will itself be
	 * the only result.
	 * 
	 * @param string
	 *            to be evaluated
	 */
	public StepsPermutationBuilder(String string) {
		// this.input = string;
		permutations = generatePermutations(string);
	}

	/**
	 * <p>
	 * Parses the {@link #input} received at construction and generates the
	 * permutations. When there are multiple patterns in the input, the method
	 * will recurse on itself to generate the permutations for the tailing end
	 * after the first matched pattern.
	 * </p>
	 * <p>
	 * Generated permutations are stored in a {@link Set}, so there will never
	 * be any duplicates, even if the input's patterns were to result in such.
	 * </p>
	 * 
	 */
	private Set<String> generatePermutations(String input) {
		// Store current invocation's results
		Set<String> variants = new HashSet<String>();

		Matcher m = regex.matcher(input);
		boolean matches = m.matches();

		if (!matches) {
			// if the regex does not find any patterns,
			// simply add the input as is
			variants.add(input);
			// end recursion
			return variants;
		}

		// isolate the part before the first pattern
		String head = m.group(1);

		// isolate the pattern itself, removing its wrapping {}
		String patternGroup = m.group(2).replaceAll("[\\{\\}]", "");

		// isolate the remaining part of the input
		String tail = m.group(6);

		// split the pattern into its options and add an empty
		// string if it ends with a separator
		String[] tmp = patternGroup.split("\\|");
		List<String> split = new ArrayList<String>();
		split.addAll(Arrays.asList(tmp));
		if (patternGroup.endsWith("|")) {
			split.add("");
		}

		// Iterate over the current pattern's
		// variants and construct the result.
		for (String s : split) {
			StringBuilder b = new StringBuilder();
			if (head != null) {
				b.append(head);
			}
			b.append(s);

			// recurse on the tail of the input
			// to handle the next pattern
			Set<String> tails = generatePermutations(tail);

			// append all permutations of the tail end
			// and add each of them to the part we have
			// built up so far.
			for (String tailPermutation : tails) {
				StringBuilder b2 = new StringBuilder(b.toString());
				b2.append(tailPermutation);
				variants.add(b2.toString());
			}
		}
		return variants;
	}

	/**
	 * <p>
	 * Returns the number of permutations available, assuming no white space
	 * compression.
	 * </p>
	 * @return the number of permutations
	 */
	public int numberOfPermutations() {
		return numberOfPermutations(false);
	}

	/**
	 * <p>
	 * Returns the number of permutations available, assuming white space
	 * compression if <code>true</code> is passed. 
	 * </p>
	 * @return the number of permutations
	 */
	public int numberOfPermutations(boolean compressWhitespace) {
		if (!compressWhitespace) {
			return permutations.size();
		} else {
			return allPermutations(true).size();
		}
	}

	/**
	 * Returns a new copy of the internal set of all permutations. There will be
	 * no whitespace compression.
	 * 
	 * @return a {@link Set} of all permutations without whitespace compression
	 * @see #allPermutations(boolean)
	 */
	public Set<String> allPermutations() {
		return allPermutations(false);
	}

	/**
	 * <p>
	 * Returns a new copy of the internal set of all permutations. Any two or
	 * more consecutive white space characters will be condensed into a single
	 * space, if <code>true</code> is passed. This compression can lead to a
	 * reduction of the Set's size!
	 * </p>
	 * <p>
	 * Otherwise, any whitespace will be left as is.
	 * </p>
	 * 
	 * @param compressWhitespace
	 *            whether or not to compress whitespace
	 * @return a {@link Set} of all permutations
	 * @see #allPermutations(boolean)
	 */
	public Set<String> allPermutations(boolean compressWhitespace) {
		if (!compressWhitespace) {
			return new HashSet<String>(permutations);
		}
		Set<String> compressed = new HashSet<String>(numberOfPermutations());
		for (String s : permutations) {
			compressed.add(s.replaceAll("\\s{2,}", " "));
		}
		return compressed;
	}

}
