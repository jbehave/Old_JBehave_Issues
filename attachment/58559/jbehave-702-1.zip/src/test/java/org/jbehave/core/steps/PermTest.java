package org.jbehave.core.steps;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;

import java.util.Set;

import org.jbehave.core.steps.StepsPermutationBuilder;
import org.junit.Test;

public class PermTest {
	StepsPermutationBuilder perm;

	@Test
	public void shouldReturnItselfForNoPatternString() {
		StepsPermutationBuilder perm = new StepsPermutationBuilder("No placeholders");
		assertEquals("No placeholders", perm.allPermutations().iterator().next());
	}

	@Test
	public void shouldReturnnumberOfPermutations1ForNoPatternsString() {
		StepsPermutationBuilder perm = new StepsPermutationBuilder("No placeholders");
		assertEquals(1, perm.numberOfPermutations());
	}

	@Test
	public void shouldReturn2VariantsForOnePattern() {
		StepsPermutationBuilder perm = new StepsPermutationBuilder("There are {Two|One} variants");
		assertEquals(2, perm.numberOfPermutations());
		Set<String> result = perm.allPermutations();
		assertTrue(result.contains("There are One variants"));
		assertTrue(result.contains("There are Two variants"));
	}

	@Test
	public void shouldReturn4VariantsForTwoPatterns() {
		StepsPermutationBuilder perm = new StepsPermutationBuilder("There are {Two|One} variants, {hooray|alas}!");
		assertEquals(4, perm.numberOfPermutations());
		Set<String> result = perm.allPermutations();
		assertTrue(result.contains("There are One variants, hooray!"));
		assertTrue(result.contains("There are Two variants, hooray!"));
		assertTrue(result.contains("There are One variants, alas!"));
		assertTrue(result.contains("There are Two variants, alas!"));
	}

	@Test
	public void shouldReturn4VariantsForTwoPatternsWithOptionElements() {
		StepsPermutationBuilder perm = new StepsPermutationBuilder("There are {One|} variants{, hooray|}!");
		assertEquals(4, perm.numberOfPermutations());
		Set<String> result = perm.allPermutations();
		assertTrue(result.contains("There are One variants, hooray!"));
		assertTrue(result.contains("There are  variants, hooray!"));
		assertTrue(result.contains("There are One variants!"));
		assertTrue(result.contains("There are  variants!"));
	}

	@Test
	public void shouldReturn4VariantsForTwoPatternsWithOptionElementsWithWhitespaceCompression() {
		StepsPermutationBuilder perm = new StepsPermutationBuilder("There are {One|} variants{, hooray|}!");
		assertEquals(4, perm.numberOfPermutations());
		Set<String> result = perm.allPermutations(true); // collapse whitespaces to 1
		assertTrue(result.contains("There are One variants, hooray!"));
		assertTrue(result.contains("There are variants, hooray!"));
		assertTrue(result.contains("There are One variants!"));
		assertTrue(result.contains("There are variants!"));
	}
	
	@Test
	public void shouldHandleSpecialCharacters() {
		StepsPermutationBuilder perm = new StepsPermutationBuilder("When $A {+|plus|is added to} $B");
		assertEquals(3, perm.numberOfPermutations());
		Set<String> result = perm.allPermutations();
		assertTrue(result.contains("When $A + $B"));
		assertTrue(result.contains("When $A plus $B"));
		assertTrue(result.contains("When $A is added to $B"));
	}

}
