package com.foo.embalajemadera.server.servicios.impl;


import java.util.List;

import org.springframework.stereotype.Service;

import com.foo.embalajemadera.server.servicios.IProvinciaService;
import com.foo.embalajemadera.shared.domain.Provincia;


@Service
public class ProvinciaServicesImpl implements IProvinciaService {

	@Override
	public Provincia findById(Integer id) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Provincia save(Provincia p) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<Provincia> findByName(String name) {
		// TODO Auto-generated method stub
		return null;
	}



}
