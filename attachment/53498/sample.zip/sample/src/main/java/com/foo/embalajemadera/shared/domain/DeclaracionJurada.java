package com.foo.embalajemadera.shared.domain;


/**
 * Entidad que representa las declaraciones juradas
 * 
 * @author Gardella Juan Pablo - gardellajuanpablo@gmail.com
 * @since 0.1.0
 * 
 */
public class DeclaracionJurada  {

	
	private static final long serialVersionUID = 1L;
	
	private Long id;
	
	public DeclaracionJurada() {
		super();
		// POJO constructor
	}

	public void setId(Long id) {
		this.id = id;
	}

	
	public Long getId() {
		return id;
	}

}
