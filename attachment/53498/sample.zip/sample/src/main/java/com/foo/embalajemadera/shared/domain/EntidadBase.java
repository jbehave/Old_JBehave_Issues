package com.foo.embalajemadera.shared.domain;

import java.io.Serializable;

/**
 * 
 * Entidad base. 
 * 
 * @author Gardella Juan Pablo - gardellajuanpablo@gmail.com
 * @since 0.1.0
 */

public abstract class EntidadBase implements Serializable {

	private static final long serialVersionUID = 1L;	

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result
				+ ((getId() == null) ? super.hashCode() : getId().hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		// FIXME: El equals debe comparar ademas la clase real.
		// Se deja asi porque en general no se van a comparar clases diferentes.
		// Comunmente se usa en List.indexof.
		if (!(obj instanceof EntidadBase))
			return false;
		EntidadBase other = (EntidadBase) obj;
		if (getId() == null) {
			if (other.getId() != null)
				return false;
		} else if (!getId().equals(other.getId()))
			return false;
		return true;
	}

	public abstract Serializable getId();

}
