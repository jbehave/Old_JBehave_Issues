package com.foo.embalajemadera.historias;

import java.util.List;

import org.jbehave.core.configuration.Configuration;
import org.jbehave.core.junit.JUnitStory;
import org.jbehave.core.steps.CandidateSteps;
import org.jbehave.core.steps.spring.SpringApplicationContextFactory;
import org.jbehave.core.steps.spring.SpringStepsFactory;
import org.junit.Before;
import org.junit.Test;
import org.springframework.context.ApplicationContext;

public class Cu9RechazarDeclaracionJurada extends JUnitStory {

	private List<CandidateSteps> steps;

	@Before
	public void inicializar() {
		steps = createSteps(configuration());
		System.out.println(steps.size());

	}

	@Test
	@Override
	public void run() throws Throwable {
		super.run();
	}

	@Override
	public List<CandidateSteps> candidateSteps() {
		if (steps == null) {
			steps = createSteps(configuration());
			System.out.println(steps.size());
		}

		return steps;
	}

	protected List<CandidateSteps> createSteps(Configuration configuration) {
		ApplicationContext context = createContext();
		return new SpringStepsFactory(configuration, context)
				.createCandidateSteps();
	}

	private ApplicationContext createContext() {
		return new SpringApplicationContextFactory("/applicationContext.xml",
				"/steps/cu9-steps.xml").createApplicationContext();
	}

}
