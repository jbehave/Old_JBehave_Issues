package com.foo.embalajemadera.historias.steps;


import javax.inject.Inject;

import org.jbehave.core.annotations.Given;
import org.jbehave.core.annotations.Then;
import org.jbehave.core.annotations.When;

import com.foo.embalajemadera.server.servicios.IProvinciaService;

public class CU9RechazarDDJJStepPrueba { // Look, Ma', I'm a POJO!

	@Inject
	IProvinciaService service;

	@Given("un Inspector $inspectorId que accede al sistema por medio de un $usuario/Clave personal e intransferible.")
	public void elInspectorIngresoExitosamente(String inspectorId,
			String usuario) {
	System.out.println(service.toString());
		System.out.println(inspectorId + ":" + usuario);
	}

	@When("elige la opcion \"Rechazar DDJJ\" y selecciona la DDJJ $ddjj")
	public void elInspectorIngresoExitosamente(String ddjj) {
		System.out.println(ddjj);
	}

	@Then("Se incorpora la Fecha de Rechazo")
	public void a() {
		System.out.println("a()");
	}

	@Then("Estado=\"Rechazada\"")
	public void b() {
		System.out.println("b()");
	}

	@Then("Observa_Estado=\"Sin ingreso de embalaje\"")
	public void d() {
		System.out.println("d()");
	}

	@Then("se informa a la Aduana que la DDJJ no ingresa al pais")
	public void e() {
		System.out.println("e()");
	}

	@Then("Se genera el Formulario  de intercepci�n y Acta?????")
	public void f() {
		System.out.println("f()");
	}

}