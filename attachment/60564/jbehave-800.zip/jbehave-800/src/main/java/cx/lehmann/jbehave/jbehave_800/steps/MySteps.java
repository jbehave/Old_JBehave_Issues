package cx.lehmann.jbehave.jbehave_800.steps;

import org.jbehave.core.annotations.Alias;
import org.jbehave.core.annotations.Given;
import org.jbehave.core.annotations.Pending;
import org.jbehave.core.annotations.Then;
import org.jbehave.core.annotations.When;
import org.jbehave.core.annotations.Named;

public class MySteps {
	@Then("string is <str>")
	@Alias("string is \"$str\"")
	public void thenStringIsExampleString(@Named("str")String str) {
		System.out.println("actual parameter "+str);
	}
}
