package pl.mmadej.jbehave.steps;

import junit.framework.Assert;
import org.jbehave.core.annotations.AfterStory;
import org.jbehave.core.annotations.BeforeStory;
import org.jbehave.core.annotations.Given;
import org.jbehave.core.annotations.Then;
import org.jbehave.core.annotations.When;

public class RunWithNoReplacementSteps{

    @Given("a configuration file:$configuration")
    public void configurationFileIsCreated(String configuration){
        System.out.println("CONF FILE CREATED  : ");
        System.out.println(configuration);
    }

    @Given("template $templateFilename:$template")
    public void templateFileIsCreated(String templateFilename, String template){
        System.out.println("TEMPLATE FILE CREATED : "+ templateFilename +": ");
        System.out.println(template);
    }

    @When("runner is invoked with configuration file as argument")
    public void runnerIsInvoked(){
        System.out.println("RUNNER IS INVOKED !");
    }

    @Then("$destination contains $amount messages")
    public void destinationShouldContainMessages(String destination, int amount){
        System.out.println("VALIDATING DESTINATION AND AMOUNT !");
    }

    @Then("each message is compliant with the template")
    public void messagesShouldBeCompliantWithTemplate(){
        System.out.println("VALIDATING MESSAGES COMPLIANCE !");
    }
    
}
