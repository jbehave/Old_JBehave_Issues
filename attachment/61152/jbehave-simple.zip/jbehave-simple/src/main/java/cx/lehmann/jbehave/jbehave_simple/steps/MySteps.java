package cx.lehmann.jbehave.jbehave_simple.steps;

public class MySteps {
}
