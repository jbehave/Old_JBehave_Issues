package com;

import org.apache.log4j.Logger;
import org.jbehave.core.configuration.Configuration;
import org.jbehave.core.configuration.MostUsefulConfiguration;
import org.jbehave.core.embedder.Embedder;
import org.jbehave.core.io.LoadFromClasspath;
import org.jbehave.core.junit.JUnitStories;
import org.jbehave.core.reporters.CrossReference;
import org.jbehave.core.reporters.Format;
import org.jbehave.core.reporters.StoryReporterBuilder;
import org.jbehave.core.steps.InjectableStepsFactory;
import org.jbehave.core.steps.InstanceStepsFactory;
import org.jbehave.core.steps.ParameterControls;
import org.junit.Test;

import java.util.Arrays;
import java.util.List;
import java.util.Properties;

/**
 * This Stories class can contain all BDD stories about profile.
 */
public class ProfileStories extends JUnitStories {

    private static final Logger logger = Logger.getLogger(ProfileStories.class);

    @Override
    public InjectableStepsFactory stepsFactory() {
        return new InstanceStepsFactory(configuration(), new Story1Steps());
    }

    protected List<String> storyPaths() {
        return Arrays.asList("story1.story");
    }

    @Override
    @Test
    public void run() throws Throwable {
        Embedder embedder = configuredEmbedder();
        String meta = System.getProperty("meta");
        if (meta != null && meta.length() > 0) {
            List<String> ms = Arrays.asList(meta.split(","));
            for (String m: ms) {
                logger.info("filter by meta [" + m + "]");
            }
            embedder.useMetaFilters(ms);
        }
        // below is from JUnitStories
        try {
            embedder.runStoriesAsPaths(storyPaths());
        } finally {
            embedder.generateCrossReference();
        }
    }

    /**
     * Set up configuration. Can also use @Configure annotation with pre-defined classes.
     * @return configuration
     */
    @Override
    public Configuration configuration() {
        return new MostUsefulConfiguration().useStoryLoader(
                new LoadFromClasspath(this.getClass())
        ).useStoryReporterBuilder(
                new StoryReporterBuilder().withDefaultFormats().
                        withFormats(Format.CONSOLE, Format.HTML, Format.TXT, Format.XML).withViewResources(new Properties()).
                        withCrossReference(new CrossReference()) // use xref to generate json for future UI to consume
        ).useParameterControls(new ParameterControls().useDelimiterNamedParameters(true));
        // the last part is to simplify textual steps matching
    }

}
