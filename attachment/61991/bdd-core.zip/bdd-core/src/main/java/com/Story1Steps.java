package com;

import org.jbehave.core.annotations.Given;
import org.jbehave.core.annotations.Then;
import org.jbehave.core.annotations.When;

import static org.junit.Assert.assertEquals;

/**
 * Document me.
 */
public class Story1Steps {

    @Given("a user")
    public void setUser() {
        assertEquals("user", "user");
    }

    @When("he is asked to download jbehave")
    public void downloadJbehave() {
        assertEquals("jbehave", "jbehave");
    }

    @Then("he should know how to do it")
    public void isDownloaded() {
        assertEquals("downloaded", "downloaded");
    }

}
