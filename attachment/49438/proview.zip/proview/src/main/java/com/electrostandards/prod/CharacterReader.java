package com.electrostandards.prod;

import java.awt.Component;

import javax.swing.JTextField;

import org.lunivore.tyburn.actors.Focuser;


public class CharacterReader {
	
    private Focuser focuser;

    public CharacterReader() {
        focuser = new Focuser(null);
    }
    
    public String readFromComponent(Component component){

    	focuser.requestFocusOn(component);
        
        if (component instanceof JTextField) {
        	
        	
            return ((JTextField) component).getText();
        		
        	
        }
        else{
        	
            return null;
        }
    }
}