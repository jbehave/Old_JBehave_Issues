package com.electrostandards.prod;

public class App{
	
    public static void main( String[] args ){
        
    	ProViewApp.getProViewApp();
    }
}
