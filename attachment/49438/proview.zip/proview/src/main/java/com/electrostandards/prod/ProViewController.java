package com.electrostandards.prod;

public class ProViewController {

	private static ProViewController proViewController;
	private String mode;
	
	/**
	 * This is the default constructor
	 */
	private ProViewController() {
	}
	
	public static synchronized ProViewController getProViewController(){
		if (proViewController == null){
			proViewController = new ProViewController();
		}
		
		return proViewController;
	}
	
	public Object clone() throws CloneNotSupportedException {
		throw new CloneNotSupportedException();
	}

	public void setMode(String mode) {
		this.mode = mode;
	}

	public String getMode() {
		return mode;
	}
}
