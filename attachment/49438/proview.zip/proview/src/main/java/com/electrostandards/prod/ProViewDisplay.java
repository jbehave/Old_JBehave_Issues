package com.electrostandards.prod;

import javax.swing.JPanel;
import javax.swing.JFrame;
import java.awt.GridBagLayout;
import javax.swing.JButton;
import java.awt.GridBagConstraints;
import javax.swing.JTextField;
import java.awt.Insets;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class ProViewDisplay extends JFrame implements ActionListener {

	private static final long serialVersionUID = 1L;
	private JPanel jContentPane = null;
	private JButton Connect = null;
	private JTextField TestMe = null;
	
	private static ProViewDisplay proViewDisplay;
	
	/**
	 * This is the default constructor
	 */
	private ProViewDisplay() {
		super();
		initialize();
	}
	
	public static synchronized ProViewDisplay getProViewDisplay(){
		if (proViewDisplay == null){
			proViewDisplay = new ProViewDisplay();
		}
		
		return proViewDisplay;
	}
	
	public Object clone() throws CloneNotSupportedException {
		throw new CloneNotSupportedException();
	}
	
	public void showWindow(){
		
		// Make the window visible and make sure that the program exits when 
    	// closing the window.
    	this.setVisible(true);
		this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	}

	/**
	 * This method initializes this
	 * 
	 * @return void
	 */
	private void initialize() {
		this.setSize(256, 124);
		this.setContentPane(getJContentPane());
		this.setTitle("ElectroStandards ProView Lite");
		this.setName("ElectroStandards ProView Lite");
	}
	
	/**
	 * This method initializes jContentPane
	 * 
	 * @return javax.swing.JPanel
	 */
	private JPanel getJContentPane() {
		if (jContentPane == null) {
			GridBagConstraints gridBagConstraints1 = new GridBagConstraints();
			gridBagConstraints1.gridx = 0;
			gridBagConstraints1.insets = new Insets(15, 0, 0, 0);
			gridBagConstraints1.gridy = 1;
			GridBagConstraints gridBagConstraints = new GridBagConstraints();
			gridBagConstraints.fill = GridBagConstraints.NONE;
			gridBagConstraints.gridx = 0;
			gridBagConstraints.gridy = 0;
			gridBagConstraints.ipadx = 150;
			gridBagConstraints.anchor = GridBagConstraints.CENTER;
			gridBagConstraints.insets = new Insets(0, 0, 0, 0);
			gridBagConstraints.weightx = 1.0;
			jContentPane = new JPanel();
			jContentPane.setLayout(new GridBagLayout());
			jContentPane.add(getConnect(), gridBagConstraints1);
			jContentPane.add(getTestMe(), gridBagConstraints);
		}
		return jContentPane;
	}

	/**
	 * This method initializes Connect	
	 * 	
	 * @return javax.swing.JButton	
	 */
	private JButton getConnect() {
		if (Connect == null) {
			Connect = new JButton();
			Connect.setText("Connect");
			Connect.setName("Connect");
		}
		return Connect;
	}

	/**
	 * This method initializes TestMe	
	 * 	
	 * @return javax.swing.JTextField	
	 */
	private JTextField getTestMe() {
		if (TestMe == null) {
			TestMe = new JTextField();
			TestMe.setText("Proview is not connected to a Pro-D");
			TestMe.setEditable(false);
			TestMe.setName("Status");
		}
		return TestMe;
	}
	
	// Must implement actionPerformed to handle the events that occur during the
	// usage of the GUI

	public void actionPerformed(ActionEvent e) {
		
		// When the button is clicked set the status of the Proview to "Connected"
		// and set the text display to "Successfully connected to Pro-D"
		
		
		
	}  //  @jve:decl-index=0:visual-constraint="18,16"
}