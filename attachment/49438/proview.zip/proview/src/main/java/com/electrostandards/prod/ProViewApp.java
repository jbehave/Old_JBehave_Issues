package com.electrostandards.prod;

public class ProViewApp {

		private static ProViewApp proViewApp;
		// A private Constructor prevents any other class from instantiating. 
		private ProViewApp() {
			
			// The ProViewApp is an instantiation of the Display and the Communicator
			// so that we can be assured that only one exists and that they can share
			// information between them.
			
		}
		
		public static synchronized ProViewApp getProViewApp() {
			if (proViewApp == null) {
				proViewApp = new ProViewApp();
			}
			return proViewApp;
		}
		
		public Object clone() throws CloneNotSupportedException {
			throw new CloneNotSupportedException();
		}
		
		private static ProViewDisplay display;
		private static ProViewController controller;
		
		public ProViewDisplay getProViewDisplay() {
			
			if (display == null){
				display = ProViewDisplay.getProViewDisplay();
			}
			
			return display;
		}
		
		public ProViewController getProViewController(){
			if (controller == null){
				controller = ProViewController.getProViewController();
			}
			
			return controller;
		}
		
	}

