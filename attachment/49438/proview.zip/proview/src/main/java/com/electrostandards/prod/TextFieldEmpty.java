package com.electrostandards.prod;

public class TextFieldEmpty extends Exception {
	
	public TextFieldEmpty(String msg) {
		super(msg);
	}

	private static final long serialVersionUID = 1L;
	
}
