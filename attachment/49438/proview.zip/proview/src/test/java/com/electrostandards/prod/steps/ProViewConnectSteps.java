package com.electrostandards.prod.steps;

import javax.swing.JTextField;

import org.jbehave.scenario.annotations.Given;
import org.jbehave.scenario.annotations.Then;
import org.jbehave.scenario.annotations.When;
import org.jbehave.scenario.steps.Steps;
import org.lunivore.tyburn.ComponentFinderException;
import org.lunivore.tyburn.WindowControl;
import org.lunivore.tyburn.threaded.TimeoutException;

import com.electrostandards.prod.CharacterReader;
import com.electrostandards.prod.ProViewApp;
import com.electrostandards.prod.ProViewDisplay;

import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.equalTo;

public class ProViewConnectSteps extends Steps {
	
	private WindowControl proViewWindowControl;
	private ProViewDisplay proViewDisplay;
	private CharacterReader characterReader;
	
	@Given("Proview is in $mode mode")
	public void newProview(String mode){
		
		ProViewApp proViewApp =  ProViewApp.getProViewApp();
		
		proViewDisplay = proViewApp.getProViewDisplay();
		proViewDisplay.showWindow();
		proViewWindowControl = new WindowControl(proViewDisplay.getName());
	}

	@When("I click '$button'")
	public void clickConnectButton(String button) throws ComponentFinderException, TimeoutException{
	
		proViewWindowControl.clickButton(button);
	}
	
	@Then("I should see '$message' in the $box box")
	public void confirmMessage(String message, String box) throws ComponentFinderException, TimeoutException{
	
		String statusMessage;
		
		JTextField textField = (JTextField) proViewWindowControl.findComponent("Status");
		statusMessage = characterReader.readFromComponent(textField);
		
		assertThat(statusMessage, equalTo(message));
		
	}
	
	
	//@Alias("the ProviewController should be connected to a Pro-D")
	

}
