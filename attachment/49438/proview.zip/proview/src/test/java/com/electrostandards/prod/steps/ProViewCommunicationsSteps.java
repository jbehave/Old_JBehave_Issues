package com.electrostandards.prod.steps;

import org.jbehave.scenario.steps.Steps;

public class ProViewCommunicationsSteps extends Steps {

//	@Given("Proview is in 'Offline' mode")
	//public void 
}
