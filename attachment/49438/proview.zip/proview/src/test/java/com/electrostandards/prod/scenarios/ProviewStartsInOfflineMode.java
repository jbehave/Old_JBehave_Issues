package com.electrostandards.prod.scenarios;

import org.jbehave.scenario.MostUsefulConfiguration;
import org.jbehave.scenario.Scenario;
import org.jbehave.scenario.parser.ClasspathScenarioDefiner;
import org.jbehave.scenario.parser.PatternScenarioParser;
import org.jbehave.scenario.parser.ScenarioDefiner;
import org.jbehave.scenario.parser.UnderscoredCamelCaseResolver;

import com.electrostandards.prod.steps.ProViewConnectSteps;

public class ProviewStartsInOfflineMode extends Scenario {
	 
    public ProviewStartsInOfflineMode() {
        super(new MostUsefulConfiguration() {
            public ScenarioDefiner forDefiningScenarios() {
                return new ClasspathScenarioDefiner(new UnderscoredCamelCaseResolver(".scenario"),
                             new PatternScenarioParser(keywords()));
            }
        });
        addSteps(new ProViewConnectSteps()); 
    }
}

