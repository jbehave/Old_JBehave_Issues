package com.coba.crc.atcspd;

import java.util.Locale;

import org.jbehave.core.configuration.Keywords;
import org.jbehave.core.i18n.LocalizedKeywords;
import org.jbehave.core.model.Story;
import org.jbehave.core.parsers.RegexStoryParser;
import org.junit.Assert;
import org.junit.Test;

public class DescriptionPatternTest {

	@Test
	public void test() {
		Keywords keywords = new LocalizedKeywords(Locale.GERMANY);
		RegexStoryParser parser = new RegexStoryParser(keywords);
		String meta = "Meta:";
		String author = "Andreas Rudolf";
		String description = "Die nächste Bewertung von Kreditausfallversicherungen";

		String narrative = "Erzählung:";
		String inOrder = "eine Kreditausfallversicherung (CreditDefaultSwaps)";
		String asA = "Als Händler zu bewerten";
		String iWantTo = "Möchte ich den aktuellen Wert berechnen";
		//		String soThat = "Damit entsprechende Positionen richtig bewertet werden";

		String lifecycle = "Lebenszyklus:";
		String before = "Vorher:"; 
		String lGiven = "Gegeben sei folgende risikolose Zinskurve";
		StringBuffer risklessCurveTable = new StringBuffer();
		risklessCurveTable.append("|Tage|Zinssatz|").append("\n");
		risklessCurveTable.append("|30  |0,05    |").append("\n");
		risklessCurveTable.append("|90  |0,052   |").append("\n");
		risklessCurveTable.append("|180 |0,053   |").append("\n");
		risklessCurveTable.append("|360 |0,054   |").append("\n");
		risklessCurveTable.append("|720 |0,055   |").append("\n");

		String scenario1 = "1 Ausfallquote bei 40%";
		String given1 = "Gegeben sei eine Kreditausfallversicherung mit den Kenndaten 122345";
		String and1 = "Und weitern Kenndaten 6789";
		String when1 = "Wenn der Stapelprozess gerechnet hat";
		String then1 = "Dann wird der aktuelle Wert 1000 EUR erwartet";

		StringBuffer storytext = new StringBuffer();
		
		storytext.append(description).append("\n");
		storytext.append("\n");
		
		storytext.append(meta).append("\n");
		storytext.append("@author").append(author).append("\n");
		
		storytext.append(narrative).append("\n");
		storytext.append("Um ").append(inOrder).append("\n");
		storytext.append(asA).append("\n");
		storytext.append(iWantTo).append("\n");		
		storytext.append("\n");

		storytext.append(lifecycle).append("\n");
		storytext.append(before).append("\n");
		storytext.append(lGiven).append("\n");
		storytext.append(risklessCurveTable.toString()).append("\n");
		
		storytext.append("Szenario: ").append(scenario1).append("\n");
		storytext.append(given1).append("\n");
		storytext.append(and1).append("\n");
		storytext.append(when1).append("\n");
		storytext.append(then1).append("\n");

		Story story = parser.parseStory(storytext.toString());

		Assert.assertEquals(description, story.getDescription().asString());
		Assert.assertEquals(inOrder, story.getNarrative().inOrderTo());
		Assert.assertEquals(scenario1, story.getScenarios().get(0).getTitle());
	}

}
