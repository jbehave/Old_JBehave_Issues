package com.coba.crc.atcspd.steps;

import org.jbehave.core.annotations.Given;
import org.jbehave.core.annotations.Then;
import org.jbehave.core.annotations.When;

public class CreditDefaultSwap {
	
	@Given("a CreditDefaultSwap with maturity date $maturity")
	public void maturityDateOfCDS(String maturity) {
		System.out.println("STEP: given maturityDateOfCDS " + maturity);
	}

	@Given("a spread of $spread per year")
	public void spreadPerYear(double spread) {
		System.out.println("STEP: given spreadPerYear " + spread);
	}

	@Given("a recovery rate of $recoveryrate%")
	public void recoveryRate(double recoveryrate)
	{
		System.out.println("STEP: given recoveryRate " + recoveryrate);		
	}
	
	@When("its calculated")
	public void whenItsCalculated() {
		System.out.println("STEP: when itsCalculated");
	}

	@Then("we expect at $riskdate a present value of $pv EUR")
	public void expectValueAtRiskdate(String riskdate,double pv) {
		System.out.println("STEP: then expectValueAtRiskdate " + riskdate);
	}
}
