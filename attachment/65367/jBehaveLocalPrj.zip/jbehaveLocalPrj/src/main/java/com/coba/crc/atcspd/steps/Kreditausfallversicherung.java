package com.coba.crc.atcspd.steps;


import org.jbehave.core.annotations.Given;
import org.jbehave.core.annotations.Then;
import org.jbehave.core.annotations.When;


public class Kreditausfallversicherung {
	
	
	@Given("sei eine Kreditausfallversicherung mit einer Laufzeit bis zum $enddate")	
	public void maturityDateOfCDS(String maturity)  {
		System.out.println("Given: maturityDateOfCDS " + maturity);

	}

	@Given("einer Ausfallpr\u00E4mie von $spread pro Jahr")
	public void spreadAndPaymentFrequency(double spread) {
		System.out.println("Given: spreadAndPaymentFrequency " + spread);
	}
	
	
	@Given("einer Konkursquote von $recoveryRate")	
	public void andEinerKonkursquoteVon40(double recoveryRate) {
		System.out.println("Given: andEinerKonkursquoteVon40 " + recoveryRate);
	}
	

	@When("die Kreditausfallversicherung bewertet wird")
	public void wennDieKreditausfallversicherungBewertetWird() {
		System.out.println("When: wennDieKreditausfallversicherungBewertetWird ");
	}

	@Then("wird zum $presentDate der aktuelle Wert $presentValue EUR erwartet")
	public void erwartet(String presentDate,double presentValue) {
		System.out.println("Then: erwartet " + presentDate + " " + presentValue);
	}

}
