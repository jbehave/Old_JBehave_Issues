package com.coba.crc.atcspd.stories;

import java.util.Locale;

public class EnglishStories extends StoryBase {
	 @Override
	    protected Locale locale() {
	        return new Locale("en");
	    }
	 
	    @Override
	    protected String storyPattern() {
	        return "**/*.story";
	    }
}
