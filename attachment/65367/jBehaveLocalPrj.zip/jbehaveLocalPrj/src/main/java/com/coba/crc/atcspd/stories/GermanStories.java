package com.coba.crc.atcspd.stories;

import java.util.Locale;

public class GermanStories extends StoryBase {
	 @Override
	    protected Locale locale() {
	        return new Locale("de","DE");
	    }
	 
	    @Override
	    protected String storyPattern() {
	        return "**/*.geschichte";
	    }
	  
}
