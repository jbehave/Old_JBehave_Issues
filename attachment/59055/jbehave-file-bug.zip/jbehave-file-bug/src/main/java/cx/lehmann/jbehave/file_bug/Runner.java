package cx.lehmann.jbehave.file_bug;

import org.jbehave.core.annotations.Configure;
import org.jbehave.core.annotations.UsingEmbedder;
import org.jbehave.core.annotations.UsingPaths;
import org.jbehave.core.annotations.UsingSteps;
import org.jbehave.core.annotations.guice.UsingGuice;
import org.jbehave.core.embedder.Embedder;
import org.jbehave.core.embedder.StoryControls;
import org.jbehave.core.io.CodeLocations;
import org.jbehave.core.io.LoadFromClasspath;
import org.jbehave.core.io.StoryLoader;
import org.jbehave.core.junit.guice.GuiceAnnotatedPathRunner;
import org.jbehave.core.parsers.RegexPrefixCapturingPatternParser;
import org.jbehave.core.parsers.StepPatternParser;
import org.jbehave.core.reporters.StoryReporterBuilder;

import org.junit.runner.RunWith;

import com.google.common.util.concurrent.MoreExecutors;
import com.google.inject.AbstractModule;

import cx.lehmann.jbehave.file_bug.Runner.ConfigurationModule;
import cx.lehmann.jbehave.file_bug.Runner.SameThreadEmbedder;
import cx.lehmann.jbehave.file_bug.Runner.StepsModule;


import static org.jbehave.core.reporters.Format.CONSOLE;
import static org.jbehave.core.reporters.Format.HTML;
import static org.jbehave.core.reporters.Format.TXT;
import static org.jbehave.core.reporters.Format.XML;

/**
 * Run stories via annotated embedder configuration and steps using Guice.
 */
@RunWith(GuiceAnnotatedPathRunner.class)
@Configure()
@UsingEmbedder(embedder = SameThreadEmbedder.class,
    generateViewAfterStories = true,
    ignoreFailureInStories = true,
    ignoreFailureInView = true,
    metaFilters = { "-skip" })
@UsingGuice(modules = { ConfigurationModule.class, StepsModule.class })
@UsingPaths(searchIn = "src/main/resources", includes = { "**/*.story" }, excludes = { "**/examples_table*.story" })
@UsingSteps(instances = { })

public class Runner {
    // Guice modules
    public static class ConfigurationModule extends AbstractModule {
        @Override
        protected void configure() {
            bind(StoryControls.class)
            .toInstance(new StoryControls().doDryRun(false).doSkipScenariosAfterFailure(false));
            bind(StepPatternParser.class).toInstance(new RegexPrefixCapturingPatternParser("$"));
            bind(StoryLoader.class).toInstance(new LoadFromClasspath(this.getClass().getClassLoader()));

            bind(StoryReporterBuilder.class).toInstance(
                    new StoryReporterBuilder().withDefaultFormats().withFormats(CONSOLE, HTML, TXT, XML)
//                    .withCodeLocation(CodeLocations.codeLocationFromClass(this.getClass()))
                    .withCodeLocation(CodeLocations.codeLocationFromClass(Embedder.class))
                    .withFailureTrace(true));
            
        }
    }

    public static class StepsModule extends AbstractModule {
        @Override
        protected void configure() {
        }
    }

    public static class SameThreadEmbedder extends Embedder {
        public SameThreadEmbedder() {
            useExecutorService(MoreExecutors.sameThreadExecutor());
        }
    }

}
