package jbehave;

import java.io.File;
import java.net.URL;
import java.util.List;
import java.util.Map;
import java.util.Properties;

import org.jbehave.core.configuration.Keywords;
import org.jbehave.core.reporters.CrossReference;
import org.jbehave.core.reporters.FilePrintStreamFactory.FileConfiguration;
import org.jbehave.core.reporters.FilePrintStreamFactory.FilePathResolver;
import org.jbehave.core.reporters.StoryReporter;
import org.jbehave.core.reporters.StoryReporterBuilder;

public class DelegatingStoryReporterBuilder extends StoryReporterBuilder {
	private StoryReporterBuilder delegate;
	
	public DelegatingStoryReporterBuilder(StoryReporterBuilder delegate) {
		super();
		this.delegate = delegate;
	}

	public int hashCode() {
		return delegate.hashCode();
	}

	public boolean equals(Object obj) {
		return delegate.equals(obj);
	}

	public File outputDirectory() {
		return delegate.outputDirectory();
	}

	public String relativeDirectory() {
		return delegate.relativeDirectory();
	}

	public FilePathResolver pathResolver() {
		return delegate.pathResolver();
	}

	public URL codeLocation() {
		return delegate.codeLocation();
	}

	public List<org.jbehave.core.reporters.Format> formats() {
		return delegate.formats();
	}

	public List<String> formatNames(boolean toLowerCase) {
		return delegate.formatNames(toLowerCase);
	}

	public Keywords keywords() {
		return delegate.keywords();
	}

	public boolean multiThreading() {
		return delegate.multiThreading();
	}

	public boolean reportFailureTrace() {
		return delegate.reportFailureTrace();
	}

	public boolean compressFailureTrace() {
		return delegate.compressFailureTrace();
	}

	public Properties viewResources() {
		return delegate.viewResources();
	}

	public StoryReporterBuilder withRelativeDirectory(String relativeDirectory) {
		return delegate.withRelativeDirectory(relativeDirectory);
	}

	public StoryReporterBuilder withPathResolver(FilePathResolver pathResolver) {
		return delegate.withPathResolver(pathResolver);
	}

	public StoryReporterBuilder withCodeLocation(URL codeLocation) {
		return delegate.withCodeLocation(codeLocation);
	}

	public CrossReference crossReference() {
		return delegate.crossReference();
	}

	public boolean hasCrossReference() {
		return delegate.hasCrossReference();
	}

	public StoryReporterBuilder withCrossReference(CrossReference crossReference) {
		return delegate.withCrossReference(crossReference);
	}

	public StoryReporterBuilder withDefaultFormats() {
		return delegate.withDefaultFormats();
	}

	public StoryReporterBuilder withFormats(org.jbehave.core.reporters.Format... formats) {
		return delegate.withFormats(formats);
	}

	public StoryReporterBuilder withFailureTrace(boolean reportFailureTrace) {
		return delegate.withFailureTrace(reportFailureTrace);
	}

	public StoryReporterBuilder withFailureTraceCompression(boolean compressFailureTrace) {
		return delegate.withFailureTraceCompression(compressFailureTrace);
	}

	public StoryReporterBuilder withKeywords(Keywords keywords) {
		return delegate.withKeywords(keywords);
	}

	public StoryReporterBuilder withMultiThreading(boolean multiThreading) {
		return delegate.withMultiThreading(multiThreading);
	}

	public StoryReporterBuilder withViewResources(Properties resources) {
		return delegate.withViewResources(resources);
	}

	public StoryReporter build(String storyPath) {
		return delegate.build(storyPath);
	}

	public String toString() {
		return delegate.toString();
	}

	public Map<String, StoryReporter> build(List<String> storyPaths) {
		return delegate.build(storyPaths);
	}

	public StoryReporter reporterFor(String storyPath, Format format) {
		return delegate.reporterFor(storyPath, format);
	}

	public FileConfiguration fileConfiguration(String extension) {
		return delegate.fileConfiguration(extension);
	}
	
	
}
