package jbehave;

import java.lang.annotation.Annotation;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Properties;

import org.jbehave.core.ConfigurableEmbedder;
import org.jbehave.core.annotations.UsingPaths;
import org.jbehave.core.configuration.Configuration;
import org.jbehave.core.configuration.MostUsefulConfiguration;
import org.jbehave.core.failures.FailureStrategy;
import org.jbehave.core.failures.PendingStepStrategy;
import org.jbehave.core.model.ExamplesTable;
import org.jbehave.core.model.Scenario;
import org.jbehave.core.model.Story;
import org.jbehave.core.reporters.Format;
import org.jbehave.core.reporters.StoryReporter;
import org.jbehave.core.reporters.StoryReporterBuilder;
import org.jbehave.core.steps.CandidateSteps;
import org.jbehave.core.steps.InstanceStepsFactory;
import org.jbehave.core.steps.ParameterConverters;
import org.jbehave.core.steps.ParameterConverters.DateConverter;
import org.jbehave.core.steps.PrintStreamStepMonitor;
import org.junit.internal.runners.model.EachTestNotifier;
import org.junit.runner.Description;
import org.junit.runner.notification.RunNotifier;
import org.junit.runners.ParentRunner;
import org.junit.runners.model.FrameworkMethod;
import org.junit.runners.model.InitializationError;
import org.junit.runners.model.Statement;

public class JBehaveTestRunner extends ParentRunner<StoryDescription> {
	private Description parentDescription;
	private Map<String, StoryDescription> storyDescriptions;
	private ConfigurableEmbedder embedder;
	private List<String> storyPaths;
	
	public JBehaveTestRunner(Class<?> testClass) throws InitializationError {
		super(testClass);
		UsingPaths usingPaths = testClass.getAnnotation(UsingPaths.class);
		if (usingPaths == null) {
			throw new IllegalStateException(String.format("%s annotation not found on %s", UsingPaths.class.getName(), testClass.getName()));
		}
		this.storyPaths = Arrays.asList(usingPaths.includes());
		this.embedder = new ConfigurableEmbedder() {
			@Override
			public void run() throws Throwable {
				configuredEmbedder().runStoriesAsPaths(storyPaths);
			}
		};
		Configuration configuration = createConfiguration();
		this.embedder.useConfiguration(configuration);
		this.storyDescriptions = parseStoryDescriptions(testClass, storyPaths, configuration);
		this.parentDescription = createParentDescription(testClass, storyDescriptions);
	}
	
	protected Configuration createConfiguration() {
		Properties viewResources = new Properties();
		viewResources.put("decorateNonHtml", "true");

		Configuration configuration = new MostUsefulConfiguration()
			.useStoryReporterBuilder(
				new StoryReporterBuilder()
						.withDefaultFormats()
						.withViewResources(viewResources)
						.withFormats(Format.CONSOLE, Format.TXT, Format.HTML, Format.XML)
						.withFailureTrace(true))
						.useParameterConverters(
								new ParameterConverters()
									// use custom date pattern
									.addConverters(new DateConverter(new SimpleDateFormat("yyyy-MM-dd"))))
			.useStepMonitor(new PrintStreamStepMonitor()
		);
		return configuration;
	}
	
	protected ConfigurableEmbedder getEmbedder() {
		return embedder;
	}
	
	@SuppressWarnings({ "unchecked", "rawtypes" })
	protected Collection<? extends Object> getSteps() throws Throwable {
		Object result = invokeSingle(createTest(), Steps.class);
		if (result instanceof Object[]) {
			return Arrays.asList(((Object[]) result));
		} else {
			return (Collection) result;
		}
	}
	
	protected Object invokeSingle(Object target, Class<? extends Annotation> annotationType) throws Throwable {
		List<FrameworkMethod> methods = getTestClass().getAnnotatedMethods(annotationType);
		if (methods.size() != 1) {
			throw new IllegalStateException(String.format("%s methods found with annotation %s, expected 1", methods.size(), annotationType.getName()));
		}
		return methods.get(0).invokeExplosively(target);
	}
	
	/**
	 * Returns a new fixture for running a test. Default implementation executes
	 * the test class's no-argument constructor (validation should have ensured
	 * one exists).
	 */
	protected Object createTest() throws Exception {
		return getTestClass().getOnlyConstructor().newInstance();
	}

	protected Map<String, StoryDescription> parseStoryDescriptions(Class<?> testClass, List<String> storyPaths, Configuration configuration) {
		Map<String, StoryDescription> storyDescriptions = new LinkedHashMap<String, StoryDescription>();
		for (String storyPath : storyPaths) {
			String storyAsText = configuration.storyLoader().loadStoryAsText(storyPath);
			Story story = configuration.storyParser().parseStory(storyAsText, storyPath);
			
			StoryDescription storyDescription = new StoryDescription(story, Description.createSuiteDescription(story.getPath()));
			for (Scenario scenario : story.getScenarios()) {
				ScenarioDescription scenarioDescription = new ScenarioDescription(scenario, Description.createSuiteDescription(scenario.getTitle()));
				ExamplesTable examplesTable = scenario.getExamplesTable();
				int exampleCount = examplesTable.getRowCount();
				for (int i = 0; i < exampleCount; ++ i) {
					Map<String, String> exampleRow = examplesTable.getRow(i); 
					String testName = exampleRow.toString();
					ExampleDescription exampleDescription = new ExampleDescription(exampleRow, Description.createTestDescription(testClass, testName));
					
					scenarioDescription.getDescription().addChild(exampleDescription.getDescription());
					scenarioDescription.getExampleDescriptions().add(exampleDescription);
				}
				storyDescription.getDescription().addChild(scenarioDescription.getDescription());
				storyDescription.getScenarioDescriptions().put(scenarioDescription.getScenario().getTitle(), scenarioDescription);
			}
			storyDescriptions.put(story.getPath(), storyDescription);
		}
		return storyDescriptions;
	}
	
	protected Description createParentDescription(Class<?> testClass, Map<String, StoryDescription> storyDescriptions) {
		Description parent = Description.createSuiteDescription(testClass);
		for (StoryDescription storyDescription : storyDescriptions.values()) {
			parent.addChild(storyDescription.getDescription());
		}
		return parent;
	}
	

	@Override
	public Description getDescription() {
		return parentDescription;
	}
	
	@Override
	protected List<StoryDescription> getChildren() {
		return new ArrayList<StoryDescription>(storyDescriptions.values());
	}
	
	@Override
	protected Description describeChild(StoryDescription child) {
		return child.getDescription();
	}
	
	@Override
	protected void runChild(StoryDescription child, RunNotifier notifier) {
		throw new UnsupportedOperationException("runChild");
	}

	@Override
	protected Statement childrenInvoker(final RunNotifier notifier) {
		return new Statement() {
			public void evaluate() {
				runChildren(notifier);
			}
		};
	}

	protected void runChildren(RunNotifier notifier) {
		runtimeConfigure(notifier);
		EachTestNotifier testNotifier = new EachTestNotifier(notifier, parentDescription);
		try {
			testNotifier.fireTestStarted();
			embedder.configuredEmbedder().runStoriesAsPaths(storyPaths);
		} catch (Throwable e) {
			testNotifier.addFailure(e);
		} finally {
			testNotifier.fireTestFinished();
		}
	}
	
	protected void runtimeConfigure(RunNotifier notifier) {
		Configuration configuration = this.embedder.configuration();
		List<StoryReporter> storyReporters = getStoryReporters(notifier);
		StoryReporterBuilder storyReporterBuilder = new JUnitStoryReporterBuilder(configuration.storyReporterBuilder(), storyReporters);
		configuration.useStoryReporterBuilder(storyReporterBuilder);
		
		final EachTestNotifier testNotifier = new EachTestNotifier(notifier, parentDescription);
		configuration.useFailureStrategy(new FailureStrategy() {
			@Override
			public void handleFailure(Throwable throwable) throws Throwable {
				testNotifier.addFailure(throwable);
			}
		});
		configuration.usePendingStepStrategy(new PendingStepStrategy() {
			public void handleFailure(Throwable throwable) throws Throwable {
				testNotifier.addFailure(throwable);
			}
		});		
		storyReporterBuilder.withFormats(Format.CONSOLE);
		
		embedder.configuredEmbedder().embedderControls()
			.doGenerateViewAfterStories(true)
			.doIgnoreFailureInStories(false)
			.doIgnoreFailureInView(false)
			.doBatch(false);
		
		try {
			Object[] steps = getSteps().toArray();
			List<CandidateSteps> candidateSteps = new InstanceStepsFactory(configuration, steps).createCandidateSteps(); 
			embedder.addSteps(candidateSteps);
		} catch (Throwable e) {
			throw new RuntimeException(e);
		}
	}
	
	protected List<StoryReporter> getStoryReporters(RunNotifier notifier) {
		DescriptionSource descriptionSource = new DefaultDescriptionSource(storyDescriptions);
		StoryReporter junitReporter = new JUnitStoryReporter(notifier, descriptionSource);
		
		return Collections.singletonList(junitReporter);
	}
}
