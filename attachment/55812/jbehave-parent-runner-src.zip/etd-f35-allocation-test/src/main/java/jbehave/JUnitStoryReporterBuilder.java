package jbehave;

import java.util.ArrayList;
import java.util.List;

import org.jbehave.core.reporters.DelegatingStoryReporter;
import org.jbehave.core.reporters.StoryReporter;
import org.jbehave.core.reporters.StoryReporterBuilder;

public class JUnitStoryReporterBuilder extends DelegatingStoryReporterBuilder {
	private List<StoryReporter> storyReporters;
	
	public JUnitStoryReporterBuilder(StoryReporterBuilder delegate, List<StoryReporter> storyReporters) {
		super(delegate);
		this.storyReporters = storyReporters;
	}
	
	@Override
	public StoryReporter build(String storyPath) {
		List<StoryReporter> allReporters = new ArrayList<StoryReporter>(storyReporters);
		allReporters.add(super.build(storyPath));
		return new DelegatingStoryReporter(allReporters.toArray(new StoryReporter[allReporters.size()]));
	}
}
