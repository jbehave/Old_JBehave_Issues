package jbehave;

import java.util.Map;

import org.jbehave.core.model.Scenario;
import org.jbehave.core.model.Story;

public class JBehaveExampleContext {
	private Story story;
	private Scenario scenario;
	private Map<String,String> exampleRow;
	
	public JBehaveExampleContext(Story story, Scenario scenario, Map<String, String> exampleRow) {
		super();
		this.story = story;
		this.scenario = scenario;
		this.exampleRow = exampleRow;
	}

	public Story getStory() {
		return story;
	}

	public Scenario getScenario() {
		return scenario;
	}

	public Map<String, String> getExampleRow() {
		return exampleRow;
	}
}
