package jbehave;

import java.util.List;
import java.util.Map;

import org.jbehave.core.model.Story;
import org.junit.runner.Description;

public interface DescriptionSource {
	public Description getDescription(Story story, String scenario, Map<String,String> exampleRow);
	public List<Description> getDescriptions(Story story, String scenario);
}
