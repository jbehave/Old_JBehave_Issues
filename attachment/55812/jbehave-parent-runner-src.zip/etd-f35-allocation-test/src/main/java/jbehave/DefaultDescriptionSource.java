package jbehave;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.jbehave.core.model.Story;
import org.junit.runner.Description;

public class DefaultDescriptionSource implements DescriptionSource {
	private Map<String, StoryDescription> storyDescriptions;

	public DefaultDescriptionSource( Map<String, StoryDescription> storyDescriptions) {
		this.storyDescriptions = storyDescriptions;
	}
	
	@Override
	public Description getDescription(Story story, String scenario, Map<String, String> exampleRow) {
		StoryDescription storyDescription = storyDescriptions.get(story.getPath());
		ScenarioDescription scenarioDescription = storyDescription.getScenarioDescriptions().get(scenario);
		for (ExampleDescription exampleDescription : scenarioDescription.getExampleDescriptions()) {
			if (exampleRow.equals(exampleDescription.getExampleRow())) {
				return exampleDescription.getDescription();
			}
		}
		return null;
	}
	
	@Override
	public List<Description> getDescriptions(Story story, String scenario) {
		List<Description> scenarioDescriptions = new ArrayList<Description>();
		StoryDescription storyDescription = storyDescriptions.get(story.getPath());
		ScenarioDescription scenarioDescription = storyDescription.getScenarioDescriptions().get(scenario);
		for (ExampleDescription exampleDescription : scenarioDescription.getExampleDescriptions()) {
			scenarioDescriptions.add(exampleDescription.getDescription());
		}
		return scenarioDescriptions;
	}
}
