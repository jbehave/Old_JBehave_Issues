package jbehave;

import java.util.List;
import java.util.Map;

import org.jbehave.core.failures.UUIDExceptionWrapper;
import org.jbehave.core.model.ExamplesTable;
import org.jbehave.core.model.Story;
import org.jbehave.core.reporters.NullStoryReporter;
import org.junit.internal.AssumptionViolatedException;
import org.junit.runner.Description;
import org.junit.runner.notification.Failure;
import org.junit.runner.notification.RunNotifier;

/**
 * This class is not thread-safe
 * @author semmenla
 */
public class JUnitStoryReporter extends NullStoryReporter {
	private RunNotifier runNotifier;
	private DescriptionSource descriptionSource;
	private Story story;
	private String scenario;
	private Map<String, String> tableRow;
	private boolean exampleInError = false;
	
	public JUnitStoryReporter(RunNotifier runNotifier, DescriptionSource descriptionSource) {
		super();
		this.runNotifier = runNotifier;
		this.descriptionSource = descriptionSource;
	}

	@Override
	public void beforeStory(Story story, boolean givenStory) {
		this.story = story;
	}
	
	@Override
	public void afterStory(boolean givenStory) {
		this.story = null;
	}
	
	@Override
	public void beforeScenario(String scenario) {
		this.scenario = scenario;
	}
	
	@Override
	public void afterScenario() {
		this.scenario = null;
	}
	
	@Override
	public void beforeExamples(List<String> steps, ExamplesTable table) {
		List<Description> descriptions = descriptionSource.getDescriptions(story, scenario);
		for (Description description : descriptions) {
			runNotifier.fireTestStarted(description);
		}
	}
	
	@Override
	public void example(Map<String, String> tableRow) {
		this.exampleInError = false;
		this.tableRow = tableRow;
	}
	
	@Override
	public void afterExamples() {
		List<Description> descriptions = descriptionSource.getDescriptions(story, scenario);
		for (Description description : descriptions) {
			runNotifier.fireTestFinished(description);
		}
	}
	
	@Override
	public void notPerformed(String step) {
		if (!exampleInError) {
			Description description = descriptionSource.getDescription(story, scenario, tableRow);
			runNotifier.fireTestIgnored(description);
		}
	}
	
	@Override
	public void failed(String step, Throwable throwable) {
		Throwable cause = throwable;
		if (throwable instanceof UUIDExceptionWrapper) {
			cause = ((UUIDExceptionWrapper) cause).getCause();
		}
		Description description = descriptionSource.getDescription(story, scenario, tableRow);
		if (cause instanceof AssumptionViolatedException) {
			runNotifier.fireTestAssumptionFailed(new Failure(description, cause));
		} else {
			runNotifier.fireTestFailure(new Failure(description, cause));
		}
		
		this.exampleInError = true;
	}
}
