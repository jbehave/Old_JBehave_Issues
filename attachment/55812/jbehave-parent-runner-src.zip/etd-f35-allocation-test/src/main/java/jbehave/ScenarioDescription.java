package jbehave;

import java.util.ArrayList;
import java.util.List;

import org.jbehave.core.model.Scenario;
import org.junit.runner.Description;

public class ScenarioDescription {
	private Scenario scenario;
	private Description description;
	private List<ExampleDescription> exampleDescriptions = new ArrayList<ExampleDescription>();
	public ScenarioDescription(Scenario scenario, Description description) {
		super();
		this.scenario = scenario;
		this.description = description;
	}
	public Scenario getScenario() {
		return scenario;
	}
	public Description getDescription() {
		return description;
	}
	public List<ExampleDescription> getExampleDescriptions() {
		return exampleDescriptions;
	}
}
