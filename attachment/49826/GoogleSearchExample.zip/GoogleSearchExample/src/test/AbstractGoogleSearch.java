package test;

import org.jbehave.core.annotations.AfterStory;
import org.jbehave.core.annotations.Given;
import org.jbehave.core.annotations.Named;
import org.jbehave.core.annotations.Then;
import org.jbehave.core.annotations.When;
import org.jbehave.core.configuration.Configuration;
import org.jbehave.core.configuration.MostUsefulConfiguration;
import org.jbehave.core.io.LoadFromClasspath;
import org.jbehave.core.io.UnderscoredCamelCaseResolver;
import org.jbehave.core.junit.JUnitStory;
import org.jbehave.core.steps.InstanceStepsFactory;

public abstract class AbstractGoogleSearch extends JUnitStory {
    public AbstractGoogleSearch() {
        initialize();
    }

    public void initialize() {
        Class<? extends JUnitStory> storyClass = this.getClass();
        Configuration config = new MostUsefulConfiguration()
            .useStoryLoader(new LoadFromClasspath(storyClass.getClassLoader()))
            .useStoryPathResolver(new UnderscoredCamelCaseResolver(".story"));
        useConfiguration(config);
        addSteps(new InstanceStepsFactory(config, new GoogleSearchSteps()).createCandidateSteps());
    }

    public class GoogleSearchSteps {
        @Given("that I am on Google's Homepage")
        public void onGoogle() {
            System.out.println("On Google!");
        }

        @When("I enter the search term <ridiculousSearchTerm> and proceed")
        public void enterSearchTermAndProceed(@Named("ridiculousSearchTerm") String ridiculousSearchTerm) {
            System.out.println("Entering " + ridiculousSearchTerm + " into box and clicking continue!");
        }

        @Then("I should see ridiculous things")
        public void seeResults() {
            System.out.println("Ahhh, so much pink!!!");
        }

        @AfterStory
        public void killBrowser() {
            System.out.println("Browser has been put to rest \n\n");
        }

    }
}