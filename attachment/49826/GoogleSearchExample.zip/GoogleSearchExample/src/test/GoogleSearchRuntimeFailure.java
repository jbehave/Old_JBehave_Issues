package test;

public class GoogleSearchRuntimeFailure extends AbstractGoogleSearch {}
