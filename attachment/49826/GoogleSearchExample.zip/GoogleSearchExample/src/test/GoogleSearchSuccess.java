package test;

public class GoogleSearchSuccess extends AbstractGoogleSearch {}

