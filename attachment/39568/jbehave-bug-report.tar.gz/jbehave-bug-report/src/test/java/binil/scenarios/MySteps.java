package binil.scenarios;


import org.apache.log4j.Logger;
import org.jbehave.scenario.steps.Steps;

public class MySteps extends Steps {
    private static final Logger log = Logger.getLogger(MySteps.class);
    
    public MySteps(ClassLoader classLoader) {
        log.debug("test log message");
    }
}
