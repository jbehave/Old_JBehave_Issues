package binil.scenarios;

import org.jbehave.scenario.MostUsefulConfiguration;
import org.jbehave.scenario.Scenario;

public class MyScenario extends Scenario {
    public MyScenario() {
        this(Thread.currentThread().getContextClassLoader());
    }
    
    public MyScenario(final ClassLoader classLoader) {
        super(new MostUsefulConfiguration(), new MySteps(classLoader));
    }
}
