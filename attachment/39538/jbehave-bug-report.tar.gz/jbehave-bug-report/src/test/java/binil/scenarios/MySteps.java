package binil.scenarios;

import org.jbehave.scenario.steps.Steps;

public class MySteps extends Steps {
    public MySteps(ClassLoader classLoader) {
    }
}
