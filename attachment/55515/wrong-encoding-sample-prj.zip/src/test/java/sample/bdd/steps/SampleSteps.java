package sample.bdd.steps;

import org.jbehave.core.annotations.Given;
import org.jbehave.core.annotations.Then;
import org.jbehave.core.annotations.When;
import org.springframework.stereotype.Component;

@Component
public class SampleSteps {
	@Given("Product with nameLocal Produkt1")
	public void givenProductWithNameLocalProdukt1(){
	  // PENDING
	}
	@When("Jezyk jest ustawiony jak Polski")
	public void whenJezykJestUstawionyJakPolski(){
	  // PENDING
	}
	@Then("Product name is Produkt2")
	public void thenProductNameIsProdukt2(){
	  // PENDING
	}
}
