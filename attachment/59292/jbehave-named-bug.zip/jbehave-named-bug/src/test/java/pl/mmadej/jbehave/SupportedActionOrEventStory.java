package pl.mmadej.jbehave;

import org.jbehave.core.ConfigurableEmbedder;
import org.jbehave.core.annotations.Given;
import org.jbehave.core.annotations.Named;
import org.jbehave.core.annotations.Then;
import org.jbehave.core.annotations.When;
import org.jbehave.core.configuration.Configuration;
import org.jbehave.core.configuration.MostUsefulConfiguration;
import org.jbehave.core.embedder.Embedder;
import org.jbehave.core.failures.FailingUponPendingStep;
import org.jbehave.core.io.LoadFromClasspath;
import org.jbehave.core.io.StoryPathResolver;
import org.jbehave.core.reporters.Format;
import org.jbehave.core.reporters.StoryReporterBuilder;
import org.jbehave.core.steps.CandidateSteps;
import org.jbehave.core.steps.InjectableStepsFactory;
import org.jbehave.core.steps.InstanceStepsFactory;
import org.junit.Test;

import java.util.LinkedList;
import java.util.List;

import static java.util.Arrays.asList;

public class SupportedActionOrEventStory extends ConfigurableEmbedder {

    private static final String NOT_SUPPORTED = "notSupported";
    private static final String SUPPORTED = "supported";

    private List<SimpleMessage> messages = new LinkedList<SimpleMessage>();


    @Test
    public void run() throws Throwable {
        Embedder embedder = configuredEmbedder();
        embedder.useStoryRunner(new PatchedStoryRunner());
        StoryPathResolver pathResolver = embedder.configuration().storyPathResolver();
        String storyPath = pathResolver.resolve(this.getClass());
        try {
            embedder.runStoriesAsPaths(asList(storyPath));
        } finally {
            embedder.generateCrossReference();
        }
    }

    @Override
    public Configuration configuration() {
        return new MostUsefulConfiguration()
                .useStoryLoader(new LoadFromClasspath(this.getClass()))
                .useStoryReporterBuilder(new StoryReporterBuilder().withDefaultFormats().withFormats(Format.CONSOLE, Format.TXT))
                .usePendingStepStrategy(new FailingUponPendingStep());
    }

    @Override
    public InjectableStepsFactory stepsFactory() {
        return new InstanceStepsFactory(configuration(), this);
    }

    @Given("a message with <actionSupportability> action and <eventTypeSupportability> event")
    public void given(
            @Named("actionSupportability") String actionSupportability,
            @Named("eventTypeSupportability") String eventTypeSupportability,
            @Named("supportedActions") String supportedActions,
            @Named("supportedEventTypes") String supportedEventTypes,
            @Named("notSupportedActions") String notSupportedActions,
            @Named("notSupportedEventTypes") String notSupportedEventTypes) {
        List<String> actions = new LinkedList<String>();
        if (actionSupportability.equals(SUPPORTED)) {
            actions.addAll(asList(supportedActions.split(",")));
        } else if (actionSupportability.equals(NOT_SUPPORTED)) {
            actions.addAll(asList(notSupportedActions.split(",")));
        } else {
            throw new IllegalStateException("wrong action supportability parameter: " + actionSupportability);
        }
        List<String> eventTypes = new LinkedList<String>();
        if (eventTypeSupportability.equals(SUPPORTED)) {
            eventTypes.addAll(asList(supportedEventTypes.split(",")));
        } else if (eventTypeSupportability.equals(NOT_SUPPORTED)) {
            eventTypes.addAll(asList(notSupportedEventTypes.split(",")));
        } else {
            throw new IllegalStateException("wrong evenType supportability parameter: " + eventTypeSupportability);
        }

        for (String givenAction : actions) {
            for (String givenEventType : eventTypes) {
                SimpleMessage message = new SimpleMessageBuilder()
                        .withAction(givenAction)
                        .withEventType(givenEventType)
                        .build();
                messages.add(message);
            }
        }

    }

    @When("it is received")
    public void when() {
        for (SimpleMessage message : messages) {
            System.out.println("Message [" + message + "] received");
        }
    }

    @Then("message is consumed without error")
    public void then() {
        for (SimpleMessage message : messages) {
            System.out.println("Message [" + message + "] consumed");
        }
    }
}
