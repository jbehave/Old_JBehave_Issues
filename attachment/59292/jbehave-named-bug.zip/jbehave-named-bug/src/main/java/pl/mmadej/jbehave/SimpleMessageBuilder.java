package pl.mmadej.jbehave;


public class SimpleMessageBuilder {
    
    private String action;
    private String eventType;
    
    public SimpleMessageBuilder withAction(String action){
        this.action = action;
        return this;
    }
    
    public SimpleMessageBuilder withEventType(String eventType){
        this.eventType = eventType;
        return this;
    }

    public SimpleMessage build(){
        return new SimpleMessage(action, eventType);
    }
}
