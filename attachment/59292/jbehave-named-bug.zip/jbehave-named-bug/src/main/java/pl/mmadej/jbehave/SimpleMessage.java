package pl.mmadej.jbehave;


import org.apache.commons.lang.builder.ToStringBuilder;

public class SimpleMessage {

    private String action;
    private String evenType;

    public SimpleMessage(String action, String eventType) {
        this.action = action;
        this.evenType = eventType;
    }

    @Override
    public String toString() {
        return new ToStringBuilder(this)
                .append("action", action)
                .append("eventType", evenType)
                .toString();
    }
}
