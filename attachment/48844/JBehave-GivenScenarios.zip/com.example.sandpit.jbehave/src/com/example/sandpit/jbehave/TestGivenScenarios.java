package com.example.sandpit.jbehave;

import org.jbehave.scenario.MostUsefulConfiguration;
import org.jbehave.scenario.Scenario;

public class TestGivenScenarios extends Scenario {

  public TestGivenScenarios() {
    super(new MostUsefulConfiguration());
    addSteps(new SandpitSteps());
  }

}
