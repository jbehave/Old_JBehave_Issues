package com.example.sandpit.jbehave;

import org.jbehave.scenario.annotations.Given;
import org.jbehave.scenario.annotations.Then;
import org.jbehave.scenario.steps.Steps;

public class SandpitSteps extends Steps {

  @Given("I do nothing")
  public void doNothing() {
  }

  @Then("I fail")
  public void doFail() {
    throw new RuntimeException();
  }

  @Then("I pass")
  public void doPass() {
  }
}
