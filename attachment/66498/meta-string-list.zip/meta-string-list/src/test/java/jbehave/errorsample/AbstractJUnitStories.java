package jbehave.errorsample;

import static org.jbehave.core.reporters.Format.CONSOLE;
import static org.jbehave.core.reporters.Format.HTML;
import static org.jbehave.core.reporters.Format.TXT;
import static org.jbehave.core.reporters.Format.XML;

import java.util.Locale;

import org.jbehave.core.configuration.Configuration;
import org.jbehave.core.configuration.Keywords;
import org.jbehave.core.configuration.MostUsefulConfiguration;
import org.jbehave.core.embedder.Embedder;
import org.jbehave.core.failures.FailingUponPendingStep;
import org.jbehave.core.i18n.LocalizedKeywords;
import org.jbehave.core.junit.JUnitStories;
import org.jbehave.core.reporters.StoryReporterBuilder;

/**
 * The class that needs to be extended to configure JBehave runner.
 * 
 * @author Matthieu Mestrez
 * @since Sep 26, 2014
 */
public abstract class AbstractJUnitStories extends JUnitStories {
    
    @Override
    public Embedder configuredEmbedder() {
        
        Embedder configuredEmbedder = super.configuredEmbedder();
        
        configuredEmbedder.
            embedderControls().
            doIgnoreFailureInStories(true).
            doIgnoreFailureInView(true);
        
        return configuredEmbedder;
    }
    
    @Override
    public Configuration configuration() {
        Keywords keywords = new LocalizedKeywords(Locale.ENGLISH);
        
        StoryReporterBuilder reporterBuilder = new StoryReporterBuilder().
            withDefaultFormats().
            withFormats(CONSOLE, TXT, HTML, XML).
            withKeywords(keywords).
            withFailureTrace(true);
        
        return new MostUsefulConfiguration().
            useStoryReporterBuilder(reporterBuilder).
            usePendingStepStrategy(new FailingUponPendingStep());
    }

}
