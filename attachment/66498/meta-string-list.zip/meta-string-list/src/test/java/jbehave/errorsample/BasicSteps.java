/*
 * Copyright (c) Smals
 */
package jbehave.errorsample;

import java.util.List;

import org.jbehave.core.annotations.BeforeScenario;
import org.jbehave.core.annotations.Given;
import org.jbehave.core.annotations.Named;
import org.jbehave.core.annotations.Then;
import org.jbehave.core.annotations.When;

public class BasicSteps {

    @BeforeScenario
    public void initializeDataset(@Named("Dataset") List<String> datasets) {
        
        for (String dataset : datasets) {
            System.out.println("About to load datasets " + dataset);
        }
        
    }
    
    @Given("a started application") 
    public void environmnetStarted() {
        System.out.println("Starting up environmnet");
    }

    @When("I modify the company $companyId")
    public void modifyCompany(String companyId) {
        System.out.println("Modifying company with Id " + companyId);
    }
    @Then("an email should be sent to the owner")
    public void assertEmailSent() {
        System.out.println("Assertion that the email is sent");
    }
    
}
