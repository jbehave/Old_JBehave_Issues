/*
 * Copyright (c) Smals
 */
package jbehave.errorsample;

import static junit.framework.Assert.assertTrue;

import org.jbehave.core.annotations.Given;
import org.jbehave.core.annotations.Then;
import org.jbehave.core.annotations.When;


/**
 * @author Matthieu Mestrez
 * @since Sep 26, 2014
 */
public class ManageTurnoverStep {

    @Given("a fresh environment")
    public void freshEnvironment() {
        System.out.println("The environment is fresh");
    }
    
    @When("I retrieve the legal persons")
    public void retrieveLegalPersons() {
        System.out.println("retrieve of legal persons");
    }
    
    @Then("an email should be sent for everyone")
    public void emailShouldBeSentForEveryLegalPerson() {
        assertTrue(true);
    }

    @Then("an error should be thrown")
    public void anErrorShouldBeThrown() {
        assertTrue(false);
    }
}
