/*
 * Copyright (c) Smals
 */
package jbehave.errorsample;

import static org.jbehave.core.io.CodeLocations.codeLocationFromPath;

import java.util.List;

import org.jbehave.core.io.StoryFinder;
import org.jbehave.core.steps.InjectableStepsFactory;
import org.jbehave.core.steps.InstanceStepsFactory;
import org.junit.Test;

/**
 * All the stories to be run.
 * 
 * @author Matthieu Mestrez
 * @since Sep 26, 2014
 */
public class BasicTest extends AbstractJUnitStories {

    @Override
    public InjectableStepsFactory stepsFactory() {
        return new InstanceStepsFactory(configuration(), 
            new BasicSteps());
    }
    
    @Override
    protected List<String> storyPaths() {
        return new StoryFinder().
            findPaths(codeLocationFromPath("src/test/resources"), 
                      "jbehave/errorsample/*.story", 
                      "");
    }

    @Test
    @Override
    public void run() throws Throwable {
        super.run();
    }
    
}
