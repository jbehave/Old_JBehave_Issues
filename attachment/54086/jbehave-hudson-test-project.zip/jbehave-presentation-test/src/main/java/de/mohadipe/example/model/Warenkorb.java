/**
 * 
 */
package de.mohadipe.example.model;

import java.math.BigDecimal;
import java.math.BigInteger;
import java.util.HashMap;
import java.util.Map;

/**
 * @author user
 * 
 */
public class Warenkorb {
	private Map<Produkt, BigInteger> inhalt = new HashMap<Produkt, BigInteger>();
	private Kunde kaeufer;

	public Kunde getKaeufer() {
		return kaeufer;
	}

	public void setKaeufer(Kunde kaeufer) {
		this.kaeufer = kaeufer;
	}

	public void addProdukt(Produkt produkt) {
		if (inhalt.containsKey(produkt)) {
			inhalt.get(produkt).add(BigInteger.ONE);
		} else {
			inhalt.put(produkt, BigInteger.ONE);
		}
	}
	
	public void removeProdukt(Produkt produkt) {
		if (inhalt.containsKey(produkt)) {
			inhalt.remove(produkt);
		}
	}
	
	public BigDecimal getRechnugsPreis() {
		BigDecimal erg = BigDecimal.ZERO;
		for (Produkt produkt : inhalt.keySet()) {
			BigDecimal tmp = produkt.getPreis().multiply(BigDecimal.valueOf(inhalt.get(produkt).doubleValue()));
			erg.add(tmp);
		}
		return erg;
	}
}
