/**
 * 
 */
package de.mohadipe.example.model;

import java.math.BigInteger;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * @author user
 * 
 */
public class Bestand {
	private Map<Produkt, BigInteger> inhalt = new HashMap<Produkt, BigInteger>();

	public void addProdukt(Produkt produkt) {
		if (inhalt.containsKey(produkt)) {
			inhalt.get(produkt).add(BigInteger.ONE);
		} else {
			inhalt.put(produkt, BigInteger.ONE);
		}
	}
	
	public void removeProdukt(Produkt produkt) {
		if (inhalt.containsKey(produkt)) {
			inhalt.remove(produkt);
		}
	}
	
	public int anzahlProdukte() {
		return inhalt.size();
	}
	
	public List<Produkt> sucheProdukteByString(String suchString) {
		List<Produkt> erg = new ArrayList<Produkt>();
		for (Produkt produkt : inhalt.keySet()) {
			if (produkt.sucheNachNamen(suchString)) {
				erg.add(produkt);
			}
		}
		return erg;
	}
}
