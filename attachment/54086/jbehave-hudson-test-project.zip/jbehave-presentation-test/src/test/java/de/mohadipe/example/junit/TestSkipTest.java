package de.mohadipe.example.junit;

import junit.framework.Assert;

import org.junit.Test;

public class TestSkipTest {
	
	@Test
	public void failedTest() {
		Assert.fail("Tests nicht skipped!!!");
	}
}
