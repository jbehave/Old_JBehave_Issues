/**
 * 
 */
package de.mohadipe.example.spec.steps;

import java.util.List;

import junit.framework.Assert;

import org.jbehave.core.annotations.Given;
import org.jbehave.core.annotations.Then;

import de.mohadipe.example.model.Bestand;
import de.mohadipe.example.model.Produkt;

/**
 * @author user
 * 
 */
public class IstProduktInBestand {

	private BestandErstellen bestand;
	private String suchString;

	public IstProduktInBestand(BestandErstellen bestandErstellen) {
		bestand = bestandErstellen;
	}

	@Given("die Eingabe lautet %suchString")
	public void suchEingabe(String suchString) {
		this.suchString = suchString;
	}

	@Then("muss ein Produkt gefunden werden")
	public void pruefeErgebnisDerSuche() {
		Bestand bestand = this.bestand.getBestand();
		List<Produkt> produkteByString = bestand.sucheProdukteByString(suchString);
		Assert.assertEquals(1, produkteByString.size());
	}
}
