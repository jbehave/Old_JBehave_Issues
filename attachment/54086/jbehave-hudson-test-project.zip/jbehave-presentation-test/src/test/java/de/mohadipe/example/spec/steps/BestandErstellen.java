
/**
 * 
 */
package de.mohadipe.example.spec.steps;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

import junit.framework.Assert;

import org.jbehave.core.annotations.Given;
import org.jbehave.core.annotations.Named;
import org.jbehave.core.annotations.Then;
import org.jbehave.core.annotations.When;

import de.mohadipe.example.model.Bestand;
import de.mohadipe.example.model.Produkt;

/**
 * @author user
 * 
 */
public class BestandErstellen {
	private Bestand bestand;
	private List<Produkt> produkte = new ArrayList<Produkt>();

	@Given("Es gibt die Produkte <id> <name> <preis>")
	public void vorgegebeneProdukte(@Named("id") int id,@Named("name") String name,@Named("preis") double preis) {
		Produkt produkt = new Produkt();
		produkt.setId(id);
		produkt.setName(name);
		produkt.setPreis(BigDecimal.valueOf(preis));
		produkte.add(produkt);
	}

	@When("Die Produkte dem Bestand hinzugef�gt werden")
	public void produkteBestandHinzufuegen() {
		bestand = new Bestand();
		for (Produkt produkt : produkte) {
			bestand.addProdukt(produkt);
		}
	}

	@Then("m�ssen <erg> Produkte im Bestand sein")
	public void anzahlProdukteInBestand(@Named("erg") int anzahl) {
		Assert.assertEquals(anzahl, bestand.anzahlProdukte());
	}
	
	public Bestand getBestand() {
		return bestand;
	}
}
