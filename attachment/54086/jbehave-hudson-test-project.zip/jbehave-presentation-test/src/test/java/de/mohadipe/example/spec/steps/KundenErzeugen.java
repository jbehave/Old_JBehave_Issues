/**
 * 
 */
package de.mohadipe.example.spec.steps;

import java.util.ArrayList;
import java.util.List;

import org.jbehave.core.annotations.Given;
import org.jbehave.core.annotations.Named;
import org.jbehave.core.annotations.Then;
import org.junit.Assert;

import de.mohadipe.example.model.Adresse;
import de.mohadipe.example.model.Kunde;

/**
 * @author user
 * 
 */
public class KundenErzeugen {
	private List<Kunde> kunden = new ArrayList<Kunde>();

	@Given("Es gibt die Kunden <id> <name> mit Ihren Adressen <ida> <strasse> <hnr> <plz> <ort>")
	public void kundenErzeugen(@Named("id") int id, @Named("name") String name, @Named("ida") int ida,
			@Named("strasse") String strasse, @Named("hnr") String hnr, @Named("plz") String plz, @Named("ort") String ort) {
		Kunde kunde = new Kunde();
		kunde.setId(id);
		kunde.setName(name);
		Adresse adresse = new Adresse();
		adresse.setId(ida);
		adresse.setStrasse(strasse);
		adresse.setHnr(hnr);
		adresse.setPlz(plz);
		adresse.setOrt(ort);
		kunde.setAdresse(adresse);
		kunden.add(kunde);
	}
	
	@Then("m�ssen <erg> Kunden angelegt sein")
	public void pruefeAnzahlKunden(@Named("erg") int erg) {
		Assert.assertEquals(erg, kunden.size());
		
	}
}
