package jbehave.config;

import org.junit.Test;

public class TestLauf {
	@Test
	public void testLauf() throws Throwable {
//		TraderStories traderStories = new TraderStories();
//		traderStories.run();
	}
}
