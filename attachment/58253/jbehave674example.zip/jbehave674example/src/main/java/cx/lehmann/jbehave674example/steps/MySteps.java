package cx.lehmann.jbehave674example.steps;

import org.jbehave.core.annotations.Given;
import org.jbehave.core.annotations.Named;

public class MySteps {
  @Given("a <parameter>")
  public void givenparameter(@Named("parameter") String parameter) {
  }

}
