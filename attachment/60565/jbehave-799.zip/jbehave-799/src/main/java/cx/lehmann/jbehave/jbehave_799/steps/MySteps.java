package cx.lehmann.jbehave.jbehave_799.steps;

import org.jbehave.core.annotations.Given;
import org.jbehave.core.annotations.Named;
import org.jbehave.core.annotations.Pending;
import org.jbehave.core.annotations.Then;
import org.jbehave.core.annotations.When;

public class MySteps {
	@Given("a <string>")
	public void givenAstring(@Named("string")String string) {
	}

}
