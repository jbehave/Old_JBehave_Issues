package calculator;

import static org.jbehave.core.reporters.Format.CONSOLE;
import static org.jbehave.core.reporters.Format.HTML;
import static org.jbehave.core.reporters.Format.STATS;
import static org.jbehave.core.reporters.Format.TXT;

import java.net.MalformedURLException;
import java.net.URL;
import java.util.Arrays;
import java.util.List;

import org.jbehave.core.configuration.Configuration;
import org.jbehave.core.configuration.MostUsefulConfiguration;
import org.jbehave.core.io.LoadFromRelativeFile;
import org.jbehave.core.io.StoryFinder;
import org.jbehave.core.junit.JUnitStories;
import org.jbehave.core.parsers.gherkin.GherkinStoryParser;
import org.jbehave.core.reporters.StoryReporterBuilder;
import org.jbehave.core.steps.InjectableStepsFactory;
import org.jbehave.core.steps.InstanceStepsFactory;
import org.jbehave.core.steps.ParameterControls;

import com.google.common.util.concurrent.MoreExecutors;

public class CalcConfig extends JUnitStories {

	private static final String FEATURES = "**/*.feature";

	private URL url;

	/*@Override
	public Embedder configuredEmbedder() {

		super.configuredEmbedder().useMetaFilters(Arrays.asList("__-skip"));

		return super.configuredEmbedder();
	}*/
	
	public CalcConfig() {
		//configuredEmbedder().useExecutorService(MoreExecutors.sameThreadExecutor());
		configuredEmbedder().useMetaFilters(Arrays.asList("-skip"));
	}

	@Override
	public Configuration configuration() {
		try {
			url = new URL("file://D:/Users/212038146/workspace/Calculator/src");
		} catch (MalformedURLException e) {
			e.printStackTrace();
		}
		return new MostUsefulConfiguration()
				.useStoryParser(new GherkinStoryParser())
				.useStoryLoader(new LoadFromRelativeFile(url))
				.useStoryReporterBuilder(
						new StoryReporterBuilder().withDefaultFormats()
								.withFormats(STATS, HTML, TXT, CONSOLE))
				.useParameterControls(
						new ParameterControls()
								.useDelimiterNamedParameters(true));

	}

	@Override
	public InjectableStepsFactory stepsFactory() {
		return new InstanceStepsFactory(configuration(), new CalcSteps());
	}

	@Override
	protected List<String> storyPaths() {
		return new StoryFinder().findPaths(url, FEATURES, "");
	}

}