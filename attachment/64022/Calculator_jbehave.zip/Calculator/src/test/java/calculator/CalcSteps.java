package calculator;


import static junit.framework.Assert.assertEquals;

import org.jbehave.core.annotations.Given;
import org.jbehave.core.annotations.Then;
import org.jbehave.core.annotations.When;


public class CalcSteps {

    private Calculator calculator;
    String msg;
    
    @Given("a calculator")
    public void newCalculator() {
        calculator = new Calculator();
    }
    
    @When("I divide $n1 by $n2")
    public void divide(int n1, int n2) {
    	try {
        calculator.divide(n1, n2);
    	}
    	catch(ArithmeticException e)
    	{			
    		msg = e.getMessage();
    	}
    }    
    
    @Then("I should get $answer")
    public void answer(String answer) {
    	try{
    		  int num = Integer.parseInt(answer);
    		  assertEquals(num, calculator.getAnswer());
    		} catch (NumberFormatException e) {
    		  assertEquals(answer, msg);
    		}
        
    }
}