package calculator;

public class Calculator {

    private int answer;
    
    public void add(Integer n1, Integer n2) {
        answer = n1 + n2;        
    }

    public void subtract(Integer n1, Integer n2) {
        answer = n2 - n1;
    }

    public void multiply(Integer n1, Integer n2) {
        answer = n1 * n2;
    }

    public void divide(Integer n1, Integer n2) {
        answer = n1 / n2;
    }

    public int getAnswer() {        
        return answer;
    }

}