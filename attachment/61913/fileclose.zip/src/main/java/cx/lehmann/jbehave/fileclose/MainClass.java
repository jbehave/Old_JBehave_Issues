package cx.lehmann.jbehave.fileclose;

import java.io.BufferedReader;
import java.io.File;
import java.io.InputStreamReader;

public class MainClass {

    /**
     * @param args
     * @throws Throwable 
     */
    public static void main(String[] args) throws Throwable {
        new MyStories().run();
        System.out.println("file size: "+new File("target/jbehave/AfterStories.html").length());
        System.out.print("press enter:");
        BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
        br.readLine();
        System.out.println("finished");
    }

}
