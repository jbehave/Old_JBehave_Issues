package org.jbehave.web.selenium;

import java.net.MalformedURLException;

import org.apache.xml.serializer.ToUnknownStream;
import org.openqa.selenium.ScreenOrientation;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.android.AndroidDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.htmlunit.HtmlUnitDriver;
import org.openqa.selenium.ie.InternetExplorerDriver;

/**
 * Provides WebDriver instances based on system property "browser".
 */
public class PropertyWebDriverProvider extends DelegatingWebDriverProvider {

    public enum Browser {
        FIREFOX, IE, CHROME, HTML, ANDROID
    }

    public void initialize() {
        Browser browser = Browser.valueOf(Browser.class, System.getProperty("browser", "firefox").toUpperCase());
        delegate = createDriver(browser);
    }

    protected WebDriver createDriver(Browser browser) {
        switch (browser) {
        case FIREFOX:
        default:
            return new FirefoxDriver();
        case IE:
            return new InternetExplorerDriver();
        case CHROME:
            return new ChromeDriver();
        case HTML:
            return new HtmlUnitDriver();
        case ANDROID:
        	final String androidUrl = System.getProperty("webdriver.android.url", "http://localhost:8080/hub");
        	final ScreenOrientation orientation = ScreenOrientation.valueOf(System.getProperty("webdriver.screen.orientation", "portrait").toUpperCase());
        	AndroidDriver androidDriver;
			try {
				androidDriver = new AndroidDriver(androidUrl);
			} catch (MalformedURLException e) {
				throw new new UnsupportedOperationException(e);
			}
        	androidDriver.rotate(orientation);
			return androidDriver;
        }
    }

}
