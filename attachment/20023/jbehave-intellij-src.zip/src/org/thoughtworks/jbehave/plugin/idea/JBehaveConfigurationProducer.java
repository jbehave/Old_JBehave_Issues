package org.thoughtworks.jbehave.plugin.idea;

import com.intellij.execution.ExecutionUtil;
import com.intellij.execution.Location;
import com.intellij.execution.actions.ConfigurationContext;
import com.intellij.execution.configurations.ConfigurationType;
import com.intellij.execution.impl.RunnerAndConfigurationSettingsImpl;
import com.intellij.execution.junit.RuntimeConfigurationProducer;
import com.intellij.psi.PsiClass;
import com.intellij.psi.PsiElement;

public class JBehaveConfigurationProducer extends RuntimeConfigurationProducer implements Cloneable {
    private PsiClass behaviorClass;

    public JBehaveConfigurationProducer(PsiClass behaviorClass, ConfigurationType configurationType) {
        super(configurationType);
        this.behaviorClass = behaviorClass;
    }

    public PsiElement getSourceElement() {
        return behaviorClass;
    }

    protected RunnerAndConfigurationSettingsImpl createConfigurationByElement(Location location, ConfigurationContext configurationContext) {
        location = ExecutionUtil.stepIntoSingleClass(location);
        final PsiElement psiElement = location.getPsiElement();
        PsiClass aClass = getPsiClass(psiElement);
        if(aClass == null) return null;
        RunnerAndConfigurationSettingsImpl settings = cloneTemplateConfiguration(location.getProject(), configurationContext);
        JBehaveRunConfiguration configuration = (JBehaveRunConfiguration) settings.getConfiguration();
        configuration.setBehaviorClass(ClassUtil.fullName(aClass));
        configuration.setModule(ExecutionUtil.findModule(aClass));
        configuration.setName(ClassUtil.shortName(aClass));
        return settings;
    }


    public int compareTo(Object o) {
        return -1;
    }

    private PsiClass getPsiClass(PsiElement element) {
        for (PsiElement current = element; current != null; current = current.getParent()) {
            if (current instanceof PsiClass) {
                return (PsiClass)current;
            }
        }
        return null;
    }
}
