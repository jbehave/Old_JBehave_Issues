package org.thoughtworks.jbehave.plugin.idea;

import com.intellij.openapi.util.IconLoader;

import javax.swing.*;

public final class Icons {
    public static final Icon LOGO = IconLoader.getIcon("/behave.png");
//    public static final Icon LOGO = IconLoader.getIcon("/logo.png");
}
