package steps;

import static junit.framework.Assert.fail;

import org.jbehave.core.annotations.Given;
import org.jbehave.core.annotations.Then;
import org.jbehave.core.steps.Steps;

public class MySteps extends Steps {

	@Given("a step that failed")
	public void aStepThatFailed() {
		fail();
	}

	@Given("a step that succeeded")
	public void aStepThatSucceeded() {
	}

	@Then("test result is visualized as succeeded")
	public void shoppingCartShouldBeVisible() {
		// TODO check if visualized as success
	}

}
