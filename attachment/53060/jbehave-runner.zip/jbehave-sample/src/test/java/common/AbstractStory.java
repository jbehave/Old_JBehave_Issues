package common;

import java.util.List;

import jbehave.junit.JUnitStory;

import org.jbehave.core.configuration.Configuration;
import org.jbehave.core.configuration.MostUsefulConfiguration;
import org.jbehave.core.reporters.Format;
import org.jbehave.core.reporters.StoryReporterBuilder;
import org.jbehave.core.steps.CandidateSteps;
import org.jbehave.core.steps.InstanceStepsFactory;
import org.junit.Before;


public abstract class AbstractStory extends JUnitStory {

	@Before
	public void setUp() {
		useConfiguration(createConfiguration());
		addSteps(createCandidateSteps());
	}

	public Configuration createConfiguration() {
		StoryReporterBuilder storyReporterBuilder = new StoryReporterBuilder() //
				.withFailureTrace(true) //
				.withFormats(Format.CONSOLE, Format.XML);
		return new MostUsefulConfiguration() //
				.useStoryReporterBuilder(storyReporterBuilder);
	}

	private List<CandidateSteps> createCandidateSteps() {
		return new InstanceStepsFactory(configuration(), getCandidateSteps()).createCandidateSteps();
	}

	protected abstract List<Object> getCandidateSteps();

}
