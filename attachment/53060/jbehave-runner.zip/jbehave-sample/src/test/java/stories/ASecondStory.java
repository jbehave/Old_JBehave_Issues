package stories;

import java.util.Arrays;
import java.util.List;

import org.jbehave.core.configuration.Configuration;
import org.jbehave.core.failures.FailingUponPendingStep;

import steps.MySteps;

import common.AbstractStory;

public class ASecondStory extends AbstractStory {

	@Override
	public Configuration createConfiguration() {
		Configuration configuration = super.createConfiguration();
		return configuration.usePendingStepStrategy(new FailingUponPendingStep());
	}

	@Override
	protected List<Object> getCandidateSteps() {
		return Arrays.<Object> asList(new MySteps());
	}

}
