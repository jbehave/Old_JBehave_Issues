package stories;

import java.util.Arrays;
import java.util.List;

import common.AbstractStory;

import steps.MySteps;

public class AStoryWithMultipleScenarios extends AbstractStory {

	@Override
	protected List<Object> getCandidateSteps() {
		return Arrays.<Object> asList(new MySteps());
	}

}
