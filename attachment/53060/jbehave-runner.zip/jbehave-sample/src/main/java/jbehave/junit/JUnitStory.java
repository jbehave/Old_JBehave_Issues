package jbehave.junit;

import static java.util.Arrays.asList;

import org.jbehave.core.ConfigurableEmbedder;
import org.jbehave.core.embedder.Embedder;
import org.jbehave.core.io.StoryPathResolver;
import org.junit.Test;
import org.junit.runner.RunWith;

@RunWith(JUnitStoryRunner.class)
public class JUnitStory extends ConfigurableEmbedder {

	private JUnitFormat format;

	public JUnitStory() {
	}

	public void setFormat(JUnitFormat format) {
		this.format = format;
	}

	@Test
	public void run() throws Throwable {
		Embedder embedder = configuredEmbedder();
		if (format != null) {
			format.setPendingStepStrategy(embedder.configuration().pendingStepStrategy());
			embedder.configuration().storyReporterBuilder().withFormats(format);
		}
		StoryPathResolver pathResolver = embedder.configuration().storyPathResolver();
		String storyPath = pathResolver.resolve(this.getClass());
		embedder.runStoriesAsPaths(asList(storyPath));
	}

}
