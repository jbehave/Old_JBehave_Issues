package jbehave.junit;

import org.jbehave.core.failures.PendingStepStrategy;
import org.jbehave.core.reporters.FilePrintStreamFactory;
import org.jbehave.core.reporters.Format;
import org.jbehave.core.reporters.StoryReporter;
import org.jbehave.core.reporters.StoryReporterBuilder;
import org.junit.runner.Description;
import org.junit.runner.notification.RunNotifier;

class JUnitFormat extends Format {

	private final RunNotifier notifier;
	private final Description desc;
	private PendingStepStrategy pendingStepStrategy;

	JUnitFormat(RunNotifier notifier, Description desc) {
		super("JUNIT");
		this.notifier = notifier;
		this.desc = desc;
	}

	public void setPendingStepStrategy(PendingStepStrategy pendingStepStrategy) {
		this.pendingStepStrategy = pendingStepStrategy;
	}

	@Override
	public StoryReporter createStoryReporter(FilePrintStreamFactory factory, StoryReporterBuilder storyReporterBuilder) {
		return new JUnitStoryReporter(notifier, desc, pendingStepStrategy);
	}
}
