package jbehave.junit;

import org.jbehave.core.embedder.Embedder;
import org.jbehave.core.io.StoryPathResolver;
import org.jbehave.core.model.Scenario;
import org.jbehave.core.model.Story;
import org.junit.runner.Description;
import org.junit.runner.Runner;
import org.junit.runner.notification.RunNotifier;
import org.junit.runners.model.InitializationError;
import org.junit.runners.model.TestClass;

public class JUnitStoryRunner extends Runner {

	private Story story;
	private Description desc;
	private final Class<?> klass;

	public JUnitStoryRunner(Class<?> klass) throws InitializationError {
		this.klass = klass;
		story = getStory(createTest(klass));
	}

	private JUnitStory createTest(Class<?> klass) {
		try {
			return (JUnitStory) new TestClass(klass).getOnlyConstructor().newInstance();
		} catch (Exception e) {
			throw new RuntimeException(e);
		}
	}

	@Override
	public Description getDescription() {
		if (desc == null) {
			desc = Description.createSuiteDescription(story.getDescription().asString());
			for (Scenario scenario : story.getScenarios()) {
				desc.addChild(createDescription(scenario));
			}
		}
		return desc;
	}

	private Description createDescription(Scenario scenario) {
		return Description.createTestDescription(klass, "Scenario: " + scenario.getTitle());
	}

	@Override
	public void run(RunNotifier notifier) {
		notifier.fireTestRunStarted(getDescription());
		createRunner(notifier).run(new RunNotifier());
	}

	private Runner createRunner(RunNotifier notifier) {
		try {
			return new ActualRunner(klass, new JUnitFormat(notifier, desc));
		} catch (InitializationError e) {
			throw new RuntimeException(e);
		}
	}

	private Story getStory(JUnitStory story) {
		Embedder embedder = story.configuredEmbedder();
		StoryPathResolver pathResolver = embedder.configuration().storyPathResolver();
		String storyPath = pathResolver.resolve(story.getClass());
		return story.configuredEmbedder().storyRunner().storyOfPath(embedder.configuration(), storyPath);
	}
}