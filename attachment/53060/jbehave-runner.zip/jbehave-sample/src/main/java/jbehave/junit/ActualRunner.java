package jbehave.junit;

import org.junit.runners.BlockJUnit4ClassRunner;
import org.junit.runners.model.InitializationError;

class ActualRunner extends BlockJUnit4ClassRunner {

	private JUnitFormat format;

	ActualRunner(Class<?> klass, JUnitFormat format) throws InitializationError {
		super(klass);
		this.format = format;
	}

	@Override
	protected Object createTest() throws Exception {
		JUnitStory story = (JUnitStory) getTestClass().getOnlyConstructor().newInstance();
		story.setFormat(format);
		return story;
	}
}
