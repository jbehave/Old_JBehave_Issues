package example;

import static java.util.Arrays.asList;
import static org.jbehave.core.io.CodeLocations.codeLocationFromPath;

import java.util.List;

import org.jbehave.core.Embeddable;
import org.jbehave.core.configuration.Configuration;
import org.jbehave.core.configuration.MostUsefulConfiguration;
import org.jbehave.core.failures.PassingUponPendingStep;
import org.jbehave.core.io.CodeLocations;
import org.jbehave.core.io.LoadFromClasspath;
import org.jbehave.core.io.StoryFinder;
import org.jbehave.core.junit.AnnotatedEmbedderRunner;
import org.jbehave.core.junit.JUnitStories;
import org.jbehave.core.parsers.RegexPrefixCapturingPatternParser;
import org.jbehave.core.reporters.FilePrintStreamFactory.ResolveToSimpleName;
import org.jbehave.core.reporters.StoryReporterBuilder;
import org.jbehave.core.steps.InjectableStepsFactory;
import org.jbehave.core.steps.guice.GuiceStepsFactory;
import org.junit.runner.RunWith;

import com.google.inject.Guice;
import com.google.inject.Injector;

// @RunWith ( JUnitReportingRunner.class )
@RunWith ( AnnotatedEmbedderRunner.class )
public class ScenarioScopeStories extends JUnitStories {

    public ScenarioScopeStories() {

        configuredEmbedder().embedderControls().doGenerateViewAfterStories( true ).doIgnoreFailureInStories( false ).doIgnoreFailureInView( true ).useThreads( 1 ).useStoryTimeoutInSecs( 600 );
    };

    @Override
    public Configuration configuration() {

        Class<? extends Embeddable> embeddableClass = this.getClass();
        StoryReporterBuilder reporter = new StoryReporterBuilder().withCodeLocation( CodeLocations.codeLocationFromClass( embeddableClass ) ).withDefaultFormats().withPathResolver( new ResolveToSimpleName() ).withRelativeDirectory( "bdd" );
        return new MostUsefulConfiguration().usePendingStepStrategy( new PassingUponPendingStep() ).useStoryLoader( new LoadFromClasspath( this.getClass() ) ).useStoryReporterBuilder( reporter ).useStepPatternParser(
                new RegexPrefixCapturingPatternParser( "$" ) );
    }

    @Override
    public InjectableStepsFactory stepsFactory() {

        Injector injector = Guice.createInjector( new AppModule() );
        return new GuiceStepsFactory( configuration(), injector );
    }

    @Override
    protected List<String> storyPaths() {

        String searchInDirectory = codeLocationFromPath( "src/main/resources" ).getFile();
        return new StoryFinder().findPaths( searchInDirectory, asList( "test.story" ), null );
    }

}
