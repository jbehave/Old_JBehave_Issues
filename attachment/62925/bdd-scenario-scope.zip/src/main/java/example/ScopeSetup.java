package example;

import org.jbehave.core.annotations.AfterScenario;
import org.jbehave.core.annotations.BeforeScenario;

import com.google.inject.Inject;
import com.google.inject.name.Named;

public class ScopeSetup {

    private SimpleScope scope;

    @Inject
    public ScopeSetup( @Named ( "scenarioScope" ) SimpleScope scope ) {
        this.scope = scope;
    }

    @BeforeScenario
    public void beforeScenario() {
        scope.enter();
    }

    @AfterScenario
    public void afterScenario() {
        scope.exit();
    }
}
