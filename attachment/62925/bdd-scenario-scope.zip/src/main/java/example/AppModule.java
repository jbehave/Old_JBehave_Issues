package example;

import com.google.inject.AbstractModule;
import com.google.inject.Singleton;
import com.google.inject.name.Names;

public class AppModule extends AbstractModule {

    @Override
    public void configure() {
        bind( ScopeSetup.class ).in( Singleton.class );
        bind( ScenarioScopeSteps.class ).in( ScenarioScope.class );

        SimpleScope scenarioScope = new SimpleScope();
        bindScope( ScenarioScope.class, scenarioScope );
        bind( SimpleScope.class ).annotatedWith( Names.named( "scenarioScope" ) ).toInstance( scenarioScope );

        bind( State.class ).in( ScenarioScope.class );

    }
}
