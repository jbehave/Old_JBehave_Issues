package example;

import org.jbehave.core.annotations.Given;
import org.jbehave.core.annotations.Then;
import org.jbehave.core.annotations.When;

import com.google.inject.Inject;

public class ScenarioScopeSteps {

    private State state;

    @Inject
    public ScenarioScopeSteps( State state ) {
        this.state = state;
        System.out.println( this );
    }

    @Given ( "I have $val" )
    public void iHave( String val ) {
        System.out.println( state );
        System.out.println( val );
    }

    @When ( "I do $val" )
    public void iDo( String val ) {
        System.out.println( state );
        System.out.println( val );
    }

    @Then ( "I should see $val" )
    public void iShouldSee( String val ) {
        System.out.println( state );
        System.out.println( val );
    }

}