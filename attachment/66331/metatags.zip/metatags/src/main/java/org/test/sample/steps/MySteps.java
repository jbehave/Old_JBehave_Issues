package org.test.sample.steps;



import org.jbehave.core.annotations.BeforeStories;
import org.jbehave.core.annotations.BeforeStory;
import org.jbehave.core.annotations.Given;
;

public class MySteps {
    
	@Given("I am a SIT step")
	public void iamstaging(){
		
	}
	
	@Given("I am a QA step")
	public void iamqa(){
		
	}
	
	@Given("I am a both step")
	public void iamboth(){
		
	}
	
	
}
