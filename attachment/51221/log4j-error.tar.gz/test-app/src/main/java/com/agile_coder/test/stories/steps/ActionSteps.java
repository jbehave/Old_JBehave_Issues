package com.agile_coder.test.stories.steps;

import static org.hamcrest.CoreMatchers.equalTo;
import static org.hamcrest.MatcherAssert.assertThat;

import org.jbehave.core.annotations.Given;
import org.jbehave.core.annotations.Then;
import org.jbehave.core.annotations.When;

public class ActionSteps {


	@Given("I do something that is given")
	public void setup() throws Exception {

	}

	@When("I do the thing I need to do")
	public void doAction() throws Exception {

	}

	@Then("the outcome is as expected")
	public void checkResult() throws Exception {

	}

}
