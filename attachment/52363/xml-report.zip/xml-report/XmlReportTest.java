package org.jbehave.core.report;


import static org.custommonkey.xmlunit.XMLAssert.assertXpathEvaluatesTo;
import static org.custommonkey.xmlunit.XMLAssert.assertXpathNotExists;

import java.io.FileInputStream;
import java.util.ArrayList;

import org.jbehave.core.configuration.Configuration;
import org.jbehave.core.configuration.MostUsefulConfiguration;
import org.jbehave.core.embedder.Embedder;
import org.jbehave.core.failures.SilentlyAbsorbingFailure;
import org.jbehave.core.reporters.StoryReporterBuilder;
import org.jbehave.core.reporters.StoryReporterBuilder.Format;
import org.jbehave.core.steps.MarkUnmatchedStepsAsPending;
import org.jbehave.core.steps.StepFinder;
import org.jbehave.core.steps.StepFinder.ByLevenshteinDistance;
import org.junit.BeforeClass;
import org.junit.Test;
import org.xml.sax.InputSource;

public class XmlReportTest {

	@BeforeClass
	public static void createTestReports() {

		Embedder embedder = new Embedder() {
			@Override
			public Configuration configuration() {

				Configuration configuration = new MostUsefulConfiguration()
						.useStoryReporterBuilder(
								new StoryReporterBuilder().withDefaultFormats()
										.withFormats(Format.XML))
						.useFailureStrategy(new SilentlyAbsorbingFailure())
						.useStepCollector(new MarkUnmatchedStepsAsPending(new StepFinder(new ByLevenshteinDistance())));

				return configuration;

			}

		};

		ArrayList<String> storyPaths = new ArrayList<String>();
		storyPaths.add("with_narrative.story");
		storyPaths.add("no_narrative.story");

		try {
			embedder.runStoriesAsPaths(storyPaths);
		} catch (Exception e) {

		}
	};

	
	@Test
	public void storyWithNarrativeShouldHaveReportTitle() throws Exception  {
		assertXpathEvaluatesTo("Story with narrative", "//story[1]/@title", new InputSource(new FileInputStream("target/jbehave/with_narrative.xml")));
	}
	
	@Test
	public void storyWithNoNarrativeShouldHaveNoReportTitleAttribute() throws Exception  {
		assertXpathNotExists("//story[1]/@title", new InputSource(new FileInputStream("target/jbehave/no_narrative.xml")));
	}
	
}
