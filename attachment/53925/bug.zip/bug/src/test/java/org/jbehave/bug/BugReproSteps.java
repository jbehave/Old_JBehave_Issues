package org.jbehave.bug;

import org.jbehave.core.annotations.BeforeScenario;
import org.jbehave.core.annotations.Given;
import org.jbehave.core.annotations.Then;
import org.jbehave.core.annotations.When;
import static org.hamcrest.Matchers.*;
import static org.junit.Assert.*;

public class BugReproSteps {
	
	private int numberOfTimesBeforeScenarioHasBeenCalled = 0;

	@BeforeScenario
	public void beforeScenario(){
		System.out.println("[BeforeScenario]");
		numberOfTimesBeforeScenarioHasBeenCalled++;
	}
	
	@Given ("you have a jbehave test with a before scenario")
	public void given(){
		System.out.println("[Given]");
	}
	
	@When ("you run example <number> test")
	public void when(int number){
		System.out.println("[When]");		
	}
	
	@Then ("BeforeScenario has been executed <number> times")
	public void then(int number){
		System.out.println("[Then]");
		assertThat(numberOfTimesBeforeScenarioHasBeenCalled, is(number));
	}

}
