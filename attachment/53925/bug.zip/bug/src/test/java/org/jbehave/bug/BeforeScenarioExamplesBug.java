package org.jbehave.bug;

import java.net.URL;
import java.text.SimpleDateFormat;
import java.util.List;
import java.util.Properties;

import org.jbehave.core.configuration.Configuration;
import org.jbehave.core.configuration.MostUsefulConfiguration;
import org.jbehave.core.io.CodeLocations;
import org.jbehave.core.io.LoadFromClasspath;
import org.jbehave.core.io.StoryPathResolver;
import org.jbehave.core.io.UnderscoredCamelCaseResolver;
import org.jbehave.core.junit.JUnitStory;
import org.jbehave.core.parsers.RegexPrefixCapturingPatternParser;
import org.jbehave.core.reporters.StoryReporterBuilder;
import org.jbehave.core.steps.CandidateSteps;
import org.jbehave.core.steps.InstanceStepsFactory;
import org.jbehave.core.steps.ParameterConverters;
import org.jbehave.core.steps.SilentStepMonitor;
import org.jbehave.paranamer.BytecodeReadingParanamer;
import org.jbehave.paranamer.CachingParanamer;

public class BeforeScenarioExamplesBug extends JUnitStory {
	public BeforeScenarioExamplesBug() {
        StoryPathResolver storyPathResolver = new UnderscoredCamelCaseResolver(".story");
        Class storyClass = this.getClass();
        Properties viewProperties = new Properties();
        viewProperties.put("decorateNonHtml", "true");
        URL codeLocation = CodeLocations.codeLocationFromClass(storyClass);
        Configuration configuration = new MostUsefulConfiguration()
                //.useStoryControls(new StoryControls().doDryRun(false).doSkipScenariosAfterFailure(false))
                .useStoryLoader(new LoadFromClasspath(storyClass.getClassLoader()))
                .useStoryReporterBuilder(new StoryReporterBuilder()
                    .withCodeLocation(codeLocation)
                    .withDefaultFormats()
                    .withViewResources(viewProperties)
                    .withFailureTrace(true))
                .useStoryPathResolver(storyPathResolver)
                .useParanamer(new CachingParanamer(new BytecodeReadingParanamer()))
                .useStepMonitor(new SilentStepMonitor())
                .useParameterConverters(new ParameterConverters()
                    .addConverters(new ParameterConverters.NumberConverter(), new ParameterConverters.DateConverter(new SimpleDateFormat("yyyy-MM-dd")))) // use custom date pattern
                .useStepPatternParser(new RegexPrefixCapturingPatternParser(
                "$"));
                 
        useConfiguration(configuration);
        addSteps(createSteps(configuration));
         
        configuredEmbedder().embedderControls().doGenerateViewAfterStories(true).doIgnoreFailureInStories(true);
	}

    public List<CandidateSteps> createSteps(Configuration configuration) {
        return new InstanceStepsFactory(configuration, new BugReproSteps()).createCandidateSteps();
    }

}
