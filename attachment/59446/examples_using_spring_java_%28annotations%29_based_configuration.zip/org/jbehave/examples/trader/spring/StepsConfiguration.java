package org.jbehave.examples.trader.spring;

import org.jbehave.examples.trader.service.TradingService;
import org.jbehave.examples.trader.steps.*;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class StepsConfiguration {

    @Bean
    public BeforeAfterSteps beforeAfterSteps() {
        return new BeforeAfterSteps();
    }

    @Bean
    public AndSteps andSteps() {
        return new AndSteps();
    }

    @Bean
    public CalendarSteps calendarSteps() {
        return new CalendarSteps();
    }

    @Bean
    public CompositeSteps compositeSteps() {
        return new CompositeSteps();
    }

    @Bean
    public PendingSteps pendingSteps() {
        return new PendingSteps();
    }

    @Bean
    public PriorityMatchingSteps priorityMatchingSteps() {
        return new PriorityMatchingSteps();
    }

    @Bean
    public SandpitSteps sandpitSteps() {
        return new SandpitSteps();
    }

    @Bean
    public SearchSteps searchSteps() {
        return new SearchSteps();
    }

    @Bean
    public TraderSteps traderSteps() {

        return new TraderSteps(new TradingService());
    }


    @Bean
    public AbstractSteps abstractSteps() {
        AbstractSteps result = new AbstractSteps() {

            @Override
            public void whenSomethingHappens() {

                System.out.println("AbstractSteps#whenSomethingHappens()");
            }
        };
        return result;
    }
}
