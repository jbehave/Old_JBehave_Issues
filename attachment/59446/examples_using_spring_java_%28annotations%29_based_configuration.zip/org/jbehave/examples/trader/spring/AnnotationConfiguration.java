package org.jbehave.examples.trader.spring;

import org.jbehave.core.configuration.spring.SpringStoryControls;
import org.jbehave.core.configuration.spring.SpringStoryReporterBuilder;
import org.jbehave.core.embedder.EmbedderClassLoader;
import org.jbehave.core.io.LoadFromClasspath;
import org.jbehave.core.parsers.RegexPrefixCapturingPatternParser;
import org.jbehave.core.steps.ParameterConverters;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import java.text.SimpleDateFormat;

import static java.util.Arrays.asList;
import static org.jbehave.core.reporters.Format.*;

@Configuration
public class AnnotationConfiguration {

    @Bean
    public LoadFromClasspath loadFromClasspath() {
        return new LoadFromClasspath(new EmbedderClassLoader(asList("target/classes")));
    }

    @Bean
    public ParameterConverters.DateConverter dateConverter() {
        return new ParameterConverters.DateConverter(new SimpleDateFormat("yyyy-MM-dd"));
    }

    @Bean
    public RegexPrefixCapturingPatternParser regexPrefixCapturingPatternParser() {
        return new RegexPrefixCapturingPatternParser("%");
    }

    @Bean
    public SpringStoryControls springStoryControls() {
        SpringStoryControls result = new SpringStoryControls();
        result.setDryRun(false);
        result.setSkipScenariosAfterFailure(false);
        return result;
    }

    @Bean
    public SpringStoryReporterBuilder springStoryReporterBuilder() {
        SpringStoryReporterBuilder result = new SpringStoryReporterBuilder();
        result.withDefaultFormats();
        result.setFormats(asList(CONSOLE, TXT, HTML, XML));
        return result;
    }
}
