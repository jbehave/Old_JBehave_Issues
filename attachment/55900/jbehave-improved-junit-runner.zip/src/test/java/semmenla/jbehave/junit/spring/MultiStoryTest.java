package semmenla.jbehave.junit.spring;

import java.util.concurrent.atomic.AtomicInteger;

import javax.annotation.Resource;

import org.jbehave.core.annotations.AfterScenario;
import org.jbehave.core.annotations.AfterStory;
import org.jbehave.core.annotations.BeforeScenario;
import org.jbehave.core.annotations.BeforeStory;
import org.jbehave.core.annotations.UsingPaths;
import org.junit.After;
import org.junit.Before;
import org.junit.runner.RunWith;
import org.springframework.test.annotation.DirtiesContext;
import org.springframework.test.annotation.DirtiesContext.ClassMode;
import org.springframework.test.context.ContextConfiguration;

import semmenla.jbehave.junit.AfterExample;
import semmenla.jbehave.junit.BeforeExample;
import semmenla.jbehave.junit.ListTestSteps;
import semmenla.jbehave.junit.Steps;

@RunWith(SpringJBehaveTestRunner.class)
@ContextConfiguration("classpath:semmenla/jbehave/junit/spring/MapSpringTest-context.xml")
@DirtiesContext(classMode=ClassMode.AFTER_EACH_TEST_METHOD)
@UsingPaths(includes={"ListTest.story", "MapSpringTest.story"}, searchIn=".")
public class MultiStoryTest {
	private static AtomicInteger NEXT_INSTANCE_ID = new AtomicInteger(1);
	private int instanceId;
	
	public MultiStoryTest() {
		this.instanceId = NEXT_INSTANCE_ID.getAndIncrement();
	}
	
	@Resource(name="mapSpringTestSteps")
	MapSpringTestSteps mapSpringTestSteps;

	@Steps
	public Object[] getSteps() {
		return new Object[] {
			mapSpringTestSteps,
			new ListTestSteps()
		};
	}
	
	@BeforeStory
	public void beforeStory() {
		System.out.println("### Before story instanceId = " + instanceId);
	}
	
	@AfterStory
	public void afterStory() {
		System.out.println("### After story instanceId = " + instanceId);
	}

	@BeforeScenario
	public void beforeScenario() {
		System.out.println("### Before scenario instanceId = " + instanceId);
	}

	@AfterScenario
	public void afterScenario() {
		System.out.println("### After scenario instanceId = " + instanceId);
	}
	
	@BeforeExample
	public void beforeExample() {
		System.out.println("### Before example instanceId = " + instanceId);
	}

	@AfterExample
	public void afterExample() {
		System.out.println("### After example instanceId = " + instanceId);
	}
	
	@Before
	public void before() {
		System.out.println("### Before instanceId = " + instanceId);
	}

	@After
	public void after() {
		System.out.println("### After instanceId = " + instanceId);
	}
}
