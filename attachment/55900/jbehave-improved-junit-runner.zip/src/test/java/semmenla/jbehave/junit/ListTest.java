package semmenla.jbehave.junit;

import org.jbehave.core.annotations.UsingPaths;
import org.junit.runner.RunWith;

@RunWith(JBehaveTestRunner.class)
@UsingPaths(includes={"ListTest.story"}, searchIn=".")
public class ListTest {
	@Steps
	public Object getSteps() {
		return new ListTestSteps();
	}
}
