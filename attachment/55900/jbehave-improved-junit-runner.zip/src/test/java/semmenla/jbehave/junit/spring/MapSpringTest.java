package semmenla.jbehave.junit.spring;

import java.util.Arrays;
import java.util.List;

import javax.annotation.Resource;

import org.jbehave.core.annotations.UsingPaths;
import org.junit.runner.RunWith;
import org.springframework.test.annotation.DirtiesContext;
import org.springframework.test.annotation.DirtiesContext.ClassMode;
import org.springframework.test.context.ContextConfiguration;

import semmenla.jbehave.junit.Steps;

@RunWith(SpringJBehaveTestRunner.class)
@ContextConfiguration
@DirtiesContext(classMode=ClassMode.AFTER_EACH_TEST_METHOD)
@UsingPaths(includes={"MapSpringTest.story"}, searchIn=".")
public class MapSpringTest {
	@Resource(name="mapSpringTestSteps")
	MapSpringTestSteps mapSpringTestSteps;
	
	@Steps
	public List<MapSpringTestSteps> getSteps() {
		return Arrays.asList(mapSpringTestSteps);
	}
}