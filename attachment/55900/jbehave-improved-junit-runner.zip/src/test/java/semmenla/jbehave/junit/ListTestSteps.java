package semmenla.jbehave.junit;

import java.util.ArrayList;
import java.util.List;

import org.jbehave.core.annotations.Given;
import org.jbehave.core.annotations.Named;
import org.jbehave.core.annotations.Then;
import org.jbehave.core.annotations.When;
import org.junit.Assert;

public class ListTestSteps {
	private List<String> list;
	
	@Given("an empty list")
	public void givenAnEmptyList() {
		list = new ArrayList<String>();
	}		
	@When("value <value1> is added to the list")
	public void valueAddedToList(@Named("value1") String value) {
		list.add(value);
	}		
	@Then("value <value2> exists in the list")
	public void valueExistsInTheList(@Named("value2") String value) {
		Assert.assertTrue(list.contains(value));
	}		
	@Then("the size of the list is <size>")
	public void sizeOfTheListIs(@Named("size") int size) {
		Assert.assertEquals(size, list.size());
	}
}
