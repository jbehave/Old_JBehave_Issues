package semmenla.jbehave.junit.spring;

import java.util.HashMap;
import java.util.Map;

import javax.annotation.Resource;

import junit.framework.Assert;

import org.jbehave.core.annotations.Alias;
import org.jbehave.core.annotations.Given;
import org.jbehave.core.annotations.Named;
import org.jbehave.core.annotations.Then;
import org.jbehave.core.annotations.When;

public class MapSpringTestSteps {
	private Map<String, String> m1;
	
	@Resource(name="m2")
	private Map<String, String> m2;
	
	@Given("an empty map m1")
	public void givenAnEmptyMapM1() {
		m1 = new HashMap<String, String>();
	}
	
	@Given("a map on the application context m2")
	public void givenAnAppContextMapM2() {
	}
	
	@When("putting <key1>, <value1> into m1")
	public void whenPuttingIntoM1(@Named("key1") String key, @Named("value1") String value) {
		m1.put(key, value);
	}

	@When("putting <key2>, <value2> into m2")
	@Alias("putting $key2, $value2 into m2")
	public void whenPuttingIntoM2(@Named("key2") String key, @Named("value2") String value) {
		m2.put(key, value);
	}
	
	@Then("m1 size is <m1Size>")
	public void thenM1SizeIs(@Named("m1Size") int size) {
		int actualSize = m1.size();
		Assert.assertEquals(size, actualSize);
	}

	@Then("m2 size is <m2Size>")
	public void thenM2SizeIs(@Named("m2Size") int size) {
		Assert.assertEquals(size, m2.size());
	}
	
	@Then("<value1> is keyed to <key1> in m1")
	public void thenValueKeyedInM1(@Named("key1") String key, @Named("value1") String value) {
		Assert.assertEquals(value, m1.get(key));
	}
	
	@Then("<value2> is keyed to <key2> in m2")
	@Alias("$value2 is keyed to $key2 in m2")
	public void thenValueKeyedInM2(@Named("key2") String key, @Named("value2") String value) {
		Assert.assertEquals(value, m2.get(key));
	}
}
