package semmenla.jbehave.junit;

import org.jbehave.core.configuration.Configuration;
import org.jbehave.core.steps.Steps;

public class MutableCandidateSteps extends Steps {
	private Object instance;

	public MutableCandidateSteps(Configuration configuration, Object instance) {
		super(configuration, null);
		this.instance = instance;
	}
	
	@Override
	public Object instance() {
		return instance;
	}
	
	public void setInstance(Object instance) {
		this.instance = instance;
	}
}
