package semmenla.jbehave.junit;

import java.util.Collection;
import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import org.jbehave.core.model.Story;
import org.jbehave.core.parsers.StoryParser;

public class CachedStoryParser implements StoryParser {
	private Map<String, Story> storyMap;
	
	public CachedStoryParser(List<Story> stories) {
		storyMap = new LinkedHashMap<String, Story>();
		for (Story story : stories) {
			storyMap.put(story.getPath(), story);
		}
	}
	
	@Override
	public Story parseStory(String storyAsText) {
		throw new UnsupportedOperationException("parseStory(storyAsText)");
	}
	
	@Override
	public Story parseStory(String storyAsText, String storyPath) {
		return storyMap.get(storyPath);
	}
	
	public Collection<String> getStoryPaths() {
		return Collections.unmodifiableSet(storyMap.keySet());
	}
}
