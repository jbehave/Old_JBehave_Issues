package semmenla.jbehave.junit;

import org.jbehave.core.reporters.FilePrintStreamFactory;
import org.jbehave.core.reporters.Format;
import org.jbehave.core.reporters.StoryReporter;
import org.jbehave.core.reporters.StoryReporterBuilder;


public class SimpleFormat extends Format {
	private StoryReporter storyReporter;

	public SimpleFormat(String name, StoryReporter storyReporter) {
		super(name);
		this.storyReporter = storyReporter;
	}
	
	public SimpleFormat(String name, StoryReporter2 storyReporter2) {
		this(name, new StoryReporter2Adapter(storyReporter2));
	}
	
	@Override
	public StoryReporter createStoryReporter(FilePrintStreamFactory factory, StoryReporterBuilder storyReporterBuilder) {
		return storyReporter;
	}
}
