package semmenla.jbehave.junit;

import org.junit.runners.model.TestClass;

public interface TestFactory {
	public Object createTest() throws Exception;
	public TestClass getTestClass();
}
