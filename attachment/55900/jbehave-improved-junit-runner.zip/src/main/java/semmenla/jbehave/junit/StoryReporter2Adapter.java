package semmenla.jbehave.junit;

import java.util.List;
import java.util.Map;

import org.jbehave.core.model.ExamplesTable;
import org.jbehave.core.model.GivenStories;
import org.jbehave.core.model.Meta;
import org.jbehave.core.model.Narrative;
import org.jbehave.core.model.OutcomesTable;
import org.jbehave.core.model.Scenario;
import org.jbehave.core.model.Story;
import org.jbehave.core.reporters.StoryReporter;

public class StoryReporter2Adapter implements StoryReporter {
	private ThreadLocal<StoryReporter2Context> storyReporter2Context = new ThreadLocal<StoryReporter2Context>() {
		protected StoryReporter2Context initialValue() {
			return new StoryReporter2Context();
		};
	};

	private final StoryReporter2 storyReporter2;
	
	public StoryReporter2Adapter(StoryReporter2 storyReporter2) {
		super();
		this.storyReporter2 = storyReporter2;
	}
	
	protected StoryReporter2Context getContext() {
		return storyReporter2Context.get();
	}

	@Override
	public void storyNotAllowed(Story story, String filter) {
		storyReporter2.storyNotAllowed(story, filter);
	}

	@Override
	public void beforeStory(Story story, boolean givenStory) {
		getContext().setStory(story);
		storyReporter2.beforeStory(story, givenStory);
	}

	@Override
	public void narrative(Narrative narrative) {
		storyReporter2.narrative(getContext().getStory(), narrative);
	}

	@Override
	public void afterStory(boolean givenStory) {
		StoryReporter2Context context = getContext();
		storyReporter2.afterStory(context.getStory(), givenStory);
		
		context.setStory(null);
		storyReporter2Context.remove();
	}

	@Override
	public void scenarioNotAllowed(Scenario scenario, String filter) {
		storyReporter2.scenarioNotAllowed(getContext().getStory(), scenario, filter);
	}

	@Override
	public void beforeScenario(String scenarioTitle) {
		StoryReporter2Context context = getContext();
		context.setScenario(getScenario(scenarioTitle));
		storyReporter2.beforeScenario(context.getStory(), context.getScenario());
	}

	@Override
	public void scenarioMeta(Meta meta) {
		StoryReporter2Context context = getContext();
		storyReporter2.scenarioMeta(context.getStory(), context.getScenario(), meta);
	}

	@Override
	public void afterScenario() {
		StoryReporter2Context context = getContext();
		storyReporter2.afterScenario(context.getStory(), context.getScenario());
		context.setScenario(null);
	}

	@Override
	public void givenStories(GivenStories givenStories) {
		storyReporter2.givenStories(givenStories);
	}

	@Override
	public void givenStories(List<String> storyPaths) {
		storyReporter2.givenStories(storyPaths);
	}

	@Override
	public void beforeExamples(List<String> steps, ExamplesTable table) {
		StoryReporter2Context context = getContext();
		context.setExamplesTable(table);
		storyReporter2.beforeExamples(context.getStory(), context.getScenario(), table);
	}

	@Override
	public void example(Map<String, String> exampleRow) {
		StoryReporter2Context context = getContext();
		Map<String, String> prevExampleRow = context.getExampleRow();
		context.setExampleRow(exampleRow);
		if (prevExampleRow != null) {
			// hack an afterExample event
			storyReporter2.afterExample(context.getStory(), context.getScenario(), prevExampleRow);
		}
		storyReporter2.beforeExample(context.getStory(), context.getScenario(), exampleRow);
	}

	@Override
	public void afterExamples() {
		StoryReporter2Context context = getContext();

		// hack an afterExample event
		if (context.getExampleRow() != null) {
			storyReporter2.afterExample(context.getStory(), context.getScenario(), context.getExampleRow());
		}
		storyReporter2.afterExamples(context.getStory(), context.getScenario(), context.getExamplesTable());
		context.setExamplesTable(null);
		context.setExampleRow(null);
	}

	@Override
	public void successful(String step) {
		StoryReporter2Context context = getContext();
		storyReporter2.successful(context.getStory(), context.getScenario(), step, context.getExampleRow());
	}

	@Override
	public void ignorable(String step) {
		StoryReporter2Context context = getContext();
		storyReporter2.ignorable(context.getStory(), context.getScenario(), step, context.getExampleRow());
	}

	@Override
	public void pending(String step) {
		StoryReporter2Context context = getContext();
		storyReporter2.pending(context.getStory(), context.getScenario(), step, context.getExampleRow());
	}

	@Override
	public void notPerformed(String step) {
		StoryReporter2Context context = getContext();
		storyReporter2.notPerformed(context.getStory(), context.getScenario(), step, context.getExampleRow());
	}

	@Override
	public void failed(String step, Throwable cause) {
		StoryReporter2Context context = getContext();
		storyReporter2.failed(context.getStory(), context.getScenario(), step, context.getExampleRow(), cause);
	}

	@Override
	public void failedOutcomes(String step, OutcomesTable table) {
		StoryReporter2Context context = getContext();
		storyReporter2.failedOutcomes(context.getStory(), context.getScenario(), step, table);
	}

	@Override
	public void dryRun() {
		storyReporter2.dryRun();
	}

	@Override
	public void pendingMethods(List<String> methods) {
		StoryReporter2Context context = getContext();
		storyReporter2.pendingMethods(context.getStory(), context.getScenario(), context.getExampleRow(), methods);
	}
	
	protected Scenario getScenario(String scenarioTitle) {
		StoryReporter2Context context = getContext();
		for (Scenario scenario : context.getStory().getScenarios()) {
			if (scenario.getTitle().equals(scenarioTitle)) {
				return scenario;
			}
		}
		throw new IllegalStateException(String.format("No such title %s in story", scenarioTitle));
	}

}
