package semmenla.jbehave.junit;

import java.util.List;
import java.util.Map;

import org.jbehave.core.model.ExamplesTable;
import org.jbehave.core.model.GivenStories;
import org.jbehave.core.model.Meta;
import org.jbehave.core.model.Narrative;
import org.jbehave.core.model.OutcomesTable;
import org.jbehave.core.model.Scenario;
import org.jbehave.core.model.Story;

public class NullStoryReporter2 implements StoryReporter2 {
	@Override
	public void storyNotAllowed(Story story, String filter) {
	}

	@Override
	public void beforeStory(Story story, boolean givenStory) {
	}

	@Override
	public void narrative(Story story, Narrative narrative) {
	}

	@Override
	public void afterStory(Story story, boolean givenStory) {
	}

	@Override
	public void scenarioNotAllowed(Story story, Scenario scenario, String filter) {
	}

	@Override
	public void beforeScenario(Story story, Scenario scenario) {
	}

	@Override
	public void scenarioMeta(Story story, Scenario scenario, Meta meta) {
	}

	@Override
	public void afterScenario(Story story, Scenario scenario) {
	}

	@Override
	public void givenStories(GivenStories givenStories) {
	}

	@Override
	public void givenStories(List<String> storyPaths) {
	}

	@Override
	public void beforeExamples(Story story, Scenario scenario, ExamplesTable table) {
	}

	@Override
	public void beforeExample(Story story, Scenario scenario, Map<String, String> tableRow) {
	}

	@Override
	public void afterExample(Story story, Scenario scenario, Map<String, String> tableRow) {
	}

	@Override
	public void afterExamples(Story story, Scenario scenario, ExamplesTable table) {
	}

	@Override
	public void successful(Story story, Scenario scenario, String step, Map<String, String> tableRow) {
	}

	@Override
	public void ignorable(Story story, Scenario scenario, String step, Map<String, String> tableRow) {
	}

	@Override
	public void pending(Story story, Scenario scenario, String step, Map<String, String> tableRow) {
	}

	@Override
	public void notPerformed(Story story, Scenario scenario, String step, Map<String, String> tableRow) {
	}

	@Override
	public void failed(Story story, Scenario scenario, String step, Map<String, String> tableRow, Throwable cause) {
	}

	@Override
	public void failedOutcomes(Story story, Scenario scenario, String step, OutcomesTable table) {
	}

	@Override
	public void dryRun() {
	}

	@Override
	public void pendingMethods(Story story, Scenario scenario, Map<String, String> tableRow, List<String> methods) {
	}
}
