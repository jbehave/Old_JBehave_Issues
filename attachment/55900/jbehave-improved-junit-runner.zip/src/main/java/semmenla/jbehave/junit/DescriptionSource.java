package semmenla.jbehave.junit;

import java.util.Map;

import org.jbehave.core.model.Scenario;
import org.jbehave.core.model.Story;
import org.junit.runner.Description;

public interface DescriptionSource {
	public Description getDescription(Story story);
	public Description getDescription(Story story, Scenario scenario);
	public Description getDescription(Story story, Scenario scenario, Map<String,String> exampleRow);
}
