package semmenla.jbehave.junit;

import java.util.Map;

import org.junit.runner.Description;

public class ExampleDescription {
	private Description description;
	private Map<String,String> exampleRow;
	public ExampleDescription(Map<String, String> exampleRow, Description description) {
		super();
		this.exampleRow = exampleRow;
		this.description = description;
	}
	
	public Description getDescription() {
		return description;
	}
	
	public Map<String, String> getExampleRow() {
		return exampleRow;
	}
}
