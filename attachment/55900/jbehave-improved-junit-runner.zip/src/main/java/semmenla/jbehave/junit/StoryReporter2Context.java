package semmenla.jbehave.junit;

import java.util.Map;

import org.jbehave.core.model.ExamplesTable;
import org.jbehave.core.model.Scenario;
import org.jbehave.core.model.Story;

public class StoryReporter2Context {
	private Story story;
	private Scenario scenario;
	private ExamplesTable examplesTable;
	private Map<String,String> exampleRow;
	
	public Story getStory() {
		return story;
	}
	public void setStory(Story story) {
		this.story = story;
	}
	public Scenario getScenario() {
		return scenario;
	}
	public void setScenario(Scenario scenario) {
		this.scenario = scenario;
	}
	public ExamplesTable getExamplesTable() {
		return examplesTable;
	}
	public void setExamplesTable(ExamplesTable examplesTable) {
		this.examplesTable = examplesTable;
	}
	public Map<String, String> getExampleRow() {
		return exampleRow;
	}
	public void setExampleRow(Map<String, String> exampleRow) {
		this.exampleRow = exampleRow;
	}
}
