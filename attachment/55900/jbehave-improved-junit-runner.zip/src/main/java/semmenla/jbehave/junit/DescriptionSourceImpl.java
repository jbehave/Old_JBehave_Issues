package semmenla.jbehave.junit;

import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import org.jbehave.core.model.Scenario;
import org.jbehave.core.model.Story;
import org.junit.runner.Description;

public class DescriptionSourceImpl implements DescriptionSource {
	private Map<String, StoryDescription> storyDescriptionMap;

	public DescriptionSourceImpl(List<StoryDescription> storyDescriptions) {
		storyDescriptionMap = new LinkedHashMap<String, StoryDescription>(storyDescriptions.size());
		for (StoryDescription description : storyDescriptions) {
			storyDescriptionMap.put(description.getStory().getPath(), description);
		}
	}
	
	@Override
	public Description getDescription(Story story) {
		StoryDescription storyDescription = storyDescriptionMap.get(story.getPath());
		return storyDescription == null ? null : storyDescription.getDescription();
	}
	
	@Override
	public Description getDescription(Story story, Scenario scenario) {
		StoryDescription storyDescription = storyDescriptionMap.get(story.getPath());
		ScenarioDescription scenarioDescription = storyDescription.getScenarioDescriptions().get(scenario.getTitle());
		return scenarioDescription.getDescription();
	}

	@Override
	public Description getDescription(Story story, Scenario scenario, Map<String, String> exampleRow) {
		StoryDescription storyDescription = storyDescriptionMap.get(story.getPath());
		ScenarioDescription scenarioDescription = storyDescription.getScenarioDescriptions().get(scenario.getTitle());
		
		if (exampleRow == null) {
			if (!scenarioDescription.getExampleDescriptions().isEmpty()) {
				throw new IllegalStateException();
			}
			return scenarioDescription.getDescription();
		} else {
			for (ExampleDescription exampleDescription : scenarioDescription.getExampleDescriptions()) {
				if (exampleRow.equals(exampleDescription.getExampleRow())) {
					return exampleDescription.getDescription();
				}
			}
		}
		return null;
	}
}
