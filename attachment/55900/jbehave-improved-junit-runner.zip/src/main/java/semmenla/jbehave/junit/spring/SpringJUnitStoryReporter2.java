package semmenla.jbehave.junit.spring;

import java.lang.reflect.Method;
import java.util.Map;

import org.jbehave.core.model.Scenario;
import org.jbehave.core.model.Story;
import org.junit.runner.notification.RunNotifier;
import org.springframework.test.context.TestContextManager;

import semmenla.jbehave.junit.CandidateStepsRefresher;
import semmenla.jbehave.junit.DescriptionSource;
import semmenla.jbehave.junit.JUnitStoryReporter2;
import semmenla.jbehave.junit.TestFactory;

/**
 * This class in not thread-safe (see super class)
 */
public class SpringJUnitStoryReporter2 extends JUnitStoryReporter2 {
	private TestContextManager testContextManager;
	private static final Method DUMMY_METHOD = Object.class.getMethods()[0];
	
	public SpringJUnitStoryReporter2(RunNotifier runNotifier, DescriptionSource descriptionSource, CandidateStepsRefresher stepsRefresher,
			TestFactory testFactory, TestContextManager testContextManager) {
		super(runNotifier, descriptionSource, stepsRefresher, testFactory);
		this.testContextManager = testContextManager;
	}

	@Override
	public void beforeExample(Story story, Scenario scenario, Map<String, String> tableRow) {
		super.beforeExample(story, scenario, tableRow);
		beforeTestMethod(getExampleTestInstance());
	}

	@Override
	public void afterExample(Story story, Scenario scenario, Map<String, String> tableRow) {
		afterTestMethod(getExampleTestInstance());
		super.afterExample(story, scenario, tableRow);
	}

	@Override
	public void beforeScenario(Story story, Scenario scenario) {
		super.beforeScenario(story, scenario);
		if (isInlineTest(scenario)) {
			beforeTestMethod(getScenarioTestInstance());
		}
	}
	
	@Override
	public void afterScenario(Story story, Scenario scenario) {
		if (isInlineTest(scenario)) {
			afterTestMethod(getScenarioTestInstance());
		}
		super.afterScenario(story, scenario);
	}
	
	protected void beforeTestMethod(Object testInstance) {
		try {
			testContextManager.beforeTestMethod(testInstance, DUMMY_METHOD);
		} catch (RuntimeException e) {
			throw e;
		} catch (Exception e) {
			throw new RuntimeException(e);
		}
	}

	protected void afterTestMethod(Object testInstance) {
		try {
			testContextManager.afterTestMethod(testInstance, DUMMY_METHOD, null);
		} catch (RuntimeException e) {
			throw e;
		} catch (Exception e) {
			throw new RuntimeException(e);
		}
	}
}
