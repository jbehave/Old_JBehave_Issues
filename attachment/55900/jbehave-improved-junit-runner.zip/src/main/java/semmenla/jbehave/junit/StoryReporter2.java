package semmenla.jbehave.junit;

import java.util.List;
import java.util.Map;

import org.jbehave.core.model.ExamplesTable;
import org.jbehave.core.model.GivenStories;
import org.jbehave.core.model.Meta;
import org.jbehave.core.model.Narrative;
import org.jbehave.core.model.OutcomesTable;
import org.jbehave.core.model.Scenario;
import org.jbehave.core.model.Story;

/**
 * A nicer StoryReporter interface to code against
 */
public interface StoryReporter2 {

    void storyNotAllowed(Story story, String filter);

    void beforeStory(Story story, boolean givenStory);

    void narrative(Story story, Narrative narrative);

    void afterStory(Story story, boolean givenStory);

    void scenarioNotAllowed(Story story, Scenario scenario, String filter);

    void beforeScenario(Story story, Scenario scenario);
    
    void scenarioMeta(Story story, Scenario scenario, Meta meta);

    void afterScenario(Story story, Scenario scenario);

    void givenStories(GivenStories givenStories);

	void givenStories(List<String> storyPaths);

    void beforeExamples(Story story, Scenario scenario, ExamplesTable table);

    void beforeExample(Story story, Scenario scenario, Map<String, String> tableRow);

    void afterExample(Story story, Scenario scenario, Map<String, String> tableRow);
    
    void afterExamples(Story story, Scenario scenario, ExamplesTable table);

    void successful(Story story, Scenario scenario, String step, Map<String, String> tableRow);

    void ignorable(Story story, Scenario scenario, String step, Map<String, String> tableRow);

    void pending(Story story, Scenario scenario, String step, Map<String, String> tableRow);

    void notPerformed(Story story, Scenario scenario, String step, Map<String, String> tableRow);

    void failed(Story story, Scenario scenario, String step, Map<String, String> tableRow, Throwable cause);

	void failedOutcomes(Story story, Scenario scenario, String step, OutcomesTable table);

	void dryRun();

    void pendingMethods(Story story, Scenario scenario, Map<String, String> tableRow, List<String> methods);
}
