package semmenla.jbehave.junit;

import java.lang.annotation.Annotation;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Properties;
import java.util.Set;

import org.jbehave.core.ConfigurableEmbedder;
import org.jbehave.core.Embeddable;
import org.jbehave.core.annotations.UsingPaths;
import org.jbehave.core.configuration.Configuration;
import org.jbehave.core.configuration.MostUsefulConfiguration;
import org.jbehave.core.failures.FailureStrategy;
import org.jbehave.core.failures.PendingStepStrategy;
import org.jbehave.core.failures.UUIDExceptionWrapper;
import org.jbehave.core.io.LoadFromClasspath;
import org.jbehave.core.io.StoryLoader;
import org.jbehave.core.model.ExamplesTable;
import org.jbehave.core.model.Scenario;
import org.jbehave.core.model.Story;
import org.jbehave.core.parsers.RegexStoryParser;
import org.jbehave.core.parsers.StoryParser;
import org.jbehave.core.reporters.Format;
import org.jbehave.core.reporters.StoryReporterBuilder;
import org.jbehave.core.steps.CandidateSteps;
import org.jbehave.core.steps.ParameterConverters;
import org.jbehave.core.steps.ParameterConverters.DateConverter;
import org.jbehave.core.steps.PrintStreamStepMonitor;
import org.junit.internal.runners.model.EachTestNotifier;
import org.junit.runner.Description;
import org.junit.runner.notification.RunNotifier;
import org.junit.runners.ParentRunner;
import org.junit.runners.model.FrameworkMethod;
import org.junit.runners.model.InitializationError;
import org.junit.runners.model.Statement;

public class JBehaveTestRunner extends ParentRunner<StoryDescription> implements TestFactory {
	private Description parentDescription;
	private List<StoryDescription> storyDescriptions;
	private StoryParser storyParser = new RegexStoryParser();
	private StoryLoader storyLoader = new LoadFromClasspath();
	private CachedStoryParser cachedStoryParser;
	
	public JBehaveTestRunner(Class<?> testClass) throws InitializationError {
		super(testClass);
		List<Story> stories = parseStories(testClass);
		this.storyDescriptions = createStoryDescriptions(testClass, stories);
		this.parentDescription = createParentDescription(testClass, storyDescriptions);
		this.cachedStoryParser = new CachedStoryParser(stories);
	}
	
	protected List<Story> parseStories(Class<?> testClass) {
		UsingPaths usingPaths = testClass.getAnnotation(UsingPaths.class);
		if (usingPaths == null) {
			throw new IllegalStateException(String.format("%s annotation not found on %s", UsingPaths.class.getName(), testClass.getName()));
		}
		Set<String> excludes = new HashSet<String>();
		if (usingPaths.excludes() != null) {
			excludes.addAll(Arrays.asList(usingPaths.excludes()));
		}
		List<Story> stories = new ArrayList<Story>();
		for (String storyPath : usingPaths.includes()) {
			if (!excludes.contains(storyPath)) {
				String storyAsText = storyLoader.loadStoryAsText(storyPath);
				stories.add(storyParser.parseStory(storyAsText, storyPath));
			}
		}
		return stories;
	}
	
	/**
	 * This hack sets up the candidate step instances to be swapped after each test
	 */
	protected List<CandidateSteps> createCandidateSteps(Configuration configuration) {
		Object testInstance;
		try {
			testInstance = createTest();
		} catch (Exception e) {
			throw new RuntimeException(e);
		}
		Object[] steps = getSteps(testInstance);
		List<CandidateSteps> candidateSteps = new ArrayList<CandidateSteps>(steps.length);
		for (Object step : steps) {
			candidateSteps.add(new MutableCandidateSteps(configuration, step));
		}
		return candidateSteps;
	};

	protected Object[] getSteps(Object testInstance) {
		Object result;
		try {
			result = invokeSingle(testInstance, Steps.class);
		} catch (Throwable e) {
			throw new RuntimeException(e);
		}
		Object[] steps;
		if (result instanceof Object[]) {
			steps = (Object[]) result;
		} else if (result instanceof Collection) {
			Collection<?> coll = (Collection<?>) result;
			steps = coll.toArray();
		} else {
			steps = new Object[] { result }; 
		}
		return steps;
	}
	
	protected Object invokeSingle(Object target, Class<? extends Annotation> annotationType) throws Throwable {
		List<FrameworkMethod> methods = getTestClass().getAnnotatedMethods(annotationType);
		if (methods.size() != 1) {
			throw new IllegalStateException(String.format("%s methods found with annotation %s, expected 1", methods.size(), annotationType.getName()));
		}
		return methods.get(0).invokeExplosively(target);
	}
	
	public Object createTest() throws Exception {
		return getTestClass().getOnlyConstructor().newInstance();
	}
	
	/**
	 * Creates a mapping from the junit description hierarchy to the 
	 * story / scenario / example for reporting of success and error in the tests
	 */
	protected List<StoryDescription> createStoryDescriptions(Class<?> testClass, List<Story> stories) {
		List<StoryDescription> storyDescriptions = new ArrayList<StoryDescription>(stories.size());
		for (Story story : stories) {
			StoryDescription storyDescription = new StoryDescription(story, Description.createSuiteDescription(story.getPath()));
			for (Scenario scenario : story.getScenarios()) {
				ScenarioDescription scenarioDescription = new ScenarioDescription(scenario, Description.createSuiteDescription(scenario.getTitle()));
				ExamplesTable examplesTable = scenario.getExamplesTable();
				int exampleCount = examplesTable.getRowCount();
				for (int i = 0; i < exampleCount; ++ i) {
					Map<String, String> exampleRow = examplesTable.getRow(i); 
					String testName = exampleRow.toString();
					ExampleDescription exampleDescription = new ExampleDescription(exampleRow, Description.createTestDescription(testClass, testName));
					
					scenarioDescription.getDescription().addChild(exampleDescription.getDescription());
					scenarioDescription.getExampleDescriptions().add(exampleDescription);
				}
				storyDescription.getDescription().addChild(scenarioDescription.getDescription());
				storyDescription.getScenarioDescriptions().put(scenarioDescription.getScenario().getTitle(), scenarioDescription);
			}
			storyDescriptions.add(storyDescription);
		}
		return storyDescriptions;
	}
	
	protected Description createParentDescription(Class<?> testClass, List<StoryDescription> storyDescriptions) {
		Description parent = Description.createSuiteDescription(testClass);
		for (StoryDescription storyDescription : storyDescriptions) {
			parent.addChild(storyDescription.getDescription());
		}
		return parent;
	}
	

	@Override
	public Description getDescription() {
		return parentDescription;
	}
	
	@Override
	protected List<StoryDescription> getChildren() {
		return storyDescriptions;
	}
	
	@Override
	protected Description describeChild(StoryDescription child) {
		return child.getDescription();
	}
	
	@Override
	protected void runChild(StoryDescription child, RunNotifier notifier) {
		throw new UnsupportedOperationException("runChild");
	}

	@Override
	protected Statement childrenInvoker(final RunNotifier notifier) {
		return new Statement() {
			public void evaluate() throws Throwable {
				runChildren(notifier);
			}
		};
	}

	protected void runChildren(RunNotifier notifier) throws Throwable {
		Embeddable embedder = createEmbedder(notifier);
		EachTestNotifier testNotifier = new EachTestNotifier(notifier, parentDescription);
		try {
			testNotifier.fireTestStarted();
			embedder.run();
		} catch (UUIDExceptionWrapper e) {
			Throwable cause = e.getCause();
			testNotifier.addFailure(cause);
		} catch (Exception e) {
			testNotifier.addFailure(e);
		} finally {
			testNotifier.fireTestFinished();
		}
	}
	
	protected Embeddable createEmbedder(RunNotifier notifier) throws Exception {
		Configuration configuration = createConfiguration(notifier);
		List<CandidateSteps> candidateSteps = createCandidateSteps(configuration);
		configuration.storyReporterBuilder().withFormats(createFormats(notifier, candidateSteps));
		
		final List<String> storyPaths = new ArrayList<String>(cachedStoryParser.getStoryPaths());
		ConfigurableEmbedder embedder = new ConfigurableEmbedder() {
			@Override
			public void run() throws Throwable {
				configuredEmbedder().runStoriesAsPaths(storyPaths);
			}
		};
		embedder.useConfiguration(configuration);
		embedder.addSteps(candidateSteps);
		embedder.configuredEmbedder().embedderControls()
			.doGenerateViewAfterStories(true)
			.doIgnoreFailureInStories(true)
			.doIgnoreFailureInView(true)
			.doBatch(false);
		return embedder;
	}

	protected Configuration createConfiguration(RunNotifier notifier) throws Exception {
		Properties viewResources = new Properties();
		viewResources.put("decorateNonHtml", "true");

		Configuration configuration = 
			new MostUsefulConfiguration()
				.useStoryReporterBuilder(
						new StoryReporterBuilder()
							.withViewResources(viewResources)
							.withFailureTrace(true))
							.useParameterConverters(
								new ParameterConverters()
									// use custom date pattern
									.addConverters(new DateConverter(new SimpleDateFormat("yyyy-MM-dd")))
							)
							.useStepMonitor(new PrintStreamStepMonitor())
							.useStoryLoader(storyLoader)
							.useStoryParser(cachedStoryParser); // avoid parsing stories twice
		
		final EachTestNotifier testNotifier = new EachTestNotifier(notifier, parentDescription);
		configuration.useFailureStrategy(new FailureStrategy() {
			@Override
			public void handleFailure(Throwable throwable) throws Throwable {
				testNotifier.addFailure(throwable);
			}
		});
		configuration.usePendingStepStrategy(new PendingStepStrategy() {
			public void handleFailure(Throwable throwable) throws Throwable {
				testNotifier.addFailure(throwable);
			}
		});
		return configuration;
	}
	

	protected Format[] createFormats(RunNotifier notifier, final List<CandidateSteps> candidateSteps) throws Exception {
		DescriptionSource descriptionSource = new DescriptionSourceImpl(storyDescriptions);
		CandidateStepsRefresher stepsRefresher = createCandidateStepsRefresher(candidateSteps);
		StoryReporter2 storyReporter = new JUnitStoryReporter2(notifier, descriptionSource, stepsRefresher, this);
		Format junitFormat = new SimpleFormat("JUNIT", storyReporter);
		return new Format[] { junitFormat, Format.TXT, Format.HTML, Format.XML, Format.CONSOLE };
	}

	/**
	 * This is a hack since the StoryRunner only makes a single call to candidateSteps(). 
	 * The hack swaps the underlying step instance on the fly
	 */
	protected CandidateStepsRefresher createCandidateStepsRefresher(final List<CandidateSteps> candidateSteps) {
		CandidateStepsRefresher stepsRefresher = new CandidateStepsRefresher() {
			public void refreshCandidateSteps(Object testInstance) {
				Object[] steps = getSteps(testInstance);
				if (steps.length != candidateSteps.size()) {
					throw new RuntimeException("Steps size has changed, could not perform refresh hack");
				}
				for (int i = 0; i < steps.length; ++ i) {
					Object newInstance = steps[i];
					MutableCandidateSteps mutable = (MutableCandidateSteps) candidateSteps.get(i);
					
					// hack to update the instance
					mutable.setInstance(newInstance);
				}
			}
		};
		return stepsRefresher;
	}
}
