package semmenla.jbehave.junit.spring;


import java.util.List;

import org.jbehave.core.reporters.Format;
import org.jbehave.core.steps.CandidateSteps;
import org.junit.runner.notification.RunNotifier;
import org.junit.runners.model.InitializationError;
import org.springframework.test.context.TestContextManager;

import semmenla.jbehave.junit.CandidateStepsRefresher;
import semmenla.jbehave.junit.DescriptionSource;
import semmenla.jbehave.junit.DescriptionSourceImpl;
import semmenla.jbehave.junit.JBehaveTestRunner;
import semmenla.jbehave.junit.SimpleFormat;
import semmenla.jbehave.junit.StoryReporter2;

/**
 * JBehaveRunner implementation that supports spring's TestExecutionListeners
 */
public class SpringJBehaveTestRunner extends JBehaveTestRunner {
	private final TestContextManager testContextManager;
	
	public SpringJBehaveTestRunner(Class<?> testClass) throws InitializationError {
		super(testClass);
		testContextManager = new TestContextManager(testClass);
	}
	
	@Override
	public Object createTest() throws Exception {
		Object testInstance = super.createTest();
		getTestContextManager().prepareTestInstance(testInstance);
		return testInstance;
	}
	
	@Override
	protected void runChildren(RunNotifier notifier) throws Throwable {
		testContextManager.beforeTestClass();
		try {
			super.runChildren(notifier);
		} finally {
			testContextManager.afterTestClass();
		}
	}
	
	@Override
	protected Format[] createFormats(RunNotifier notifier, List<CandidateSteps> candidateSteps) throws Exception {
		DescriptionSource descriptionSource = new DescriptionSourceImpl(getChildren());
		CandidateStepsRefresher stepsRefresher = createCandidateStepsRefresher(candidateSteps);
		StoryReporter2 storyReporter = new SpringJUnitStoryReporter2(notifier, descriptionSource, stepsRefresher, this, testContextManager);
		Format springFormat = new SimpleFormat("SPRING", storyReporter);
		return new Format[] { springFormat, Format.TXT, Format.HTML, Format.XML };
	}
	
	protected TestContextManager getTestContextManager() {
		return testContextManager;
	}
}
