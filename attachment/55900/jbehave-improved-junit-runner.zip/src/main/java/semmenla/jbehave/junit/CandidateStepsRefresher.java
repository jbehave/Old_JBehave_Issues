package semmenla.jbehave.junit;


public interface CandidateStepsRefresher {
	public void refreshCandidateSteps(Object testInstance);
}
