package semmenla.jbehave.junit;

import java.util.LinkedHashMap;
import java.util.Map;

import org.jbehave.core.model.Story;
import org.junit.runner.Description;

public class StoryDescription {
	private Description description;
	private Story story;
	private Map<String, ScenarioDescription> scenarioDescriptions = new LinkedHashMap<String, ScenarioDescription>();
	
	public StoryDescription(Story story, Description description) {
		super();
		this.story = story;
		this.description = description;
	}
	
	public Description getDescription() {
		return description;
	}
	
	public Story getStory() {
		return story;
	}
	
	public Map<String, ScenarioDescription> getScenarioDescriptions() {
		return scenarioDescriptions;
	}
}
