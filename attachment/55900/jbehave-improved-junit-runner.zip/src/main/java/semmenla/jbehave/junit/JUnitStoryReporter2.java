package semmenla.jbehave.junit;

import java.lang.annotation.Annotation;
import java.util.List;
import java.util.Map;

import org.jbehave.core.annotations.AfterScenario;
import org.jbehave.core.annotations.AfterStory;
import org.jbehave.core.annotations.BeforeScenario;
import org.jbehave.core.annotations.BeforeStory;
import org.jbehave.core.failures.UUIDExceptionWrapper;
import org.jbehave.core.model.OutcomesTable;
import org.jbehave.core.model.Scenario;
import org.jbehave.core.model.Story;
import org.junit.After;
import org.junit.Before;
import org.junit.internal.AssumptionViolatedException;
import org.junit.runner.Description;
import org.junit.runner.notification.Failure;
import org.junit.runner.notification.RunNotifier;
import org.junit.runners.model.FrameworkMethod;

/**
 * This class is not thread-safe
 * TODO: use a ThreadLocal to store context
 * @author semmenla
 */
public class JUnitStoryReporter2 extends NullStoryReporter2 {
	private RunNotifier runNotifier;
	private DescriptionSource descriptionSource;
	private CandidateStepsRefresher stepsRefresher;
	private TestFactory testFactory;
	private Object storyTestInstance; // new test instance for each story
	private Object scenarioTestInstance; // new test instance for each scenario
	private Object exampleTestInstance; // new test instance for each example
	private boolean isError = false;	
	
	public JUnitStoryReporter2(RunNotifier runNotifier, DescriptionSource descriptionSource, CandidateStepsRefresher stepsRefresher, TestFactory testFactory) {
		super();
		this.runNotifier = runNotifier;
		this.descriptionSource = descriptionSource;
		this.stepsRefresher = stepsRefresher;
		this.testFactory = testFactory;
	}
	
	@Override
	public void beforeStory(Story story, boolean givenStory) {
		Description description = descriptionSource.getDescription(story);

		// JBehave calls beforeStory() with implicit stories not in the test case
		if (description != null) {
			runNotifier.fireTestStarted(description);
			storyTestInstance = createTestQuietly();
			runMethods(BeforeStory.class, storyTestInstance);
		}
	}
	
	@Override
	public void afterStory(Story story, boolean givenStory) {
		Description description = descriptionSource.getDescription(story);

		// JBehave calls afterStory() with implicit stories not in the test case
		if (description != null) {
			runMethods(AfterStory.class, storyTestInstance);
			storyTestInstance = null;
			runNotifier.fireTestFinished(description);
		}
	}
	
	@Override
	public void beforeScenario(Story story, Scenario scenario) {
		Description description = descriptionSource.getDescription(story, scenario);
		runNotifier.fireTestStarted(description);
		isError = false;
		scenarioTestInstance = createTestQuietly();
		runMethods(BeforeScenario.class, scenarioTestInstance);
		if (isInlineTest(scenario)) {
			runMethods(Before.class, scenarioTestInstance);
		}
	}
	
	@Override
	public void afterScenario(Story story, Scenario scenario) {
		if (isInlineTest(scenario)) {
			runMethods(After.class, scenarioTestInstance);
		}
		runMethods(AfterScenario.class, scenarioTestInstance);
		isError = false;
		scenarioTestInstance = null;
		Description description = descriptionSource.getDescription(story, scenario);
		runNotifier.fireTestFinished(description);
	}

	@Override
	public void beforeExample(Story story, Scenario scenario, Map<String, String> exampleRow) {
		Description description = descriptionSource.getDescription(story, scenario, exampleRow);
		runNotifier.fireTestStarted(description);
		isError = false;
		exampleTestInstance = createTestQuietly();
		stepsRefresher.refreshCandidateSteps(exampleTestInstance);
		runMethods(Before.class, exampleTestInstance);
		runMethods(BeforeExample.class, exampleTestInstance);
	}
	
	@Override
	public void afterExample(Story story, Scenario scenario, Map<String, String> exampleRow) {
		runMethods(AfterExample.class, exampleTestInstance);
		runMethods(After.class, exampleTestInstance);
		isError = false;
		exampleTestInstance = null;
		Description description = descriptionSource.getDescription(story, scenario, exampleRow);
		runNotifier.fireTestFinished(description);
	}
	
	@Override
	public void notPerformed(Story story, Scenario scenario, String step, Map<String, String> exampleRow) {
		if (!isError) {
			Description description = descriptionSource.getDescription(story, scenario, exampleRow);
			runNotifier.fireTestIgnored(description);
		}
	}
	
	@Override
	public void failed(Story story, Scenario scenario, String step, Map<String, String> exampleRow, Throwable throwable) {
		isError = true;
		Throwable cause = throwable;
		if (throwable instanceof UUIDExceptionWrapper) {
			cause = ((UUIDExceptionWrapper) cause).getCause();
		}
		Description description = descriptionSource.getDescription(story, scenario, exampleRow);
		if (cause instanceof AssumptionViolatedException) {
			runNotifier.fireTestAssumptionFailed(new Failure(description, cause));
		} else {
			runNotifier.fireTestFailure(new Failure(description, cause));
		}
		
	}
	
	@Override
	public void failedOutcomes(Story story, Scenario scenario, String step, OutcomesTable table) {
		throw new UnsupportedOperationException("failedOutcomes");
	}
	
	@Override
	public void pendingMethods(Story story, Scenario scenario, Map<String, String> tableRow, List<String> methods) {
		if (!isError) {
			Description description = descriptionSource.getDescription(story, scenario, tableRow);
			runNotifier.fireTestIgnored(description);
		}
	}
	
	protected void runMethods(Class<? extends Annotation> annotationType, Object testInstance) {
		List<FrameworkMethod> beforeStories = testFactory.getTestClass().getAnnotatedMethods(annotationType);
		try {
			for (FrameworkMethod beforeStory : beforeStories) {
				beforeStory.invokeExplosively(testInstance);
			}
		} catch (RuntimeException e) {
			throw e;
		} catch (Throwable e) {
			throw new RuntimeException(e);
		}
	}
	
	protected Object getStoryTestInstance() {
		return storyTestInstance;
	}

	protected Object getScenarioTestInstance() {
		return scenarioTestInstance;
	}

	protected Object getExampleTestInstance() {
		return exampleTestInstance;
	}
	
	protected boolean isInlineTest(Scenario scenario) {
		return scenario.getExamplesTable() == null || scenario.getExamplesTable().getRowCount() == 0; 
	}
	
	protected Object createTestQuietly() {
		try {
			return testFactory.createTest();
		} catch (Exception e) {
			throw new RuntimeException(e);
		}
	}
}
