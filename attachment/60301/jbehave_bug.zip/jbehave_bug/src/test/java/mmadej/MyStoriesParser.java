package mmadej;

import org.apache.commons.lang.StringUtils;
import org.jbehave.core.model.ExamplesTableFactory;
import org.jbehave.core.model.Story;
import org.jbehave.core.parsers.RegexStoryParser;

import java.io.IOException;
import java.io.StringReader;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

import static java.lang.System.getProperty;
import static org.apache.commons.io.IOUtils.readLines;


public class MyStoriesParser extends RegexStoryParser {

	private static final String USED_STORY_MARKER = StringUtils.EMPTY;

	private static final Map<String, Story> LOADED_STORIES = new ConcurrentHashMap<String, Story>();

	private ScenariosForStories scenariosForStories;

	private List<String> storyPaths;

	public MyStoriesParser(
			ExamplesTableFactory tableFactory, ScenariosForStories scenariosForStories) throws IOException {
		super(tableFactory);
		this.scenariosForStories = scenariosForStories;
		this.storyPaths = new MyStoryResolver().resolveStoryPathsForGivenScenarios(scenariosForStories);
	}

	@Override
	public Story parseStory(String storyAsText, String storyPath) {
		String storyWithoutCommentsAsText = getStoryWithoutComments(storyPath, storyAsText);
		Story storyWithAllScenarios = super.parseStory(storyWithoutCommentsAsText, storyPath);
		int indexOfStoryPath = storyPaths.indexOf(storyPath);
		storyPaths.set(indexOfStoryPath, USED_STORY_MARKER);
		return copyStoryToIncludeOnlySpecifiedScenarios(storyWithAllScenarios, indexOfStoryPath);
	}

	private String getStoryWithoutComments(String storyPath, String storyAsText) {
		try {
			StringBuilder storyTextBuilderWithoutComments = new StringBuilder();
			for (String line : (List<String>) readLines(new StringReader(storyAsText))) {
				storyTextBuilderWithoutComments.append(line).append(getProperty("line.separator"));
			}
			return storyTextBuilderWithoutComments.toString();
		} catch (IOException e) {
			throw new RuntimeException(e);
		}
	}

	private Story copyStoryToIncludeOnlySpecifiedScenarios(Story storyWithAllScenarios, int indexOfStoryPath) {
		Scenario scenarioReference = scenariosForStories.scenarios()[indexOfStoryPath];
		List<org.jbehave.core.model.Scenario> listWithOneScenario = new ArrayList<org.jbehave.core.model.Scenario>(1);
		for (org.jbehave.core.model.Scenario scenario : storyWithAllScenarios.getScenarios()) {
			if (scenario.getTitle().equals(scenarioReference.title())) {
				listWithOneScenario.add(scenario);
			}
		}
		if (listWithOneScenario.size() == 0) {
			throw new IllegalStateException("Cannot find scenario " + scenarioReference.title()
					+ " in story " + scenarioReference.story());
		}
		return new Story(storyWithAllScenarios.getPath(),
				storyWithAllScenarios.getDescription(),
				storyWithAllScenarios.getMeta(),
				storyWithAllScenarios.getNarrative(),
				listWithOneScenario);
	}
}
