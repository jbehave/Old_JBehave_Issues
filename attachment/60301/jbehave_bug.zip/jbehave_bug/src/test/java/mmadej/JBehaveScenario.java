package mmadej;

import org.apache.commons.lang.StringUtils;
import org.jbehave.core.ConfigurableEmbedder;
import org.jbehave.core.Embeddable;
import org.jbehave.core.configuration.Configuration;
import org.jbehave.core.configuration.MostUsefulConfiguration;
import org.jbehave.core.embedder.Embedder;
import org.jbehave.core.failures.FailingUponPendingStep;
import org.jbehave.core.i18n.LocalizedKeywords;
import org.jbehave.core.io.LoadFromClasspath;
import org.jbehave.core.model.ExamplesTableFactory;
import org.jbehave.core.parsers.RegexPrefixCapturingPatternParser;
import org.jbehave.core.parsers.StepMatcher;
import org.jbehave.core.reporters.Format;
import org.jbehave.core.reporters.StoryReporterBuilder;
import org.jbehave.core.steps.InjectableStepsFactory;
import org.jbehave.core.steps.InstanceStepsFactory;
import org.jbehave.core.steps.ParameterConverters;
import org.jbehave.core.steps.ParameterConverters.DateConverter;
import org.jbehave.core.steps.StepType;
import org.junit.Test;

import java.io.IOException;
import java.lang.reflect.Method;
import java.lang.reflect.Type;
import java.text.SimpleDateFormat;

import static java.util.Arrays.asList;
import static org.jbehave.core.io.CodeLocations.codeLocationFromClass;
import static org.junit.Assert.assertNotNull;

public abstract class JBehaveScenario extends ConfigurableEmbedder {

	private static final int DEFAULT_USER_STORY_TIMEOUT = 60;
	private ScenariosForStories scenariosForStories;

	protected JBehaveScenario() {
		this.scenariosForStories = getClass().getAnnotation(ScenariosForStories.class);
		assertNotNull("Every JBehave scenario need to be annotated with '"
				+ ScenariosForStories.class.getSimpleName() + "' annotation", scenariosForStories);
	}

	@Test
	public void run() throws Throwable {
		configuredEmbedder().runStoriesAsPaths(new MyStoryResolver()
				.resolveStoryPathsForGivenScenarios(scenariosForStories));
	}

	@Override
	public Embedder configuredEmbedder() {
		Embedder embedder = super.configuredEmbedder();
		embedder.useMetaFilters(asList("-skip"));
		embedder.embedderControls().doGenerateViewAfterStories(false).doIgnoreFailureInStories(false)
				.useStoryTimeoutInSecs(DEFAULT_USER_STORY_TIMEOUT);
		return embedder;
	}

	@Override
	public Configuration configuration() {
		Class<? extends Embeddable> embeddableClass = this.getClass();
		ParameterConverters parameterConverters = new ParameterConverters();
		ExamplesTableFactory examplesTableFactory =
				new ExamplesTableFactory(new LocalizedKeywords(), new LoadFromClasspath(embeddableClass),
						parameterConverters);
		parameterConverters.addConverters(new DateConverter(new SimpleDateFormat("yyyy-MM-dd")),
				new ParameterConverters.ExamplesTableConverter(examplesTableFactory), new EnumConverter());
		try {
			return new MostUsefulConfiguration()
					.useStoryLoader(new LoadFromClasspath(embeddableClass))
					.useStoryParser(new MyStoriesParser(examplesTableFactory, scenariosForStories))
					.useStoryReporterBuilder(new StoryReporterBuilder()
							.withFailureTrace(true)
							.withCodeLocation(codeLocationFromClass(embeddableClass))
							.withFormats(Format.CONSOLE))
					.useParameterConverters(parameterConverters)
					.usePendingStepStrategy(new FailingUponPendingStep())
					.useStepPatternParser(new RegexPrefixCapturingPatternParser() {
						public StepMatcher parseStep(StepType stepType, String stepPattern) {
							return new MyStepMatcherThatIgnoresWhitespaces(super.parseStep(stepType, stepPattern));
						}
					});
		} catch (IOException e) {
			throw new RuntimeException(e);
		}
	}

	@Override
	public InjectableStepsFactory stepsFactory() {
		return new InstanceStepsFactory(configuration(), this);
	}


	public static class EnumConverter implements ParameterConverters.ParameterConverter {
		public boolean accept(Type type) {
			return type instanceof Class<?> && ((Class<?>) type).isEnum();
		}

		public Object convertValue(String value, Type type) {
			String typeClass = ((Class<?>) type).getName();
			Class<?> enumClass = (Class<?>) type;
			if (StringUtils.isEmpty(value)) {
				return null;
			}
			try {
				Method valueOfMethod = enumClass.getMethod("valueOf", new Class[]{String.class});
				return valueOfMethod.invoke(enumClass, value.toUpperCase());
			} catch (Exception e) {
				throw new ParameterConverters.ParameterConvertionFailed("Failed to convert " + value + " for Enum " + typeClass, e);
			}
		}
	}
}