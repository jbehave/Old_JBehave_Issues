package mmadej;

import org.jbehave.core.model.StepPattern;
import org.jbehave.core.parsers.StepMatcher;

import static org.apache.commons.lang.StringUtils.stripAll;

class MyStepMatcherThatIgnoresWhitespaces implements StepMatcher {

	public static final String DOUBLE_QUOTE = "\"";

	private StepMatcher stepMatcher;

	@Override
	public StepPattern pattern() {
		return stepMatcher.pattern();
	}

	public MyStepMatcherThatIgnoresWhitespaces(StepMatcher stepMatcher) {
		this.stepMatcher = stepMatcher;
	}

	@Override
	public boolean matches(String stepWithoutStartingWord) {
		return stepMatcher.matches(stepWithoutStartingWord.trim());
	}

	private String[] unquoteAll() {
		return stripAll(stepMatcher.parameterNames(), DOUBLE_QUOTE);
	}

	@Override
	public boolean find(String stepWithoutStartingWord) {
		return stepMatcher.find(stepWithoutStartingWord.trim());
	}

	@Override
	public String parameter(int matchedPosition) {
		return stepMatcher.parameter(matchedPosition);
	}

	@Override
	public String[] parameterNames() {
		return unquoteAll();
	}
}

