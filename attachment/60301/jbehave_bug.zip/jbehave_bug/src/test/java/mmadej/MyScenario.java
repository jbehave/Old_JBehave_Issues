package mmadej;


import org.jbehave.core.annotations.Given;
import org.jbehave.core.annotations.Named;
import org.jbehave.core.annotations.Then;
import org.jbehave.core.annotations.When;

import static org.hamcrest.core.Is.is;
import static org.hamcrest.core.IsEqual.equalTo;
import static org.junit.Assert.assertThat;

@ScenariosForStories(
		scenarios = {@Scenario(title = "abc1", story = "my_scenario"),
				@Scenario(title = "abc2", story = "my_scenario"),
				@Scenario(title = "abc3", story = "my_scenario")}
)
public class MyScenario extends JBehaveScenario {

	@Given("a")
	public void givenA() {

	}

	@When("b")
	public void whenB() {

	}

	@Then("c <C> and <D>")
	public void thenC(@Named("C") String c, @Named("D") String d) {
		assertThat(c, is(equalTo("C")));
		assertThat(d, is(equalTo("D")));
	}
}
