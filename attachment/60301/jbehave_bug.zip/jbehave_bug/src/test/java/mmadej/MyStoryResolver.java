package mmadej;


import org.springframework.core.io.Resource;
import org.springframework.core.io.support.PathMatchingResourcePatternResolver;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

public class MyStoryResolver {
	private PathMatchingResourcePatternResolver resolver = new PathMatchingResourcePatternResolver();

	public List<String> resolveStoryPathsForGivenScenarios(ScenariosForStories scenariosForStories) throws IOException {
		List<String> storyPaths = new ArrayList<String>(scenariosForStories.scenarios().length);
		for (Scenario scenario : scenariosForStories.scenarios()) {
			storyPaths.add(resolveStoryPath(scenario));
		}
		return storyPaths;
	}

	private String resolveStoryPath(Scenario scenario) throws IOException {
		String patternPath = "classpath:/**/" + "/**/" + scenario.story() + ".story";
		Resource[] resources = resolver.getResources(patternPath);
		String storyPath = resources[0].getURL().getPath();
		return storyPath.substring(storyPath.indexOf("/mmadej/") + 1);
	}
}
